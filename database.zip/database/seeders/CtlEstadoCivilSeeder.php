<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CtlEstadoCivilSeeder extends Seeder
{
    public function run()
    {
        DB::table('ctl_estado_civil')->insert([
            [
                'nombre' => 'Soltero(a)',
                'label_femenino' => 'Soltera',
            ],
            [
                'nombre' => 'Casado(a)',
                'label_femenino' => 'Casada',
            ],
            [
                'nombre' => 'Divorciado(a)',
                'label_femenino' => 'Divorciada',
            ],
            [
                'nombre' => 'Viudo(a)',
                'label_femenino' => 'Viuda',
            ],
            [
                'nombre' => 'Acompañado(a)',
                'label_femenino' => 'Acompañada',
            ],
            [
                'nombre' => 'Unión Estable',
                'label_femenino' => 'Unión Estable',
            ],
            [
                'nombre' => 'No aplica',
                'label_femenino' => 'No aplica',
            ],
        ]);
    }
}
