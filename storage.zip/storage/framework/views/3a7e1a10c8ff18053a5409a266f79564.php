<?php $__env->startSection('title', 'Crear usuario'); ?>

<?php $__env->startSection('content'); ?>
<div class="p-6">
    <div class="bg-white p-4 rounded shadow mb-4">

        <div class="bg-[#edf3ff] p-2 rounded-md mb-4 text-center border border-[#d0e1ff]">
            <h2 class="text-xl font-semibold text-[#576ca9]">Formulario de Creación de Usuario</h2>
        </div>
        
        <!-- Formulario de filtros -->
        <form method="POST" action="<?php echo e(route('users.store')); ?>" class="grid grid-cols-1 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 xxl:grid-cols-5 gap-x-4 gap-y-6 mt-6">
            <?php echo csrf_field(); ?>

            <div class="input-container">
                <label for="primer_nombre" class="input-label">Primer nombre</label>
                <input type="text" id="primer_nombre" name="primer_nombre" class="input-field" value="<?php echo e(old('primer_nombre')); ?>">
                <?php $__errorArgs = ['primer_nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="input-container">
                <label for="segundo_nombre" class="input-label">Segundo nombre</label>
                <input type="text" id="segundo_nombre" name="segundo_nombre" class="input-field" value="<?php echo e(old('segundo_nombre')); ?>">
                <?php $__errorArgs = ['segundo_nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="input-container">
                <label for="tercer_nombre" class="input-label">Tercer nombre</label>
                <input type="text" id="tercer_nombre" name="tercer_nombre" class="input-field" value="<?php echo e(old('tercer_nombre')); ?>">
                <?php $__errorArgs = ['tercer_nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            
            <div class="input-container">
                <label for="primer_apellido" class="input-label">Primer apellido</label>
                <input type="text" id="primer_apellido" name="primer_apellido" class="input-field" value="<?php echo e(old('primer_apellido')); ?>">
                <?php $__errorArgs = ['primer_apellido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="input-container">
                <label for="segundo_apellido" class="input-label">Segundo apellido</label>
                <input type="text" id="segundo_apellido" name="segundo_apellido" class="input-field" value="<?php echo e(old('segundo_apellido')); ?>">
                <?php $__errorArgs = ['segundo_apellido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="input-container">
                <label for="fecha_nacimiento" class="input-label">Fecha de nacimiento</label>
                <input type="date" id="fecha_nacimiento" name="fecha_nacimiento" class="input-field" value="<?php echo e(old('fecha_nacimiento')); ?>">
                <?php $__errorArgs = ['fecha_nacimiento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="input-container">
                <label for="edad" class="input-label">Edad</label>
                <input type="number" id="edad" name="edad" class="input-field" value="<?php echo e(old('edad')); ?>" disabled>
            </div>

            <div class="input-container">
                <label for="nro_documento" class="input-label">N° de documento</label>
                <input type="text" id="nro_documento" name="nro_documento" class="input-field" value="<?php echo e(old('nro_documento')); ?>">
                <?php $__errorArgs = ['nro_documento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="input-container">
                <label for="correo_institucional" class="input-label">Correo institucional</label>
                <input type="email" id="correo_institucional" name="correo_institucional" class="input-field" value="<?php echo e(old('correo_institucional')); ?>">
                <?php $__errorArgs = ['correo_institucional'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="input-container">
                <label for="role" class="input-label">Tipo de Usuario</label>
                <select id="role" name="role" class="select-field bg-white">
                    <option value="" disabled selected>Seleccione</option>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($role->name); ?>" <?php echo e((old('role') == $role->name) ? 'selected' : ''); ?>>
                            <?php echo e($role->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div id="establecimiento-container" class="input-container <?php echo e((old('role') == 'Región' || old('role') == 'Sibasi') ? '' : 'hidden'); ?>">
                <label for="establecimiento" class="input-label">Establecimiento</label>
                <select id="establecimiento" name="establecimiento" class="select-field bg-white">
                    <option value="" disabled selected>Seleccione</option>
                    <!-- Las opciones se cargan dinamicamente segun el rol -->
                </select>
                <?php $__errorArgs = ['establecimiento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <?php if(session('error')): ?>
                <div class="col-span-full bg-red-500 text-white p-2 mt-4 rounded-md relative flex items-center justify-between gap-2">
                    <div class="flex items-center gap-2">
                        <span class="material-symbols-outlined">cancel</span> 
                        <span><?php echo e(session('error')); ?></span>
                    </div>
                    <button class="notification-close-button" onclick="this.parentElement.style.display='none';"><span class="material-symbols-outlined">close</span></button>
                </div>
            <?php endif; ?>
            
            <div class="col-span-full flex justify-end mt-4">
                <button type="submit" class="bg-[#576ca9] text-white pt-3.5 pb-3 px-4 rounded inline-flex items-center text-base">
                    <span class="material-symbols-outlined mr-2 text-base">person_add</span>
                    AGREGAR USUARIO
                </button>
                <a href="<?php echo e(route('users.index')); ?>" class="bg-gray-500 text-white pt-3.5 pb-3 px-4 rounded inline-flex items-center ml-2 text-base">
                    <span class="material-symbols-outlined mr-2 text-base">cancel</span>
                    CANCELAR
                </a>
            </div>
        </form>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const fechaNacimientoInput = document.getElementById('fecha_nacimiento');
        const edadInput = document.getElementById('edad');
        const roleSelect = document.getElementById('role');
        const establecimientoContainer = document.getElementById('establecimiento-container');
        const establecimientoSelect = document.getElementById('establecimiento');

        // Eventos principales
        fechaNacimientoInput.addEventListener('change', () => calculateAge(fechaNacimientoInput.value, edadInput.id));
        roleSelect.addEventListener('change', handleRoleChange);
        establecimientoSelect.addEventListener('change', () => saveSelectedEstablecimiento(establecimientoSelect.value));

        // Restaurar opciones y selección previa al cargar la página
        restoreEstablecimientoState();

        // Limpiar localStorage al enviar el formulario
        document.querySelector('form').addEventListener('submit', clearLocalStorage);

        // Funciones
        function calculateAge(fechaNacimiento, edadInputId) {
            const today = new Date();
            const birthDate = new Date(fechaNacimiento);
            let age = today.getFullYear() - birthDate.getFullYear();
            const monthDifference = today.getMonth() - birthDate.getMonth();

            if (monthDifference < 0 || (monthDifference === 0 && today.getDate() < birthDate.getDate())) {
                age--;
            }

            document.getElementById(edadInputId).value = age;
        }

        function handleRoleChange() {
            const selectedRole = roleSelect.value;

            if (selectedRole === 'Región' || selectedRole === 'Sibasi') {
                establecimientoContainer.classList.remove('hidden');
                fetchEstablecimientos(selectedRole);
            } else {
                establecimientoContainer.classList.add('hidden');
                establecimientoSelect.innerHTML = '<option value="" disabled selected>Seleccione</option>';
            }
        }

        function fetchEstablecimientos(role) {
            fetch(`/obtener/establecimientos/${encodeURIComponent(role)}`)
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`Error ${response.status}: ${response.statusText}`);
                    }
                    return response.json();
                })
                .then(data => {
                    setEstablecimientos(data.establecimientos);
                })
                .catch(error => {
                    console.error('Error al intentar obtener establecimientos:', error);
                    alert('Hubo un problema al cargar los establecimientos. Inténtelo de nuevo más tarde.');
                });
        }

        function setEstablecimientos(establecimientos) {
            establecimientoSelect.innerHTML = '<option value="" disabled selected>Seleccione</option>';
            establecimientos.forEach(establecimiento => {
                const option = document.createElement('option');
                option.value = establecimiento.id;
                option.textContent = establecimiento.nombre;
                establecimientoSelect.appendChild(option);
            });

            // Guardar opciones en localStorage
            localStorage.setItem('establecimientoOptions', establecimientoSelect.innerHTML);
        }

        function saveSelectedEstablecimiento(value) {
            localStorage.setItem('selectedEstablecimiento', value);
        }

        function restoreEstablecimientoState() {
            const options = localStorage.getItem('establecimientoOptions');
            const selectedValue = localStorage.getItem('selectedEstablecimiento');

            if (options) {
                establecimientoSelect.innerHTML = options;
            }

            if (selectedValue) {
                establecimientoSelect.value = selectedValue;
            }
        }

        function clearLocalStorage() {
            localStorage.removeItem('establecimientoOptions');
            localStorage.removeItem('selectedEstablecimiento');
        }
    });

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/users/create.blade.php ENDPATH**/ ?>