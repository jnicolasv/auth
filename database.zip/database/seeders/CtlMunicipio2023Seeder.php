<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CtlMunicipio2023Seeder extends Seeder
{
    public function run()
    {
        DB::table('ctl_municipio2023')->insert([
            [
                'nombre' => 'Ahuachapan Norte',
                'id_departamento' => '1',
                'id_usuario_reg' => null,
                'cabecera' => false,
            ],
            [
                'nombre' => 'Ahuachapan Centro',
                'id_departamento' => '1',
                'id_usuario_reg' => null,
                'cabecera' => 'true',
            ],
            [
                'nombre' => 'Ahuachapan Sur',
                'id_departamento' => '1',
                'id_usuario_reg' => null,
                'cabecera' => false,
            ],
            [
                'nombre' => 'Santa Ana Norte',
                'id_departamento' => '2',
                'id_usuario_reg' => null,
                'cabecera' => false,
            ],
            [
                'nombre' => 'Santa Ana Centro',
                'id_departamento' => '2',
                'id_usuario_reg' => null,
                'cabecera' => 'true',
            ],
            [
                'nombre' => 'Santa Ana Este',
                'id_departamento' => '2',
                'id_usuario_reg' => null,
                'cabecera' => false,
            ],
            [
                'nombre' => 'Santa Ana Oeste',
                'id_departamento' => '2',
                'id_usuario_reg' => null,
                'cabecera' => false,
            ],
            [
                'nombre' => 'Sonsonate Norte',
                'id_departamento' => '3',
                'id_usuario_reg' => null,
                'cabecera' => false,
            ],
            [
                'nombre' => 'Sonsonate Centro',
                'id_departamento' => '3',
                'id_usuario_reg' => null,
                'cabecera' => 'true',
            ],
            [
                'nombre' => 'Sonsonate Este',
                'id_departamento' => '3',
                'id_usuario_reg' => null,
                'cabecera' => false,
            ],
            [
                'nombre' => 'Sonsonate Oeste',
                'id_departamento' => '3',
                'id_usuario_reg' => null,
                'cabecera' => false,
            ],
            [
                'nombre' => 'Chalatenango Norte',
                'id_departamento' => '4',
                'id_usuario_reg' => null,
                'cabecera' => false,
            ],
            [
                'nombre' => 'Chalatenango Centro',
                'id_departamento' => '4',
                'id_usuario_reg' => null,
                'cabecera' => false,
            ],
            [
                'nombre' => 'Chalatenango Sur',
                'id_departamento' => '4',
                'id_usuario_reg' => null,
                'cabecera' => 'true',
            ],
            [
                'nombre' => 'La Libertad Norte',
                'id_departamento' => '5',
                'id_usuario_reg' => null,
                'cabecera' => false,
            ],
            [
                'nombre' => 'La Libertad Centro',
                'id_departamento' => '5',
                'id_usuario_reg' => null,
                'cabecera' => false,
            ],
            [
                'nombre' => 'La Libertad Oeste',
                'id_departamento' => '5',
                'id_usuario_reg' => null,
                'cabecera' => false,
            ],
            [
                'nombre' => 'La Libertad Este',
                'id_departamento' => '5',
                'id_usuario_reg' => null,
                'cabecera' => false,
            ],
            [
                'nombre' => 'La Libertad Costa',
                'id_departamento' => '5',
                'id_usuario_reg' => null,
                'cabecera' => false,
            ],
            [
                'nombre' => 'La Libertad Sur',
                'id_departamento' => '5',
                'id_usuario_reg' => null,
                'cabecera' => 'true',
            ],
            [
                'nombre' => 'San Salvador Norte',
                'id_departamento' => '6',
                'id_usuario_reg' => null,
                'cabecera' => false,
            ],
            [
                'nombre' => 'San Salvador Oeste',
                'id_departamento' => '6',
                'id_usuario_reg' => null,
                'cabecera' => false,
            ],
            [
                'nombre' => 'San Salvador Este',
                'id_departamento' => '6',
                'id_usuario_reg' => null,
                'cabecera' => false,
            ],
            [
                'nombre' => 'San Salvador Centro',
                'id_departamento' => '6',
                'id_usuario_reg' => null,
                'cabecera' => 'true',
            ],
            [
                'nombre' => 'San Salvador Sur',
                'id_departamento' => '6',
                'id_usuario_reg' => null,
                'cabecera' => false,
            ],
            [
                'nombre' => 'Cuscatlan Norte',
                'id_departamento' => '7',
                'id_usuario_reg' => null,
                'cabecera' => false,
            ],
            [
                'nombre' => 'Cuscatlan Sur',
                'id_departamento' => '7',
                'id_usuario_reg' => null,
                'cabecera' => 'true',
            ],
            [
                'nombre' => 'La Paz Oeste',
                'id_departamento' => '8',
                'id_usuario_reg' => null,
                'cabecera' => false,
            ],
            [
                'nombre' => 'La Paz Centro',
                'id_departamento' => '8',
                'id_usuario_reg' => null,
                'cabecera' => false,
            ],
            [
                'nombre' => 'La Paz Este',
                'id_departamento' => '8',
                'id_usuario_reg' => null,
                'cabecera' => 'true',
            ],
            [
                'nombre' => 'Cabañas Este',
                'id_departamento' => '9',
                'id_usuario_reg' => null,
                'cabecera' => 'true',
            ],
            [
                'nombre' => 'Cabañas Oeste',
                'id_departamento' => '9',
                'id_usuario_reg' => null,
                'cabecera' => false,
            ],
            [
                'nombre' => 'San Vicente Norte',
                'id_departamento' => '10',
                'id_usuario_reg' => null,
                'cabecera' => false,
            ],
            [
                'nombre' => 'San Vicente Sur',
                'id_departamento' => '10',
                'id_usuario_reg' => null,
                'cabecera' => 'true',
            ],
            [
                'nombre' => 'Usulutan Norte',
                'id_departamento' => '11',
                'id_usuario_reg' => null,
                'cabecera' => false,
            ],
            [
                'nombre' => 'Usulutan Este',
                'id_departamento' => '11',
                'id_usuario_reg' => null,
                'cabecera' => 'true',
            ],
            [
                'nombre' => 'Usulutan Oeste',
                'id_departamento' => '11',
                'id_usuario_reg' => null,
                'cabecera' => false,
            ],
            [
                'nombre' => 'San Miguel Norte',
                'id_departamento' => '12',
                'id_usuario_reg' => null,
                'cabecera' => false,
            ],
            [
                'nombre' => 'San Miguel Centro',
                'id_departamento' => '12',
                'id_usuario_reg' => null,
                'cabecera' => 'true',
            ],
            [
                'nombre' => 'San Miguel Oeste',
                'id_departamento' => '12',
                'id_usuario_reg' => null,
                'cabecera' => false,
            ],
            [
                'nombre' => 'Morazan Norte',
                'id_departamento' => '13',
                'id_usuario_reg' => null,
                'cabecera' => false,
            ],
            [
                'nombre' => 'Morazan Sur',
                'id_departamento' => '13',
                'id_usuario_reg' => null,
                'cabecera' => 'true',
            ],
            [
                'nombre' => 'La Union Norte',
                'id_departamento' => '14',
                'id_usuario_reg' => null,
                'cabecera' => false,
            ],
            [
                'nombre' => 'La Union Sur',
                'id_departamento' => '14',
                'id_usuario_reg' => null,
                'cabecera' => 'true',
            ],
        ]);
    }
}
