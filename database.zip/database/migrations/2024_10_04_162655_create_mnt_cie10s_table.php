<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('mnt_cie10', function (Blueprint $table) {
            $table->id();
            $table->string('codigo', 5)->default('')->unique();
            $table->integer('grupom')->default(0);
            $table->integer('codgrupo')->default(0);
            $table->string('diagnostico', 130)->nullable();
            $table->smallInteger('alarma')->nullable()->default(0);
            $table->smallInteger('sexo_cie10')->default(0);
            $table->integer('c_salida')->nullable();
            $table->integer('mayor')->nullable();
            $table->integer('menor')->nullable();
            $table->smallInteger('critico')->nullable()->default(0);
            $table->text('unaccent_diagnostico')->nullable();
            $table->boolean('activo')->default(true);
            $table->boolean('odontologia')->default(false);
            $table->boolean('causa_externa')->default(false);
            $table->boolean('incluir_repetitiva')->nullable()->default(false);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('mnt_cie10');
    }
};
