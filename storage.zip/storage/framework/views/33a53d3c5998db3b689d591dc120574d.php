<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Usuarios</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/output.css')); ?>">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.tailwind.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <style>
        #sidebar {
            border-radius: 0 20px 20px 0;
        }
        .toggleMenu span {
            font-size: 2rem;
            padding: 5px 13px;
        }
        .menu-item span:first-child {
            font-size: 2rem;
            padding: 3px;
        }
        .menu-item span:nth-child(2) {
            display: none;
        }
        .toggleMenu {
            height: 80px !important;
            /* margin-bottom: 80px; */
        }
        .menu-item {
            cursor: pointer;
            transition: background-color 0.3s;
            padding: 7px 10px;
            border-radius: 10px;
        }
        .menu-item:hover {
            background-color: darkblue;
        }

        @media (max-width: 640px) {
            #content h1 {
                font-size: 1rem; /* Reduce el tamaño del texto para pantallas pequeñas */
                line-height: 1.25; /* Ajusta el espaciado entre líneas */
                word-wrap: break-word; /* Permite que el texto se ajuste */
            }
            #settingsButton {
                margin-top: 1rem; /* Asegura espacio entre el título y el botón en diseño en bloque */
            }
        }
        table {
            min-width: 100%; /* Permite que el contenido se ajuste mejor a tamaños pequeños */
        }
        #settingsButton {
            display: flex;
            align-items: center;
            justify-content: center;
        }
    </style>
</head>
<body class="bg-gray-100 font-sans">
    <div class="flex h-screen">
        <!-- Sidebar -->
        <aside id="sidebar" class="bg-[#576ca9] text-white shadow-2xl shadow-black/50 w-[90px] p-4 fixed h-full">
            <div class="toggleMenu">
                <button id="openSidebar" class="text-white absolute top-4 left-4 z-10">
                <span class="material-symbols-outlined">menu</span>
                </button>
                <button id="closeSidebar" class="text-white absolute top-4 left-4 z-10 hidden">
                <span class="material-symbols-outlined">close</span>
                </button>
            </div>
            <ul>
                <li class="mb-4 flex items-center gap-2 menu-item">
                    <span class="material-symbols-outlined">person</span>
                    <span>Gestión de Usuarios</span>
                </li>
                <li class="mb-4 flex items-center gap-2 menu-item">
                    <span class="material-symbols-outlined">description</span>
                    <span>Reportes Validados</span>
                </li>
                <li class="flex items-center gap-2 menu-item">
                    <span class="material-symbols-outlined">pending_actions</span>
                    <span>Reportes Pendientes de Validar</span>
                </li>
            </ul>
        </aside>

        <!-- Main content -->
        <div id="content" class="flex-1 ml-[90px]">
            <div class="p-4 flex flex-col sm:flex-row items-center justify-between border-b border-gray-200 shadow-md">
                <!-- Título y botón de ajustes -->
                <h1 class="text-center sm:text-left text-base sm:text-lg md:text-xl font-bold break-words w-full sm:w-auto text-gray-600">
                    SISTEMA CENTRALIZADO DE REACCIONES ADVERSAS
                </h1>
                <div class="mt-2 sm:mt-0 flex sm:block justify-center w-full sm:w-auto">
                    <button id="settingsButton" class="text-gray-600">
                        <span class="material-symbols-outlined" style="font-size: 2.5rem;font-weight: normal;">settings</span>
                    </button>
                    <!-- Menú de configuración -->
                    <div id="settingsMenu" class="hidden absolute right-0 mt-2 w-48 bg-white shadow-md border rounded">
                        <ul>
                            <li class="px-4 py-2 hover:bg-gray-100">Configuración General</li>
                            <li class="px-4 py-2 hover:bg-gray-100">Ajustes de Usuario</li>
                            <li class="px-4 py-2 hover:bg-gray-100">
                                <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Cerrar Sesión</a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="hidden">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="p-6">
                <!-- Filters -->
                <div class="bg-white p-4 rounded shadow mb-4">
                    <div class="border-2 border-[#576ca9] bg-[#edf3ff] p-2 rounded-2xl mb-4 text-center">
                        <h2 class="text-xl font-semibold text-[#576ca9]">Usuarios del Sistema</h2>
                    </div>
                    
                    <form class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 mt-6">
                        <input type="text" placeholder="Nombre" class="p-2 border rounded">
                        <select class="p-2 border rounded">
                            <option value="" disabled selected>Tipo de Usuario</option>
                            <option value="Administrador">Administrador</option>
                            <option value="Sibasi">Sibasi</option>
                        </select>
                        <select class="p-2 border rounded">
                            <option value="" disabled selected>Estado</option>
                            <option value="Activo">Activo</option>
                            <option value="Inactivo">Inactivo</option>
                        </select>
                        <button class="bg-[#576ca9] text-white py-2 px-4 rounded">FILTRAR</button>
                        <button class="bg-gray-300 py-2 px-4 rounded">LIMPIAR</button>
                    </form>
                    <hr class="col-span-3 my-4 border-t border-[#576ca9]">
                    <div class="col-span-1 flex justify-end">
                        <button class="bg-[#576ca9] text-white py-2 px-4 rounded text-base">AGREGAR USUARIO</button>
                    </div>
                </div>

                <!-- Users Table -->
                <div class="bg-white p-4 rounded shadow overflow-x-auto">
                    <table id="tablaUsuarios" class="w-full border-collapse border border-gray-200 min-w-[600px]">
                        <thead class="bg-[#576ca9] text-white">
                            <tr>
                                <th class="p-2 border">Nombre</th>
                                <th class="p-2 border">Apellido</th>
                                <th class="p-2 border">Correo Institucional</th>
                                <th class="p-2 border">Tipo Usuario</th>
                                <th class="p-2 border">Estado</th>
                                <th class="p-2 border">Acción</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr class="odd:bg-gray-100">
                                <td class="p-2 border">Juan Alfredo</td>
                                <td class="p-2 border">Perez García</td>
                                <td class="p-2 border">juan.perez@salud.gob.sv</td>
                                <td class="p-2 border">Secretaría de Estado</td>
                                <td class="p-2 border text-center">
                                    <span class="bg-green-100 text-green-800 text-xs font-semibold px-2 py-1 rounded">Habilitado</span>
                                </td>
                                <td class="p-2 border text-center">
                                    <button class="text-[#576ca9]"><span class="material-symbols-outlined">edit_square</span></button>
                                </td>
                            </tr>
                            <!-- Agrega más filas según sea necesario -->
                        </tbody>
                    </table>
                
                    <!-- Paginación -->
                    
                </div>
                
            </div>
        </div>
    </div>

    <script>
        document.getElementById('openSidebar').addEventListener('click', () => {
            document.getElementById('sidebar').style.transition = 'width 0.3s';
            document.getElementById('content').style.transition = 'margin-left 0.3s';
            document.getElementById('sidebar').style.width = '330px';
            document.getElementById('content').style.marginLeft = '330px';
            document.getElementById('closeSidebar').classList.remove('hidden');
            document.getElementById('openSidebar').classList.add('hidden');

            setTimeout(() => {
            document.querySelectorAll('.menu-item span:nth-child(2)').forEach(span => {
                span.style.display = 'block';
                span.style.transition = 'opacity 0.5s';
                span.style.opacity = '1';
            });
            }, 300); // Wait for the sidebar transition to complete
        });

        document.getElementById('closeSidebar').addEventListener('click', () => {
            document.getElementById('sidebar').style.transition = 'width 0.3s';
            document.getElementById('content').style.transition = 'margin-left 0.3s';
            document.getElementById('sidebar').style.width = '90px';
            document.getElementById('content').style.marginLeft = '90px';
            document.getElementById('closeSidebar').classList.add('hidden');
            document.getElementById('openSidebar').classList.remove('hidden');

            document.querySelectorAll('.menu-item span:nth-child(2)').forEach(span => {
            span.style.display = 'none';
            });
        });

        document.getElementById('settingsButton').addEventListener('click', () => {
            const menu = document.getElementById('settingsMenu');
            menu.classList.toggle('hidden');
        });
    </script>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.tailwind.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#tablaUsuarios').DataTable({
                language: {
                    url: '//cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json'
                },
                responsive: true,
                paging: true,
                searching: true,
            });
        });
    </script>
</body>
</html>
<?php /**PATH /var/www/html/resources/views/dashboardNO.blade.php ENDPATH**/ ?>