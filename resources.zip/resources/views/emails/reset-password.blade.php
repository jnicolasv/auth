<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restablecimiento de contraseña</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 14px;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .ii a[href] {
            color: #fff;
        }
        .email-wrapper {
            width: 100%;
            background-color: #f4f4f4;
            padding: 20px 0;
        }
        .email-container {
            max-width: 600px;
            background: #ffffff;
            border-radius: 12px;
            padding: 15px;
            border: 1px solid #eee;
        }
        .header {
            background: #293653;
            padding: 20px;
            color: #ffffff;
            font-size: 24px;
            font-weight: bold;
            text-align: center;
        }
        .content {
            padding: 20px;
            color: #333333;
            text-align: center;
            font-size: 16px;
        }
        .button {
            display: inline-block;
            background: #455A8A;
            color: #ffffff !important;
            padding: 12px 24px;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
            margin: 20px auto;
            text-align: center;
        }
        .button:hover {
            background: #293653;
        }
        .footer {
            background: #d4d4dc ;
            color: #293653 ;
            padding: 10px;
            font-size: 14px;
            border-radius: 0 0 8px 8px;
            text-align: center;
        }
        .footer a {
            color: #ffffff;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" class="email-wrapper">
        <tr>
            <td align="center">
                <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="600" class="email-container">
                    <tr>
                        <td align="center" class="header">
                             {{-- <img src="{{ asset('images/lock_icon.png') }}" alt="Icon lock" style="width: 40px;"> --}}
                            <img src="https://drive.google.com/uc?export=view&id=10XE3WuEyWsYDhXHeT7_vm2wOLm0MsASS" alt="Icon lock" style="height: 40px;"><br>
                            Restablecimiento de Contraseña
                        </td>
                    </tr>
                    <tr>
                        <td align="center" class="content">
                             {{-- <img src="{{ asset('images/logo.png') }}" alt="Logotipo" style="width: 250px;"> --}}
                            <img src="https://drive.google.com/uc?export=view&id=1peIYOpT2g0LescQLjNM7xV0BqsD0wUW4" alt="Logotipo" style="height: 85px;"><br>
                            <h2>Hola, {{ $user->persona->primer_nombre }} {{ $user->persona->primer_apellido }}</h2>
                            <p>Has recibido este correo porque solicitaste restablecer tu contraseña.</p>
                            <p>Haz clic en el siguiente botón para restablecer tu contraseña:</p>
                            <a href="{{ $url }}" class="button">Restablecer Contraseña</a>
                            <p>Este enlace expirará en 60 minutos.</p>
                        </td>
                    </tr>
                    <tr>
                        <td align="center" class="footer">
                            <p>Si no solicitaste un restablecimiento de contraseña, puedes ignorar este mensaje.</p>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>