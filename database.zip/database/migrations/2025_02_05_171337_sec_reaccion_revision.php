<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('sec_reaccion_revision', function (Blueprint $table) {
            $table->id();

            $table->unsignedBigInteger('reaccion_adversa_id');
            $table->string('estado_revision', 20)->default('Pendiente');
            $table->timestamp('fecha_revision')->nullable();
            $table->text('observaciones')->nullable();
            $table->unsignedBigInteger('usuario_id');
            
            // Definir claves foráneas
            $table->foreign('reaccion_adversa_id')->references('id')->on('sec_reaccion_adversa')->onDelete('cascade');
            $table->foreign('usuario_id')->references('id')->on('users')->onDelete('cascade');
            
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('sec_reaccion_revision');
    }
};
