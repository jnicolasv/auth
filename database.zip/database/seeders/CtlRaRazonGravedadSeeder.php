<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CtlRaRazonGravedadSeeder extends Seeder
{
    public function run()
    {
        DB::table('ctl_ra_razon_gravedad')->insert([
            [
                'nombre_corto' => 'PELVIDA',
                'nombre' => 'Han puesto en peligro su vida',
                'activo' => true,
            ],
            [
                'nombre_corto' => 'CAUHOSP',
                'nombre' => 'Han sido la causa de su hospitalización',
                'activo' => true,
            ],
            [
                'nombre_corto' => 'PROLHOSP',
                'nombre' => 'Han prolongado su ingreso en el hospital',
                'activo' => true,
            ],
            [
                'nombre_corto' => 'INCAP',
                'nombre' => 'Han originado incapacidad persistente o grave',
                'activo' => true,
            ],
            [
                'nombre_corto' => 'DEFANOM',
                'nombre' => 'Han causado defecto o anomalía congénita',
                'activo' => true,
            ],
            [
                'nombre_corto' => 'MUER',
                'nombre' => 'Han causado la muerte del paciente',
                'activo' => true,
            ],
            [
                'nombre_corto' => 'NADAANT',
                'nombre' => 'No han causado nada de lo anterior pero considero que es grave',
                'activo' => true,
            ],
            [
                'nombre_corto' => 'NOGRAVE',
                'nombre' => 'No ha causado nada de lo anterior y considero que NO es grave',
                'activo' => true,
            ],
        ]);
    }
}
