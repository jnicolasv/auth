<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CtlRaClasificacionNotificadorSeeder extends Seeder
{
    public function run()
    {
        DB::table('ctl_ra_clasificacion_notificador')->insert([
            [
                'nombre_corto' => 'RFV',
                'nombre' => 'Referente de farmacovigilancia',
                'descripcion' => null,
                'activo' => true,
            ],
            [
                'nombre_corto' => 'MC',
                'nombre' => 'Médico consultante',
                'descripcion' => null,
                'activo' => true,
            ],
            [
                'nombre_corto' => 'F',
                'nombre' => 'Farmacéutico',
                'descripcion' => null,
                'activo' => true,
            ],
            [
                'nombre_corto' => 'O',
                'nombre' => 'Otro',
                'descripcion' => null,
                'activo' => true,
            ],
        ]);
    }
}
