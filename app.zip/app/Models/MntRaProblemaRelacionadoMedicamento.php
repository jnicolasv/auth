<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MntRaProblemaRelacionadoMedicamento extends Model
{
    use HasFactory;

    protected $table = 'mnt_ra_problema_relacionado_medicamento';

    protected $fillable = [
        'id_ram',
        'id_organo_afectado',
        'codigo_snomed',
        'label_snomed',
        'fecha_inicio',
        'fecha_fin',
        'id_usuario_registra'
    ];

    // Relaciones
    public function ram()
    {
        return $this->belongsTo(SecRam::class, 'id_ram');
    }

    public function organoAfectado()
    {
        return $this->belongsTo(CtlRaOrganoAfectado::class, 'id_organo_afectado');
    }

    public function usuarioRegistra()
    {
        return $this->belongsTo(FosUserUser::class, 'id_usuario_registra');
    }

}
