<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CtlRaMarcoAplicacionSeeder extends Seeder
{
    public function run()
    {
        DB::table('ctl_ra_marco_aplicacion')->insert([
            [
                'nombre_corto' => 'CEV',
                'nombre' => 'Cumplimiento del esquema de vacunación',
                'descripcion' => null,
                'activo' => true,
            ],
            [
                'nombre_corto' => 'DC',
                'nombre' => 'Durante campaña',
                'descripcion' => null,
                'activo' => true,
            ],
            [
                'nombre_corto' => 'V',
                'nombre' => 'Viajero',
                'descripcion' => null,
                'activo' => true,
            ],
            [
                'nombre_corto' => 'O',
                'nombre' => 'Otros',
                'descripcion' => null,
                'activo' => true,
            ],
            [
                'nombre_corto' => 'IM',
                'nombre' => 'Indicación médica',
                'descripcion' => null,
                'activo' => true,
            ],
        ]);
    }
}
