<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CtlTipoDiagnostico extends Model
{
    use HasFactory;

    protected $table = 'ctl_tipo_diagnostico';

    protected $fillable = [
        'nombre',
    ];

    // Relación con SecRaDiagnostico
    public function secRaDiagnosticos()
    {
        return $this->hasMany(SecRaDiagnostico::class, 'id_tipo_diagnostico');
    }
}
