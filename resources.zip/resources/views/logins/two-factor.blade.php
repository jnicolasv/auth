@extends('layout-login')

@section('title', 'Verificación en dos pasos')

@section('content')

    {{-- Formulario de restablecimiento --}}
    <form action="{{ route('two-factor.verify') }}" method="POST">
        @csrf

        <div class="mb-5">
            <p class="text-gray-700 text-lg text-center font-bold">Verificación en dos paso</p>
        </div>

        {{-- Campos --}}
        <div class="grid grid-cols-1 gap-x-4 gap-y-6 mt-10">

            <div class="input-container">
                <label for="code" class="input-label">Código de verificación</label>
                <input type="text" id="code" name="code" class="input-field" value="{{ request('code') }}">
            </div>

        </div>

        {{-- Botón Verificar --}}
        <div class="flex flex-wrap justify-center mt-5 gap-4 w-full mx-auto">
            <button type="button" class="btn-secondary flex-1 min-w-[150px]" onclick="document.getElementById('cancel-form').submit()">
                Cancelar
            </button>
            <button type="submit" class="btn-primary flex-1 min-w-[150px]">
                Verificar
            </button>
        </div>
    </form>

    {{-- Formulario oculto para cancelar --}}
    <form id="cancel-form" action="{{ route('two-factor.cancel') }}" method="POST" class="hidden">
        @csrf
    </form>

    {{-- Mostrar mensajes de error --}}
    @if (session('status'))
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mt-4" role="alert">
            <p class="text-sm">{{ session('status') }}</p>
        </div>
    @endif

    {{-- Mostrar errores de validación --}}
    @if ($errors->any())
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mt-4" role="alert">
            @foreach ($errors->all() as $error)
                <p class="text-sm">{{ $error }}</p>
            @endforeach
        </div>
    @endif

@endsection
