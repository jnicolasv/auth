<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('sec_vacuna_sospechosa_esavi', function (Blueprint $table) {
            $table->id();
            
            $table->integer('id_via_administracion')->nullable();
            $table->integer('id_tipo_vacuna')->nullable();
            $table->integer('id_region_cuerpo')->nullable();
            $table->integer('id_recurso_vacunador')->nullable();
            $table->integer('id_marco_aplicacion')->nullable();
            $table->integer('id_lugar_vacunacion')->nullable();
            $table->integer('id_vacuna');
            $table->string('numero_registro_sanitario', 20)->nullable();
            $table->string('nombre_comercial', 100);
            $table->string('numero_dosis', 15)->nullable();
            $table->decimal('dosis_vacuna_ml', 5, 2)->nullable();
            $table->string('otro_sitio_anatomico', 30)->nullable();
            $table->decimal('temperatura_conservacion', 5, 2)->nullable();
            $table->string('direccion_establecimiento', 256)->nullable();
            $table->string('otra_indicacion_medica', 50)->nullable();
            $table->string('otra_via_administracion', 25)->nullable();
            $table->string('laboratorio', 120)->nullable();
            $table->string('lote', 10)->nullable();
            $table->string('fecha_vencimiento')->nullable();
            $table->date('fecha_vacunacion')->nullable();
            $table->time('hora_vacunacion')->nullable();
            $table->string('otro_recurso_vacunador', 300)->nullable();
            $table->boolean('resguarda_frasco');
            $table->integer('total_vacunas_aplicadas')->nullable();
            $table->integer('total_vacunas_establecimientos')->nullable();
            $table->integer('id_esavi')->nullable();
            $table->integer('id_usuario_registra')->nullable();

            // Definición de las claves foráneas
            $table->foreign('id_via_administracion')->references('id')->on('farm_via_administracion');
            $table->foreign('id_tipo_vacuna')->references('id')->on('ctl_ra_sospecha_medicamento');
            $table->foreign('id_region_cuerpo')->references('id')->on('ctl_region_cuerpo');
            $table->foreign('id_recurso_vacunador')->references('id')->on('ctl_ra_recurso_vacunador');
            $table->foreign('id_marco_aplicacion')->references('id')->on('ctl_ra_marco_aplicacion');
            $table->foreign('id_lugar_vacunacion')->references('id')->on('ctl_ra_lugar_vacunacion');
            $table->foreign('id_vacuna')->references('id')->on('ctl_vacunas');
            $table->foreign('id_esavi')->references('id')->on('sec_esavi');
            $table->foreign('id_usuario_registra')->references('id')->on('fos_user_user');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('sec_vacuna_sospechosa_esavi');
    }
};
