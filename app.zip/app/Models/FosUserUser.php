<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FosUserUser extends Model
{
    use HasFactory;

    protected $table = 'fos_user_user';

    protected $fillable = [
        'id_sis',
        'username',
        'email',
        'date_of_birth',
        'firstname',
        'lastname',
        'gender',
        'phone',
        'id_establecimiento',
        'id_empleado',
    ];

    // Relaciones
    public function empleado()
    {
        return $this->belongsTo(MntEmpleado::class, 'id_empleado');
    }

    public function establecimiento()
    {
        return $this->belongsTo(CtlEstablecimiento::class, 'id_establecimiento');
    }

    public function reaccionesAdversas()
    {
        return $this->hasMany(SecReaccionAdversa::class, 'id_usuario_registra');
    }

    public function esavi()
    {
        return $this->hasMany(SecEsavi::class, 'id_usuario_registra');
    }

}
