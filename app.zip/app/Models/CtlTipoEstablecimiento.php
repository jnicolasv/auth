<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CtlTipoEstablecimiento extends Model
{
    use HasFactory;

    // Tabla asociada
    protected $table = 'ctl_tipo_establecimiento';

    // Campos que pueden ser rellenados de forma masiva
    protected $fillable = [
        'nombre',
        'codigo',
        'id_institucion',
    ];

    // Relación con la tabla ctl_institucion
    public function institucion()
    {
        return $this->belongsTo(CtlInstitucion::class, 'id_institucion');
    }

    // Relación con la tabla ctl_establecimiento
    public function establecimientos()
    {
        return $this->hasMany(CtlEstablecimiento::class, 'id_tipo_establecimiento');
    }
}
