<?php

namespace App\Http\Controllers\web;

use App\Http\Controllers\Controller;
use App\Models\MntPersona;
use App\Models\SecReaccionAdversa;
use App\Models\User;
use Illuminate\Http\Request;
use Spatie\Permission\Models\Role;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class ReportController extends Controller
{
    public function reportesPendientes(Request $request)
    {
        // Usuario en sesion
        $userAuth = Auth::user();
        $roleAuth = $userAuth->roles->first()->name;

        $query = DB::table('sec_reaccion_adversa as sra')
            ->select(
            'sra.id',
            'ctr.codigo as tipo_reaccion',
            'ce.nombre as establecimiento',
            DB::raw("CONCAT(me.nombre, ' ', me.apellido) AS medico"),
            DB::raw("CONCAT(mp.primer_nombre, ' ', mp.segundo_nombre, ' ', mp.primer_apellido, ' ', mp.segundo_apellido) AS paciente"),
            'sra.fecha_notificacion'
            )
            ->leftJoin('ctl_ra_tipo_reaccion as ctr', 'sra.id_tipo_reaccion', '=', 'ctr.id')
            ->leftJoin('ctl_establecimiento as ce', 'sra.id_establecimiento', '=', 'ce.id')
            ->leftJoin('mnt_empleado as me', 'sra.id_empleado', '=', 'me.id')
            ->leftJoin('mnt_paciente as mp', 'sra.id_paciente', '=', 'mp.id')
            ->where('sra.estado_verificacion', '=', 'Pendiente')
            ->whereNotExists(function ($query) use ($userAuth) {
            $query->select(DB::raw(1))
                ->from('sec_reaccion_revision as srr')
                ->whereRaw('srr.reaccion_adversa_id = sra.id')
                ->where('srr.usuario_id', '=', $userAuth->id)
                ->where('srr.estado_revision', '=', 'Aprobado');
            });
        
        // Filtro por nombre de establecimiento
        if ($request->has('nombre_establecimiento')) {
            $query->where('ce.nombre', 'like', '%' . $request->nombre_establecimiento . '%');
        }

        // Filtro por tipo de reaccion
        if ($request->has('tipo_reaccion')) {
            $query->where('ctr.codigo', '=', $request->tipo_reaccion);
        }

        // Filtro por rango de fechas
        if ($request->has('fecha_rango') && $request->fecha_rango != '') {
            $fechas = explode(' a ', $request->fecha_rango);
            $fecha_desde = date('Y-m-d', strtotime($fechas[0]));
            $fecha_hasta = date('Y-m-d', strtotime($fechas[1]));
            $query->whereBetween('sra.fecha_notificacion', [$fecha_desde, $fecha_hasta]);
        }

        // Paginación con 10 usuarios por página
        $reacciones = $query->paginate(10);

        $reaccionesPendientes = DB::table('sec_reaccion_adversa as sra')
            ->where('sra.estado_verificacion', 'Pendiente')
            ->get();

        $cantidad_pendientes = $reaccionesPendientes->count();
        // dd($cantidad_pendientes);

        $cantidad_sibasi = DB::table('sec_reaccion_adversa as sra')
            ->where('sra.estado_verificacion', 'Pendiente')
            ->whereExists(function ($query) {
                $query->select(DB::raw(1))
                    ->from('sec_reaccion_revision as srr')
                    ->join('model_has_roles as mhr', 'srr.usuario_id', '=', 'mhr.model_id')
                    ->join('roles as r', 'mhr.role_id', '=', 'r.id')
                    ->where('r.name', '=', 'Sibasi')
                    ->whereRaw('srr.reaccion_adversa_id = sra.id');
            })->count();
        // dd($cantidad_sibasi);

        $cantidad_region = DB::table('sec_reaccion_adversa as sra')
            ->where('sra.estado_verificacion', 'Pendiente')
            ->whereExists(function ($query) {
                $query->select(DB::raw(1))
                    ->from('sec_reaccion_revision as srr')
                    ->join('model_has_roles as mhr', 'srr.usuario_id', '=', 'mhr.model_id')
                    ->join('roles as r', 'mhr.role_id', '=', 'r.id')
                    ->where('r.name', '=', 'Región')
                    ->whereRaw('srr.reaccion_adversa_id = sra.id');
            })->count();
        // dd($cantidad_region);

        $cantidad_pendientes_region = $cantidad_pendientes - $cantidad_region;
        $cantidad_pendientes_sibasi = $cantidad_pendientes - $cantidad_sibasi;

        $tipos_reaccion = DB::table('ctl_ra_tipo_reaccion')->pluck('codigo');
        // dd($tipos_reaccion);

        return view('reportes.pendientes', [
            'reacciones' => $reacciones,
            'cantidad_pendientes' => $cantidad_pendientes,
            'cantidad_pendientes_region' => $cantidad_pendientes_region,
            'cantidad_pendientes_sibasi' => $cantidad_pendientes_sibasi,
            'tipos_reaccion' => $tipos_reaccion,
            'filters' => $request->only('nombre_establecimiento', 'tipo_reaccion', 'fecha_rango'),
        ]);
    }

    public function reportesValidados(Request $request)
    {
        // Usuario en sesion
        $userAuth = Auth::user();
        $roleAuth = $userAuth->roles->first()->name;

        $query = DB::table('sec_reaccion_adversa as sra')
            ->select(
            'sra.id',
            'sra.estado_verificacion',
            'ctr.codigo as tipo_reaccion',
            'ce.nombre as establecimiento',
            DB::raw("CONCAT(me.nombre, ' ', me.apellido) AS medico"),
            DB::raw("CONCAT(mp.primer_nombre, ' ', mp.segundo_nombre, ' ', mp.primer_apellido, ' ', mp.segundo_apellido) AS paciente"),
            'sra.fecha_notificacion'
            )
            ->leftJoin('ctl_ra_tipo_reaccion as ctr', 'sra.id_tipo_reaccion', '=', 'ctr.id')
            ->leftJoin('ctl_establecimiento as ce', 'sra.id_establecimiento', '=', 'ce.id')
            ->leftJoin('mnt_empleado as me', 'sra.id_empleado', '=', 'me.id')
            ->leftJoin('mnt_paciente as mp', 'sra.id_paciente', '=', 'mp.id')
            ->whereIn('sra.estado_verificacion', ['Aprobado', 'Rechazado']);
        
        // Filtro por nombre de establecimiento
        if ($request->has('nombre_establecimiento')) {
            $query->where('ce.nombre', 'like', '%' . $request->nombre_establecimiento . '%');
        }

        // Filtro por estado de verificación
        if ($request->has('estado')) {
            $query->where('sra.estado_verificacion', '=', $request->estado);
        }

        // Filtro por tipo de reaccion
        if ($request->has('tipo_reaccion')) {
            $query->where('ctr.codigo', '=', $request->tipo_reaccion);
        }

        // Filtro por rango de fechas
        if ($request->has('fecha_rango') && $request->fecha_rango != '') {
            $fechas = explode(' a ', $request->fecha_rango);
            $fecha_desde = date('Y-m-d', strtotime($fechas[0]));
            $fecha_hasta = date('Y-m-d', strtotime($fechas[1]));
            $query->whereBetween('sra.fecha_notificacion', [$fecha_desde, $fecha_hasta]);
        }

        // Paginación con 10 usuarios por página
        $reacciones = $query->paginate(10);

        $tipos_reaccion = DB::table('ctl_ra_tipo_reaccion')->pluck('codigo');
        // dd($tipos_reaccion);

        return view('reportes.validados', [
            'reacciones' => $reacciones,
            'tipos_reaccion' => $tipos_reaccion,
            'filters' => $request->only('nombre_establecimiento', 'estado', 'tipo_reaccion', 'fecha_rango'),
        ]);
    }

    public function verificarReporte($id)
    {
        $reaccion = SecReaccionAdversa::with([
            'formaDetectarCaso:id,nombre',
            'tipoEvento:id,nombre',
            'tipoReaccion:id,codigo',
            'establecimiento:id,nombre',
            'profesion:id,nombre',
            'sexo:id,nombre',
            'empleado:id,nombre,apellido,numero_celular,correo_electronico,id_establecimiento',
            'empleado.establecimiento:id,nombre',
            'paciente:id,primer_nombre,segundo_nombre,primer_apellido,segundo_apellido',
            'esavi:id,id_reaccion_adversa,id_clasificacion_notificador,fecha_resolucion_evento,fecha_inicio_esavi',
        ])
        ->select([
            'id',
            'id_forma_detectar_caso',
            'id_tipo_evento',
            'id_tipo_reaccion',
            'id_establecimiento',
            'id_profesion',
            'id_sexo',
            'id_empleado',
            'id_paciente',
            'titulo_reporte',
            'fecha_notificacion',
            'forma_detectar_especifique',
            'paciente_grave',
            'peso',
            'talla',
            'embarazo',
            'lactando',
            'semana_gestacional',
            'edad_lactante',
            'responsable',
            'fecha_deteccion',
            'fecha_ingreso',
            'antecedentes',
            'otros_antecedentes',
            'estado_verificacion',
            'created_at'
        ])
        ->where('id', $id)
        ->first();
        
        // Obtener quien ha hecho revisiones al reporte
        /*$revisiones = DB::table('sec_reaccion_revision as srr')
            ->join('model_has_roles as mhr', 'srr.usuario_id', '=', 'mhr.model_id')
            ->join('roles as r', 'mhr.role_id', '=', 'r.id')
            ->select('r.name as role')
            ->where('srr.reaccion_adversa_id', $id)
            ->pluck('role');*/

        $revisiones = DB::table('sec_reaccion_revision as srr')
            ->join('users as u', 'srr.usuario_id', '=', 'u.id') // Relación con users
            ->join('mnt_persona as mp', 'u.id', '=', 'mp.usuario_id') // Relación con mnt_persona
            ->join('model_has_roles as mhr', 'srr.usuario_id', '=', 'mhr.model_id') // Relación con roles
            ->join('roles as r', 'mhr.role_id', '=', 'r.id') // Obtener el rol
            ->select('r.name as role', 'mp.primer_nombre', 'mp.primer_apellido') // Datos a obtener
            ->where('srr.reaccion_adversa_id', $id)
            ->get();

        return view('reportes.verificar', [
            'reaccion' => $reaccion,
            'revisiones' => $revisiones,
        ]);
    }

    public function aprobarReporte($id)
    {
        $userAuth = Auth::user();
        $roleAuth = $userAuth->roles->first()->name;

        // Comprobar si el usuario tiene permisos para aprobar reportes
        if (!in_array($roleAuth, ['Región', 'Sibasi'])) {
            return redirect()->back()->with('warning', 'No tiene permiso para aprobar este reporte.');
        }

        $reaccion = SecReaccionAdversa::find($id);

        if (!$reaccion) {
            return redirect()->back()->with('error', 'Reporte no encontrado.');
        }

        if ($reaccion->estado_verificacion == 'Aprobado') {
            return redirect()->back()->with('info', 'El reporte ya ha sido aprobado.');
        }

        $aprobaciones = DB::table('sec_reaccion_revision')
            ->where('reaccion_adversa_id', $id)
            ->where('estado_revision', 'Aprobado')
            ->pluck('usuario_id');

        $aprobadoPorRegion = DB::table('model_has_roles')
            ->whereIn('model_id', $aprobaciones)
            ->where('role_id', Role::where('name', 'Región')->first()->id)
            ->exists();

        $aprobadoPorSibasi = DB::table('model_has_roles')
            ->whereIn('model_id', $aprobaciones)
            ->where('role_id', Role::where('name', 'Sibasi')->first()->id)
            ->exists();

        if (($roleAuth == 'Región' && $aprobadoPorRegion) || ($roleAuth == 'Sibasi' && $aprobadoPorSibasi)) {
            return redirect()->back()->with('error', 'Ya ha aprobado este reporte.');
        }

        DB::beginTransaction();
        try {
            DB::table('sec_reaccion_revision')->insert([
                'reaccion_adversa_id' => $id,
                'usuario_id' => Auth::id(),
                'fecha_revision' => now(),
                'estado_revision' => 'Aprobado'
            ]);

            if ($aprobadoPorRegion && $roleAuth == 'Sibasi' || $aprobadoPorSibasi && $roleAuth == 'Región') {
                $reaccion->estado_verificacion = 'Aprobado';
                $reaccion->save();
            }

            DB::commit();
            return redirect()->back()->with('success', 'Reporte aprobado exitosamente.');
        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->back()->with('error', $e->getMessage());
        }
    }

    public function rechazarReporte($id)
    {
        $userAuth = Auth::user();
        $roleAuth = $userAuth->roles->first()->name;

        // Comprobar si el usuario tiene permisos para rechazar reportes
        if (!in_array($roleAuth, ['Región', 'Sibasi'])) {
            return redirect()->back()->with('warning', 'No tiene permiso para rechazar este reporte.');
        }

        $reaccion = SecReaccionAdversa::find($id);

        if (!$reaccion) {
            return redirect()->back()->with('error', 'Reporte no encontrado.');
        }

        if ($reaccion->estado_verificacion == 'Rechazado') {
            return redirect()->back()->with('info', 'El reporte ya ha sido rechazado.');
        }

        DB::beginTransaction();
        try {
            $reaccion->estado_verificacion = 'Rechazado';
            $reaccion->save();

            DB::table('sec_reaccion_revision')->insert([
                'reaccion_adversa_id' => $id,
                'usuario_id' => Auth::id(),
                'fecha_revision' => now(),
                'estado_revision' => 'Rechazado',
                'observaciones' => request()->motivo_rechazo
            ]);

            DB::commit();
            return redirect()->back()->with('success', 'Reporte rechazado exitosamente.');
        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->back()->with('error', $e->getMessage());
        }
    }
}
