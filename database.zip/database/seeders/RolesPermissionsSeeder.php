<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;

class RolesPermissionsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Eliminar todos los usuarios
        DB::table('users')->truncate();
        DB::table('mnt_persona')->truncate();

        // Insertar usuarios en la base de datos
        DB::table('users')->insert([
            [
                'id' => 1,
                'name' => 'sadmin',
                'email' => 'cristian.hrnandezh@salud.gob.sv',
                'email_verified_at' => null,
                'password' => bcrypt('4dm1n1str4d0r_Ap!'),
                'remember_token' => null,
                'created_at' => '2024-10-28 19:48:10.000',
                'updated_at' => '2025-01-07 20:40:37.000',
                'status' => true,
            ],
            [
                'id' => 2,
                'name' => 'userApi',
                'email' => 'user.apireacciones@salud.gob.sv',
                'email_verified_at' => null,
                'password' => bcrypt('Us3r_4p!'),
                'remember_token' => null,
                'created_at' => '2024-10-28 19:48:10.000',
                'updated_at' => '2024-10-28 19:48:10.000',
                'status' => true,
            ],
            [
                'id' => 3,
                'name' => 'admin',
                'email' => 'jperez@salud.gob.sv',
                'email_verified_at' => null,
                'password' => bcrypt('Us3r_g3n3r4l'),
                'remember_token' => null,
                'created_at' => '2025-01-06 21:17:38.000',
                'updated_at' => '2025-01-07 20:44:13.000',
                'status' => true,
            ],
            [
                'id' => 4,
                'name' => 'svelasco',
                'email' => 'svelasco@salud.gob.sv',
                'email_verified_at' => null,
                'password' => bcrypt('Us3r_g3n3r4l'),
                'remember_token' => null,
                'created_at' => '2025-01-07 17:32:27.000',
                'updated_at' => '2025-01-08 21:24:37.000',
                'status' => true,
            ],
            [
                'id' => 5, // Región
                'name' => 'esanchez',
                'email' => 'esanchez@salud.gob.sv',
                'email_verified_at' => null,
                'password' => bcrypt('Us3r_g3n3r4l'),
                'remember_token' => null,
                'created_at' => '2025-01-07 17:33:31.000',
                'updated_at' => '2025-01-07 17:33:31.000',
                'status' => true,
            ],
            [
                'id' => 6, // Sibasi
                'name' => 'emedrano',
                'email' => 'emedrano@salud.gob.sv',
                'email_verified_at' => null,
                'password' => bcrypt('Us3r_g3n3r4l'),
                'remember_token' => null,
                'created_at' => '2025-01-07 21:08:58.000',
                'updated_at' => '2025-01-07 21:08:58.000',
                'status' => true,
            ],
        ]);

        DB::table('mnt_persona')->insert([
            [
                'id' => 1,
                'primer_nombre' => 'Cristian',
                'segundo_nombre' => 'Ismael',
                'tercer_nombre' => null,
                'primer_apellido' => 'Hernandez',
                'segundo_apellido' => null,
                'fecha_nacimiento' => '2000-05-05',
                'nro_documento' => '23456',
                'establecimiento_id' => null,
                'usuario_id' => 1,
                'created_at' => null,
                'updated_at' => null,
            ],
            [
                'id' => 3,
                'primer_nombre' => 'Juan',
                'segundo_nombre' => 'Camilo',
                'tercer_nombre' => null,
                'primer_apellido' => 'Perez',
                'segundo_apellido' => 'Castro',
                'fecha_nacimiento' => '2000-05-05',
                'nro_documento' => '123456',
                'establecimiento_id' => null,
                'usuario_id' => 3,
                'created_at' => '2025-01-06 21:17:38.000',
                'updated_at' => '2025-01-07 17:47:21.000',
            ],
            [
                'id' => 4,
                'primer_nombre' => 'Sofia',
                'segundo_nombre' => 'Alejandra',
                'tercer_nombre' => null,
                'primer_apellido' => 'Velasco',
                'segundo_apellido' => 'Carballo',
                'fecha_nacimiento' => '2001-05-05',
                'nro_documento' => '85085',
                'establecimiento_id' => null,
                'usuario_id' => 4,
                'created_at' => '2025-01-07 17:32:27.000',
                'updated_at' => '2025-01-07 17:32:27.000',
            ],
            [
                'id' => 5, // Región
                'primer_nombre' => 'Eulises',
                'segundo_nombre' => 'Fernando',
                'tercer_nombre' => null,
                'primer_apellido' => 'Sanchez',
                'segundo_apellido' => 'Solorzano',
                'fecha_nacimiento' => '1995-05-05',
                'nro_documento' => '746154',
                'establecimiento_id' => 3, // (3-Región Metropolitana)
                'usuario_id' => 5,
                'created_at' => '2025-01-07 17:33:31.000',
                'updated_at' => '2025-01-07 17:33:31.000',
            ],
            [
                'id' => 6, // Sibasi
                'primer_nombre' => 'Erica',
                'segundo_nombre' => 'Noemy',
                'tercer_nombre' => null,
                'primer_apellido' => 'Medrano',
                'segundo_apellido' => 'Munguia',
                'fecha_nacimiento' => '1998-02-02',
                'nro_documento' => '232323',
                'establecimiento_id' => 10, // (10-Sibasi La Libertad)
                'usuario_id' => 6,
                'created_at' => '2025-01-07 21:08:58.000',
                'updated_at' => '2025-01-07 21:08:58.000',
            ],
        ]);
        
        User::all()->each(function ($user) {
            $user->syncRoles([]); // Elimina todos los roles asignados al usuario
            $user->syncPermissions([]); // Elimina todos los permisos asignados al usuario
        });

        // Eliminar todos los roles y permisos
        Role::truncate(); // Limpia la tabla de roles
        Permission::truncate(); // Limpia la tabla de permisos

        // Crear nuevos permisos
        $permissions = [
            'Crear usuarios',
            'Ver usuarios',
            'Editar usuarios',
            'Eliminar usuarios',
            'Cambiar estado de usuario',
            'Crear roles',
            'Ver roles',
            'Editar roles',
            'Eliminar roles',
            'Crear permisos',
            'Ver permisos',
            'Editar permisos',
            'Eliminar permisos',
            'Asignar permisos',
            'Ver reportes pendientes',
            'Ver detalle reportes pendientes',
            'Ver reportes validados',
            'Ver detalle reportes validados',
            'Aprobar reporte',
            'Rechazar reporte',
        ];

        foreach ($permissions as $permission) {
            Permission::firstOrCreate(['name' => $permission, 'guard_name' => 'web']);
        }        

        // Crear nuevos roles
        $roles = [
            'Superadmin',
            'Administrador',
            'DIRTECS',
            'Región',
            'Sibasi',
        ];

        foreach ($roles as $role) {
            $roleInstance = Role::create(['name' => $role]);

            // Asignar permisos a los roles
            if ($role == 'Superadmin') {
                $roleInstance->givePermissionTo(Permission::all());
            } elseif ($role == 'Administrador') {
                $roleInstance->givePermissionTo([
                    'Crear usuarios', 
                    'Ver usuarios', 
                    'Editar usuarios', 
                    'Eliminar usuarios', 
                    'Cambiar estado de usuario', 
                    'Ver roles', 
                    'Ver permisos', 
                    'Ver reportes pendientes',
                    'Ver detalle reportes pendientes',
                    'Ver reportes validados',
                    'Ver detalle reportes validados'
                ]);
            } elseif ($role == 'DIRTECS') {
                $roleInstance->givePermissionTo([
                    'Crear usuarios', 
                    'Ver usuarios', 
                    'Editar usuarios', 
                    'Cambiar estado de usuario',
                    'Ver reportes validados'
                ]);
            } elseif ($role == 'Región') {
                $roleInstance->givePermissionTo([
                    'Ver reportes pendientes',
                    'Ver detalle reportes pendientes',
                    'Ver reportes validados',
                    'Ver detalle reportes validados',
                    'Aprobar reporte',
                    'Rechazar reporte'
                ]);
            } elseif ($role == 'Sibasi') {
                $roleInstance->givePermissionTo([
                    'Ver reportes pendientes',
                    'Ver detalle reportes pendientes',
                    'Ver reportes validados',
                    'Ver detalle reportes validados',
                    'Aprobar reporte',
                    'Rechazar reporte'
                ]);
            }
        }

        // Asignar un rol a un usuario específico
        $userSuperadmin = User::find(1); // Busca el usuario con ID 1
        if ($userSuperadmin) { // Verifica si el usuario existe
            $userSuperadmin->assignRole('Superadmin'); // Asigna el rol de 'Superadmin'
        }
        $userAdmin = User::find(3); // Busca el usuario con ID 3
        if ($userAdmin) { // Verifica si el usuario existe
            $userAdmin->assignRole('Administrador'); // Asigna el rol de 'Administrador'
        }
        $userDIRTECS = User::find(4); // Busca el usuario con ID 4
        if ($userDIRTECS) { // Verifica si el usuario existe
            $userDIRTECS->assignRole('DIRTECS'); // Asigna el rol de 'DIRTECS'
        }
        $userRegión = User::find(5); // Busca el usuario con ID 5
        if ($userRegión) { // Verifica si el usuario existe
            $userRegión->assignRole('Región'); // Asigna el rol de 'Región'
        }
        $userSibasi = User::find(6); // Busca el usuario con ID 6
        if ($userSibasi) { // Verifica si el usuario existe
            $userSibasi->assignRole('Sibasi'); // Asigna el rol de 'Sibasi'
        }
    }
}
