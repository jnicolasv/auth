<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CtlRaSospechaMedicamento extends Model
{
    use HasFactory;

    protected $table = 'ctl_ra_sospecha_medicamento';

    protected $fillable = [
        'nombre_corto',
        'nombre',
        'descripcion',
        'activo',
    ];

    // Relaciones
    public function vacunasConcomitantes()
    {
        return $this->hasMany(MntRaVacunasConcomitantes::class, 'id_tipo_vacuna');
    }

    public function vacunasSospechosas()
    {
        return $this->hasMany(SecVacunaSospechosaEsavi::class, 'id_tipo_vacuna');
    }
}
