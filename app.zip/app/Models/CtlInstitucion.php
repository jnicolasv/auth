<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CtlInstitucion extends Model
{
    use HasFactory;

    // Tabla asociada
    protected $table = 'ctl_institucion';

    // Campos que pueden ser rellenados de forma masiva
    protected $fillable = [
        'nombre',
        'id_pais',
        'logo',
        'rectora',
        'categoria',
        'sigla',
        'estado',
        'color',
    ];

    // Relación con la tabla ctl_pais
    public function pais()
    {
        return $this->belongsTo(CtlPais::class, 'id_pais');
    }
}
