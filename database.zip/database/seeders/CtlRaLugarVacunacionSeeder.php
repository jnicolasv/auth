<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CtlRaLugarVacunacionSeeder extends Seeder
{
    public function run()
    {
        DB::table('ctl_ra_lugar_vacunacion')->insert([
            [
                'nombre_corto' => 'H',
                'nombre' => 'Hospital',
                'descripcion' => null,
                'activo' => true,
            ],
            [
                'nombre_corto' => 'US',
                'nombre' => 'Unidad de Salud',
                'descripcion' => null,
                'activo' => true,
            ],
            [
                'nombre_corto' => 'CP',
                'nombre' => 'Clínica Privada',
                'descripcion' => null,
                'activo' => true,
            ],
            [
                'nombre_corto' => 'PV',
                'nombre' => 'Puesto de Vacunación',
                'descripcion' => null,
                'activo' => true,
            ],
            [
                'nombre_corto' => 'D',
                'nombre' => 'Domicilio',
                'descripcion' => null,
                'activo' => true,
            ],
        ]);
    }
}
