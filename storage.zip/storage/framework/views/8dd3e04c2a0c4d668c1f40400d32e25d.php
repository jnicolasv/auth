<?php if($paginator->hasPages()): ?>
    <nav role="navigation" aria-label="Pagination" class="flex items-center justify-between flex-wrap">
        <!-- Conteo de Registros -->
        <div class="flex-1 text-sm text-gray-700 mb-4 sm:mb-0">
            <p>
                Mostrando <?php echo e($paginator->firstItem()); ?> a <?php echo e($paginator->lastItem()); ?> de <?php echo e($paginator->total()); ?> registros.
            </p>
        </div>

        <!-- Contenedor de los botones de navegación -->
        <div class="flex items-center space-x-1">
            <!-- Página Anterior -->
            <?php if($paginator->onFirstPage()): ?>
                <span class="relative inline-flex items-center px-4 py-2 text-sm font-medium text-gray-500 bg-gray-200 border border-white rounded-l-md">
                    Anterior
                </span>
            <?php else: ?>
                <a href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev" class="relative inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-[#576ca9] border border-white rounded-l-md hover:bg-[#435a77] focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 focus:ring-offset-gray-100">
                    Anterior
                </a>
            <?php endif; ?>

            <!-- Enlaces de Página -->
            <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- Si es un enlace simple -->
                <?php if(is_string($element)): ?>
                    <span class="text-gray-500">...</span>
                <?php endif; ?>

                <!-- Si son enlaces de páginas -->
                <?php if(is_array($element)): ?>
                    <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($page == $paginator->currentPage()): ?>
                            <span class="z-10 inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-[#576ca9] border border-white"><?php echo e($page); ?></span>
                        <?php else: ?>
                            <a href="<?php echo e($url); ?>" class="inline-flex items-center px-4 py-2 text-sm font-medium text-gray-500 bg-gray-100 border border-white hover:bg-gray-200"><?php echo e($page); ?></a>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <!-- Página Siguiente -->
            <?php if($paginator->hasMorePages()): ?>
                <a href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next" class="relative inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-[#576ca9] border border-white rounded-r-md hover:bg-[#435a77] focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 focus:ring-offset-gray-100">
                    Siguiente
                </a>
            <?php else: ?>
                <span class="relative inline-flex items-center px-4 py-2 text-sm font-medium text-gray-500 bg-gray-200 border border-white rounded-r-md">
                    Siguiente
                </span>
            <?php endif; ?>
        </div>
    </nav>
<?php endif; ?><?php /**PATH /var/www/html/resources/views/vendor/pagination/tailwind.blade.php ENDPATH**/ ?>