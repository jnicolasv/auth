<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('mnt_ra_detalle_medicamento', function (Blueprint $table) {
            $table->id();

            $table->unsignedBigInteger('id_medicamento');
            $table->string('nombre_generico', 100);
            $table->string('forma_farmaceutica', 100);
            $table->string('nombre_comercial', 100);
            $table->string('laboratorio_fabricante', 100);
            $table->string('concentracion', 100);
            $table->string('presentacion', 128);
            $table->string('registro_sanitario', 20);
            $table->string('lote', 10);
            $table->string('vencimiento', 7);
            $table->unsignedBigInteger('id_usuario_registra')->nullable();
            $table->unsignedBigInteger('id_usuario_modifica')->nullable();
            $table->timestamp('fecha_hora_registra')->nullable();
            $table->timestamp('fecha_hora_modifica')->nullable();

            // Claves foráneas después de los campos
            $table->foreign('id_medicamento')->references('id')->on('mnt_ra_medicamento')->onUpdate('cascade')->onDelete('restrict');
            $table->foreign('id_usuario_registra')->references('id')->on('fos_user_user')->onUpdate('cascade')->onDelete('restrict');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('mnt_ra_detalle_medicamento');
    }
};
