<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('mnt_expediente', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('id_sis');
            $table->string('numero', 13); // Campo número (obligatorio)
            $table->unsignedBigInteger('id_paciente');
            $table->unsignedInteger('id_establecimiento')->nullable();
            $table->boolean('habilitado')->default(true); // Campo habilitado (default true)
            $table->unsignedInteger('id_creacion_expediente')->nullable();
            $table->date('fecha_creacion')->nullable();
            $table->time('hora_creacion')->nullable();
            $table->boolean('numero_temporal')->default(false);
            $table->boolean('expediente_fisico_eliminado')->default(false);
            $table->boolean('cun')->default(false);
            $table->boolean('uso_temporal')->default(false);
            $table->text('carpeta_familiar')->nullable();
            $table->unsignedInteger('id_establecimiento_origen')->nullable();
            $table->boolean('historial_neonato')->nullable();
            $table->unsignedInteger('id_expediente_madre')->nullable();
            $table->boolean('nui')->nullable();

            // Llaves foráneas
            $table->foreign('id_paciente')->references('id')->on('mnt_paciente');
            $table->foreign('id_establecimiento')->references('id')->on('ctl_establecimiento');
            $table->foreign('id_creacion_expediente')->references('id')->on('ctl_creacion_expediente');
            $table->foreign('id_establecimiento_origen')->references('id')->on('ctl_establecimiento')->onDelete('restrict')->onUpdate('cascade');
            $table->foreign('id_expediente_madre')->references('id')->on('mnt_expediente')->onDelete('restrict')->onUpdate('cascade');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('mnt_expediente');
    }
};
