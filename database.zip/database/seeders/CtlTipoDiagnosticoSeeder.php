<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CtlTipoDiagnosticoSeeder extends Seeder
{
    public function run()
    {
        DB::table('ctl_tipo_diagnostico')->insert([
            [
                'nombre' => 'Principal',
            ],
            [
                'nombre' => 'Secundario',
            ],
            [
                'nombre' => 'Causa Externa',
            ],
            [
                'nombre' => 'Complementario',
            ],
        ]);
    }
}
