<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CtlRaFormaDetectarCasoSeeder extends Seeder
{
    public function run()
    {
        DB::table('ctl_ra_forma_detectar_caso')->insert([
            [
                'nombre_corto' => 'NOTESP',
                'nombre' => 'Notificación espontánea',
                'descripcion' => null,
                'activo' => true,
            ],
            [
                'nombre_corto' => 'BUSQACT',
                'nombre' => 'Búsqueda activa',
                'descripcion' => null,
                'activo' => true,
            ],
            [
                'nombre_corto' => 'RUM',
                'nombre' => 'Rumor',
                'descripcion' => null,
                'activo' => true,
            ],
            [
                'nombre_corto' => 'NOTI',
                'nombre' => 'Noticia',
                'descripcion' => null,
                'activo' => true,
            ],
            [
                'nombre_corto' => 'COMEN',
                'nombre' => 'Comentario',
                'descripcion' => null,
                'activo' => true,
            ],
            [
                'nombre_corto' => 'ESTU',
                'nombre' => 'Estudio',
                'descripcion' => null,
                'activo' => true,
            ],
            [
                'nombre_corto' => 'OTR',
                'nombre' => 'Otro',
                'descripcion' => null,
                'activo' => true,
            ],
        ]);
    }
}
