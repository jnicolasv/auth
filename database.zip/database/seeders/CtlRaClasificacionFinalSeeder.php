<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CtlRaClasificacionFinalSeeder extends Seeder
{
    public function run()
    {
        DB::table('ctl_ra_clasificacion_final')->insert([
            [
                'nombre_corto' => 'ERV',
                'nombre' => 'Evento relacionado con la vacuna',
                'descripcion' => null,
                'activo' => 'true',
            ],
            [
                'nombre_corto' => 'ECV',
                'nombre' => 'Evento coincidente con la vacuna',
                'descripcion' => null,
                'activo' => 'true',
            ],
            [
                'nombre_corto' => 'ENC',
                'nombre' => 'Evento no concluyente',
                'descripcion' => null,
                'activo' => 'true',
            ],
            [
                'nombre_corto' => 'RRAI',
                'nombre' => 'Reacción relacionada a ansiedad por inmunización',
                'descripcion' => null,
                'activo' => 'true',
            ],
            [
                'nombre_corto' => 'EP',
                'nombre' => 'Error programático',
                'descripcion' => null,
                'activo' => 'true',
            ],
        ]);
    }
}
