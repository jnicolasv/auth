<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CtlRaMarcoAplicacion extends Model
{
    use HasFactory;

    protected $table = 'ctl_ra_marco_aplicacion';

    protected $fillable = [
        'nombre_corto',
        'nombre',
        'descripcion',
        'activo',
    ];

    public function vacunaSospechosa()
    {
        return $this->hasMany(SecVacunaSospechosaEsavi::class, 'id_marco_aplicacion');
    }
}
