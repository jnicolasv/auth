<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CtlRegionCuerpo extends Model
{
    use HasFactory;

    protected $table = 'ctl_region_cuerpo';

    protected $fillable = [
        'nombre',
        'descripcion',
    ];

    // Relaciones
    public function vacunasConcomitantes()
    {
        return $this->hasMany(MntRaVacunasConcomitantes::class, 'id_region_cuerpo');
    }

    public function vacunaSospechosa()
    {
        return $this->hasMany(SecVacunaSospechosaEsavi::class, 'id_region_cuerpo');
    }
}
