<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MntRazonGravedad extends Model
{
    use HasFactory;

    // Especifica la tabla asociada al modelo
    protected $table = 'mnt_razon_gravedad';

    // Especifica los campos que se pueden asignar en masa
    protected $fillable = [
        'id_razon_gravedad',
        'id_reaccion_adversa',
    ];

    public function reaccionAdversa()
    {
        return $this->belongsTo(SecReaccionAdversa::class, 'id_reaccion_adversa');
    }

    public function razonGravedad()
    {
        return $this->belongsTo(CtlRaRazonGravedad::class, 'id_razon_gravedad');
    }
}
