@extends('layout-login')

@section('title', 'Login')

@section('content')
<form action="{{ route('login') }}" method="POST">
    @csrf
    
    <div class="relative mb-4">
        <label for="email" class="absolute -top-2 left-4 bg-white text-gray-700 text-sm px-1">Usuario o Correo Electrónico</label>
        <input
            type="text"
            id="login"
            name="login"
            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-300 focus:border-blue-500"
            placeholder=""
            value="{{ old('login') }}"
        >
    </div>
    
    <div class="relative mb-4">
        <label for="password" class="absolute -top-2 left-4 bg-white text-gray-700 text-sm px-1">Contraseña</label>
        <input
            type="password"
            id="password"
            name="password"
            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-300 focus:border-blue-500"
            placeholder=""
        >
    </div>

    @if (session('status'))
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
            <p class="text-sm">{{ session('status') }}</p>
        </div>
    @endif
    
    @if ($errors->any())
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
            @foreach ($errors->all() as $error)
                <p class="text-sm">{{ $error }}</p>
            @endforeach
        </div>
    @endif

    <button type="submit" class="w-full bg-[#576ca9] text-white font-bold py-3 rounded-lg hover:bg-[#4a5a8a]">
        INICIAR SESIÓN
    </button>
</form>
<div class="text-center mt-6">
    <span class="text-gray-700">¿Has olvidado tu contraseña?</span> <a href="{{ route('password.email') }}" id="btn_recuperar_contra" class="text-[#576ca9] hover:underline inline"> <strong>Recuperar Cuenta</strong></a>
</div>
@endsection