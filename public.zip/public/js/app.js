// Función para aplicar el estado del sidebar ANTES de que la página se renderice
function applySidebarStateBeforeRender() {
    const sidebarOpen = localStorage.getItem('sidebarOpen') === 'true';

    if (sidebarOpen) {
        document.body.classList.add('sidebar-open');
        // Asegurar que los títulos de los menús sean visibles al cargar la página
        document.querySelectorAll('.menu-item span:nth-child(2)').forEach(span => {
            span.style.display = 'inline-block';
            span.style.opacity = '1';
        });
        // Asegurar que el botón de cerrar esté visible
        document.getElementById('closeSidebar').classList.remove('hidden');
        document.getElementById('openSidebar').classList.add('hidden');
    } else {
        document.body.classList.remove('sidebar-open');
        // Asegurar que el botón de abrir esté visible
        document.getElementById('closeSidebar').classList.add('hidden');
        document.getElementById('openSidebar').classList.remove('hidden');
    }
}

// Ejecutar ANTES del renderizado de la página
applySidebarStateBeforeRender();

document.addEventListener('DOMContentLoaded', function() {
    applySidebarState();
});

// Función para aplicar el estado del sidebar después de cargar
function applySidebarState() {
    const sidebarOpen = localStorage.getItem('sidebarOpen') === 'true';
    const sidebar = document.getElementById('sidebar');
    const mainContent = document.getElementById('main-content');

    if (sidebarOpen) {
        sidebar.style.width = '330px';
        mainContent.style.marginLeft = '330px';
        document.body.classList.add('sidebar-open');
    } else {
        sidebar.style.width = '90px';
        mainContent.style.marginLeft = '90px';
        document.body.classList.remove('sidebar-open');
    }
}

// Función para abrir el sidebar
function openSidebar() {
    const sidebar = document.getElementById('sidebar');
    const mainContent = document.getElementById('main-content');

    sidebar.style.width = '330px';
    mainContent.style.marginLeft = '330px';
    document.getElementById('closeSidebar').classList.remove('hidden');
    document.getElementById('openSidebar').classList.add('hidden');

    document.body.classList.add('sidebar-open');
    localStorage.setItem('sidebarOpen', 'true');

    // Ocultar los títulos antes de iniciar la animación
    document.querySelectorAll('.menu-item span:nth-child(2)').forEach(span => {
        span.style.visibility = 'hidden'; 
        span.style.opacity = '0';
    });

    // Mostrar los títulos después de que el sidebar termine de expandirse (ajustar el tiempo si es necesario)
    // setTimeout(() => {
        document.querySelectorAll('.menu-item span:nth-child(2)').forEach(span => {
            span.style.visibility = 'visible';
            span.style.opacity = '1';
            span.style.display = 'inline-block';
        });
    // }, 300); // 300ms debe coincidir con la duración de la animación del sidebar
}

// Función para cerrar el sidebar
function closeSidebar() {
    const sidebar = document.getElementById('sidebar');
    const mainContent = document.getElementById('main-content');

    sidebar.style.width = '90px';
    mainContent.style.marginLeft = '90px';
    document.getElementById('closeSidebar').classList.add('hidden');
    document.getElementById('openSidebar').classList.remove('hidden');

    document.body.classList.remove('sidebar-open');
    localStorage.setItem('sidebarOpen', 'false');

    document.querySelectorAll('.menu-item span:nth-child(2)').forEach(span => {
        span.style.display = 'none';
    });
}



// Asigna los eventos a los botones de abrir y cerrar
document.getElementById('openSidebar').addEventListener('click', openSidebar);
document.getElementById('closeSidebar').addEventListener('click', closeSidebar);

// Evita que el sidebar se reinicie al hacer clic en una opción del menú
document.querySelectorAll('.menu-item a').forEach(link => {
    link.addEventListener('click', function(event) {
        // Evita que el enlace recargue la página (opcional, solo para SPAs)
        event.preventDefault();

        // Guarda la ruta a la que se debe navegar
        const targetUrl = link.href;

        // Navega a la nueva ruta después de un breve retraso (opcional)
        // setTimeout(() => {
            window.location.href = targetUrl;
        // }, 100); // Ajusta el tiempo según sea necesario
    });
});

document.getElementById('settingsButton').addEventListener('click', () => {
    const menu = document.getElementById('settingsMenu');
    menu.classList.toggle('hidden');
});


$(document).ready(function() {
    // Obtén la ruta actual
    var currentRoute = window.location.pathname;
    console.log("Ruta actual:", currentRoute);

    // Remueve la clase 'active' de todos los elementos del menú
    $('.menu-item').removeClass('active');

    // Agrega la clase 'active' al elemento del menú que coincide con la ruta actual
    $('.menu-item a').each(function() {
        // Obtén la ruta del enlace (sin el dominio)
        var linkRoute = new URL($(this).attr('href')).pathname;
        console.log("Ruta del enlace:", linkRoute);

        // Compara las rutas
        if (linkRoute === currentRoute) {
            $(this).parent().addClass('active');
        }
    });

    // Maneja el clic en los elementos del menú
    $('.menu-item a').on('click', function() {
        // Remueve la clase 'active' de todos los elementos del menú
        $('.menu-item').removeClass('active');

        // Agrega la clase 'active' al elemento clicado
        $(this).parent().addClass('active');
    });
});