<?php $__env->startSection('title', 'Recuperar Contraseña'); ?>

<?php $__env->startSection('content'); ?>
<form method="POST" action="<?php echo e(route('password.email')); ?>">
    <?php echo csrf_field(); ?>
    <div class="mb-5">
        <p class="text-gray-700 text-lg text-center font-bold">Restablecer contraseña</p>
        <p class="text-gray-600 text-md text-center">Ingresa tu correo para recibir instrucciones</p>
    </div>
    <div class="mt-10">
        <div class="input-container">
            <label for="email" class="input-label">Correo eléctronico</label>
            <input type="email" id="email" name="email" class="input-field" value="<?php echo e(old('name', $filters['name'] ?? '')); ?>">
        </div>
    </div>

    <div class="flex flex-wrap justify-center mt-5 gap-4 w-full mx-auto">
        <a href="<?php echo e(route('login')); ?>" class="btn-secondary flex-1 min-w-[150px]">
            Cancelar
        </a>
        <button type="submit" class="btn-primary flex-1 min-w-[150px]">
            Enviar
        </button>
    </div>
</form>

<?php if(session('status')): ?>
    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mt-4" role="alert">
        <p class="text-sm"><?php echo e(session('status')); ?></p>
    </div>
<?php endif; ?>

<?php if($errors->any()): ?>
    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mt-4" role="alert">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p class="text-sm"><?php echo e($error); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        document.getElementById('login').focus();
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout-login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/logins/password-email.blade.php ENDPATH**/ ?>