<?php

namespace Database\Seeders;

use App\Models\CtlMunicipio;
use App\Models\CtlNacionalidad;
use App\Models\CtlPais;
use App\Models\CtlRaAccionTomada;
use App\Models\CtlSexo;
use App\Models\User;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Contracts\Role;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([
            // CreateUsersSeeder::class,
            CtlPaisSeeder::class,
            CtlInstitucionSeeder::class,
            CtlTipoEstablecimientoSeeder::class,
            CtlEstablecimientoSeeder::class,
            RolesPermissionsSeeder::class,
            CtlCreacionExpedienteSeeder::class,
            CtlRaAccionTomadaSeeder::class,
            CtlRaClasificacionFinalSeeder::class,
            CtlRaClasificacionNotificadorSeeder::class,
            CtlRaCondicionDesenlaceSeeder::class,
            CtlRaFormaDetectarCasoSeeder::class,
            CtlRaLugarVacunacionSeeder::class,
            CtlRaMarcoAplicacionSeeder::class,
            CtlRaProfesionSeeder::class,
            CtlRaRazonGravedadSeeder::class,
            CtlRaRecursoVacunadorSeeder::class,
            CtlRaSospechaMedicamentoSeeder::class,
            CtlRaTipoEventoSeeder::class,
            CtlRaTipoReaccionSeeder::class,
            CtlRaViaDeAdministracionSeeder::class,
            CtlRegionCuerpoSeeder::class,
            CtlSexoSeeder::class,
            CtlDepartamentoSeeder::class,
            CtlMunicipio2023Seeder::class,
            CtlMunicipioSeeder::class,
            CtlTipoDiagnosticoSeeder::class,
            CtlEstadoCivilSeeder::class,
            CtlDocumentoIdentidadSeeder::class,
            CtlNacionalidadSeeder::class,
            CtlOcupacionSeeder::class,
            CtlTipoVacunaSeeder::class,
            CtlTipoConsultaSeeder::class,
            CtlVacunasSeeder::class,
            CtlCantonSeeder::class,
            FarmViaAdministracionSeeder::class,
            LabTipoMuestraSeeder::class,
            MntCie10Seeder::class,
            MntCie10SeederV2::class,
            MntCie10SeederV3::class,
            MntCie10SeederV4::class,
        ]);
    }
}
