<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('sec_reaccion_adversa', function (Blueprint $table) {
            $table->id();
            
            $table->unsignedBigInteger('id_forma_detectar_caso');
            $table->unsignedBigInteger('id_tipo_evento');
            $table->unsignedBigInteger('id_establecimiento');
            $table->unsignedBigInteger('id_profesion');
            $table->unsignedBigInteger('id_sexo');
            $table->unsignedBigInteger('id_condicion_desenlace');
            $table->integer('id_historial_clinico')->nullable(false);
            $table->unsignedBigInteger('id_empleado');
            $table->unsignedBigInteger('id_paciente');
            $table->timestamp('fecha_consulta');
            $table->string('especialidad_consulta', 200);
            $table->integer('numero_reporte');
            $table->string('titulo_reporte', 100);
            $table->timestamp('fecha_notificacion');
            $table->string('forma_detectar_especifique', 100)->nullable();
            $table->boolean('paciente_grave')->nullable();
            $table->decimal('peso', 8, 2);
            $table->decimal('talla', 8, 2);
            $table->boolean('embarazo')->nullable();
            $table->boolean('lactando')->nullable();
            $table->unsignedSmallInteger('semana_gestacional')->nullable();
            $table->unsignedSmallInteger('edad_lactante')->nullable();
            $table->string('responsable', 120)->nullable();
            $table->timestamp('fecha_deteccion');
            $table->timestamp('fecha_ingreso')->nullable();
            $table->text('antecedentes')->nullable();
            $table->text('otros_antecedentes')->nullable();
            $table->unsignedBigInteger('id_pais')->nullable();
            $table->unsignedBigInteger('id_tipo_reaccion')->nullable();
            $table->unsignedBigInteger('id_usuario_registra')->nullable();
            $table->string('estado_verificacion', 20)->default('Pendiente');
            // $table->unsignedBigInteger('id_usuario_modifica')->nullable();

            // Definición de llaves foráneas
            $table->foreign('id_forma_detectar_caso')->references('id')->on('ctl_ra_forma_detectar_caso')->onUpdate('cascade')->onDelete('restrict');
            $table->foreign('id_tipo_evento')->references('id')->on('ctl_ra_tipo_evento')->onUpdate('cascade')->onDelete('restrict');
            $table->foreign('id_establecimiento')->references('id')->on('ctl_establecimiento')->onUpdate('cascade')->onDelete('restrict');
            $table->foreign('id_profesion')->references('id')->on('ctl_ra_profesion')->onUpdate('cascade')->onDelete('restrict');
            $table->foreign('id_sexo')->references('id')->on('ctl_sexo')->onUpdate('cascade')->onDelete('restrict');
            $table->foreign('id_condicion_desenlace')->references('id')->on('ctl_ra_condicion_desenlace')->onUpdate('cascade')->onDelete('restrict');
            $table->foreign('id_empleado')->references('id')->on('mnt_empleado')->onUpdate('cascade')->onDelete('restrict');
            $table->foreign('id_paciente')->references('id')->on('mnt_paciente')->onUpdate('cascade')->onDelete('restrict');
            $table->foreign('id_pais')->references('id')->on('ctl_pais')->onUpdate('cascade')->onDelete('restrict');
            $table->foreign('id_tipo_reaccion')->references('id')->on('ctl_ra_tipo_reaccion')->onUpdate('cascade')->onDelete('restrict');
            $table->foreign('id_usuario_registra')->references('id')->on('fos_user_user')->onUpdate('cascade')->onDelete('restrict');
            // $table->foreign('id_usuario_modifica')->references('id')->on('fos_user_user')->onUpdate('cascade')->onDelete('restrict');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('sec_reaccion_adversa');
    }
};
