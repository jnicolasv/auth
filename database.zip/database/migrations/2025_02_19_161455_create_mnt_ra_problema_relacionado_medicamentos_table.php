<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('mnt_ra_problema_relacionado_medicamento', function (Blueprint $table) {
            $table->id();

            $table->unsignedBigInteger('id_ram')->nullable();
            $table->unsignedBigInteger('id_organo_afectado')->nullable();
            $table->string('codigo_snomed', 15)->nullable();
            $table->string('label_snomed', 250)->nullable();
            $table->timestamp('fecha_inicio')->nullable();
            $table->timestamp('fecha_fin')->nullable();
            $table->unsignedBigInteger('id_usuario_registra')->nullable();
            $table->timestamp('fecha_hora_registra')->nullable();
            $table->unsignedBigInteger('id_usuario_modifica')->nullable();
            $table->timestamp('fecha_hora_modifica')->nullable();

            // Claves foráneas
            $table->foreign('id_ram')->references('id')->on('sec_ram')->restrictOnDelete()->cascadeOnUpdate();
            $table->foreign('id_organo_afectado')->references('id')->on('ctl_ra_organo_afectado')->restrictOnDelete()->cascadeOnUpdate();
            $table->foreign('id_usuario_registra')->references('id')->on('fos_user_user')->restrictOnDelete()->cascadeOnUpdate();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('mnt_ra_problema_relacionado_medicamento');
    }
};
