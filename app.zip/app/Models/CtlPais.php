<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CtlPais extends Model
{
    use HasFactory;

    // Especifica la tabla asociada al modelo
    protected $table = 'ctl_pais';

    // Define los atributos que pueden ser asignados masivamente
    protected $fillable = [
        'nombre',
        'activo',
        'codigo_rnpn',
        'abreviacion_rnpn'
    ];

    // Relación con SecReaccionAdversa (uno a muchos)
    public function reaccionesAdversas()
    {
        return $this->hasMany(SecReaccionAdversa::class, 'id_pais');
    }

    // Relación con la tabla ctl_institucion (uno a muchos)
    public function instituciones()
    {
        return $this->hasMany(CtlInstitucion::class, 'id_pais');
    }

    // Relación con la tabla ctl_departamento (uno a muchos)
    public function departamentos()
    {
        return $this->hasMany(CtlDepartamento::class, 'id_pais');
    }
}
