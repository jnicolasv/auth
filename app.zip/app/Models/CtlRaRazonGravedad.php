<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CtlRaRazonGravedad extends Model
{
    use HasFactory;

    // Definir el nombre de la tabla (si es diferente al plural del modelo)
    protected $table = 'ctl_ra_razon_gravedad';

    protected $primaryKey = 'id';
    public $incrementing = true;
    protected $keyType = 'int';
    // public $timestamps = false;

    // Campos que se pueden asignar en masa (fillable)
    protected $fillable = [
        'nombre_corto',
        'nombre',
        'activo',
    ];

    // Relación con el modelo MntRazonGravedad (Uno a muchos)
    public function mntRazonGravedad()
    {
        return $this->hasMany(MntRazonGravedad::class, 'id_razon_gravedad');
    }
}
