<?php $__env->startSection('title', 'Ajustes'); ?>

<?php $__env->startSection('content'); ?>
<div class="p-6">
    <!-- Filters -->
    <div class="bg-white p-4 rounded shadow mb-4">
        <div class="border-2 border-[#576ca9] bg-[#edf3ff] p-2 rounded-2xl mb-4 text-center">
            <h2 class="text-xl font-semibold text-[#576ca9]">Ajustes del Sistema</h2>
        </div>
        
        <div class="subtitulo">
            <p class="text-lg font-semibold">Cambio de contraseña</p>
        </div>

        <!-- Formulario de cambio de contraseña -->
        <form id="change-password-form" class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-x-4 gap-y-6 mt-6">
            <?php echo csrf_field(); ?>
            <div class="input-container">
                <label for="actual_contra" class="input-label">Contraseña actual</label>
                <input type="password" id="actual_contra" name="actual_contra" class="input-field" autocomplete="off">
            </div>
            <div class="input-container">
                <label for="nueva_contra" class="input-label">Nueva contraseña</label>
                <input type="password" id="nueva_contra" name="nueva_contra" class="input-field" autocomplete="off">
            </div>
            <div class="input-container">
                <label for="nueva_contra_confirmation" class="input-label">Confirmar nueva contraseña</label>
                <input type="password" id="nueva_contra_confirmation" name="nueva_contra_confirmation" class="input-field" autocomplete="off">
            </div>
            <!-- Botón -->
            <div class="input-container">
                <button type="submit" class="input-button btn-primary">Cambiar contraseña</button>
            </div>
        </form>

        <!-- Mensajes de respuesta -->
        <div id="response-message" class="mt-4 hidden text-center"></div>

        <hr class="col-span-3 my-4 border-t border-[#576ca9]">
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function() {
        $('#change-password-form').on('submit', function(e) {
            e.preventDefault(); // Evita el envío del formulario por defecto

            let form = $(this);
            let formData = form.serialize();
            let responseMessage = $('#response-message');

            // Limpiar estilos de error previos
            $('.input-field').removeClass('border-red-500');
            responseMessage.addClass('hidden').empty();

            $.ajax({
                url: '<?php echo e(route("password.change")); ?>', // Asegúrate de definir esta ruta en web.php
                type: 'POST',
                data: formData,
                dataType: 'json',
                success: function(response) {
                    responseMessage.html(`
                        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mt-4" role="alert">
                            <p class="text-sm">${response.message}</p>
                        </div>
                    `).removeClass('hidden');

                    form.trigger('reset');
                },
                error: function(xhr) {
                    if (xhr.status === 422) { // Validaciones fallidas
                        let errors = xhr.responseJSON.errors;
                        let errorMessages = '';

                        // Resaltar inputs con errores y construir los mensajes
                        $.each(errors, function(key, messages) {
                            /*let inputField = $('[name="' + key + '"]'); // Seleccionar por name
                            inputField.css('border-color', '#ef4444'); // Aplicar borde rojo directamente*/
                            errorMessages += `<p class="text-sm">${messages[0]}</p>`; // Muestra solo el primer mensaje de cada campo
                        });

                        responseMessage.html(`
                            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mt-4" role="alert">
                                ${errorMessages}
                            </div>
                        `).removeClass('hidden');
                    } else {
                        responseMessage.html(`
                            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mt-4" role="alert">
                                <p class="text-sm">Ocurrió un error inesperado. Inténtalo de nuevo.</p>
                            </div>
                        `).removeClass('hidden');
                    }
                }
            });
        });
    });


</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/users/settings.blade.php ENDPATH**/ ?>