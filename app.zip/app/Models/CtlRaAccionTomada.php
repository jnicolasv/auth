<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CtlRaAccionTomada extends Model
{
    use HasFactory;

    protected $table = 'ctl_ra_accion_tomada';

    protected $fillable = [
        'nombre_corto',
        'nombre',
        'descripcion',
        'modulo',
        'activo',
    ];

    // Relación con SecEsavi (uno a muchos)
    public function esavi()
    {
        return $this->hasMany(SecEsavi::class, 'id_accion_tomada');
    }

    // Relacion con SecRam (uno a muchos)
    public function ram()
    {
        return $this->hasMany(SecRam::class, 'id_accion_tomada');
    }
}
