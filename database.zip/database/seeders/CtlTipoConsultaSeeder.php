<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CtlTipoConsultaSeeder extends Seeder
{
    public function run()
    {
        DB::table('ctl_tipo_consulta')->insert([
            [
                'nombre' => 'Primera Vez',
                'descripcion' => 'Indica una consulta o diagnostico de primera vez',
            ],
            [
                'nombre' => 'Subsecuente',
                'descripcion' => 'Indica una consulta o diagnostico subsecuente',
            ],
        ]);
    }
}
