<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CtlVacunas extends Model
{
    use HasFactory;

    protected $table = 'ctl_vacunas';

    protected $fillable = [
        'nombre',
        'codigo_vacuna',
        'habilitado',
        'tipo_vacuna',
        'aplicable_para',
        'idusuarioreg',
        'fechahorareg',
        'id_tipo_vacuna',
    ];

    // Relaciones
    public function tipoVacuna()
    {
        return $this->belongsTo(CtlTipoVacuna::class, 'id_tipo_vacuna');
    }

    public function usuarioRegistro()
    {
        return $this->belongsTo(FosUserUser::class, 'idusuarioreg');
    }

    public function vacunasSospechosas()
    {
        return $this->hasMany(SecVacunaSospechosaEsavi::class, 'id_vacuna');
    }

    public function secRaDiagnosticos()
    {
        return $this->hasMany(SecRaDiagnostico::class, 'id_tipo_diagnostico');
    }
}
