<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SecRaDiagnostico extends Model
{
    use HasFactory;

    protected $table = 'sec_ra_diagnostico';

    protected $fillable = [
        'id_esavi',
        'id_tipo_diagnostico',
        'id_cie10',
        'id_tipo_consulta',
        'id_vacuna',
        'especificacion',
        'confirmado',
        'presuntivo',
        'id_usuario_registra',
    ];

    // Relaciones con otras tablas
    public function esavi()
    {
        return $this->belongsTo(SecEsavi::class, 'id_esavi');
    }

    /*public function historialClinico()
    {
        return $this->belongsTo(SecHistorialClinico::class, 'id_historial_clinico');
    }*/

    public function tipoDiagnostico()
    {
        return $this->belongsTo(CtlTipoDiagnostico::class, 'id_tipo_diagnostico');
    }

    public function cie10()
    {
        return $this->belongsTo(MntCie10::class, 'id_cie10');
    }

    public function tipoConsulta()
    {
        return $this->belongsTo(CtlTipoConsulta::class, 'id_tipo_consulta');
    }

    public function vacuna()
    {
        return $this->belongsTo(CtlVacunas::class, 'id_vacuna');
    }

    public function usuarioRegistra()
    {
        return $this->belongsTo(FosUserUser::class, 'id_usuario_registra');
    }
}
