<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CtlRaTipoReaccionSeeder extends Seeder
{
    public function run()
    {
        DB::table('ctl_ra_tipo_reaccion')->insert([
            [
                'id' => '1',
                'codigo' => 'RAM/PRM',
                'nombre' => 'Reacción por Medicamento',
                'descripcion' => 'Reacción Adversa a Medicamentos/Problemas Relacionados a Medicamentos',
                'activo' => 'true',
            ],
            [
                'id' => '2',
                'codigo' => 'ESAVI',
                'nombre' => 'Reacción por Vacuna',
                'descripcion' => 'Evento Supuestamente Atribuible a Vacunación e Inmunización',
                'activo' => 'true',
            ],
        ]);
    }
}
