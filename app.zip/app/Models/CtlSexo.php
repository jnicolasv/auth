<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CtlSexo extends Model
{
    use HasFactory;

    // Especifica la tabla asociada al modelo
    protected $table = 'ctl_sexo';

    // Define los atributos que pueden ser asignados masivamente
    protected $fillable = [
        'nombre',
        'abreviatura'
    ];

    // Relación con SecReaccionAdversa (uno a muchos)
    public function reaccionesAdversas()
    {
        return $this->hasMany(SecReaccionAdversa::class, 'id_sexo');
    }

    // Relación con MntPaciente
    public function pacientes()
    {
        return $this->hasMany(MntPaciente::class, 'id_sexo');
    }
}
