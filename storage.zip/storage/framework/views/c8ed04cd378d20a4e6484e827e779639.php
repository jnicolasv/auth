<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Código de Verificación</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 14px;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .ii a[href] {
            color: #fff;
        }
        .email-wrapper {
            width: 100%;
            background-color: #f4f4f4;
            padding: 20px 0;
        }
        .email-container {
            max-width: 600px;
            background: #ffffff;
            border-radius: 12px;
            padding: 15px;
            border: 1px solid #eee;
        }
        .header {
            background: #293653;
            padding: 20px;
            color: #ffffff;
            font-size: 24px;
            font-weight: bold;
            text-align: center;
        }
        .content {
            padding: 20px;
            color: #333333;
            text-align: center;
            font-size: 16px;
        }
        .code-box {
            display: inline-block;
            background: #f4f4f4;
            color: #293653;
            font-size: 24px;
            font-weight: bold;
            padding: 12px 24px;
            border-radius: 5px;
            margin: 20px auto;
            text-align: center;
        }
        .footer {
            background: #d4d4dc ;
            color: #293653 ;
            padding: 10px;
            font-size: 14px;
            border-radius: 0 0 8px 8px;
            text-align: center;
        }
    </style>
</head>
<body>
    <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" class="email-wrapper">
        <tr>
            <td align="center">
                <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="600" class="email-container">
                    <tr>
                        <td align="center" class="header">
                            <img src="https://drive.google.com/uc?export=view&id=10XE3WuEyWsYDhXHeT7_vm2wOLm0MsASS" alt="Icon lock" style="height: 40px;"><br>
                            Código de Verificación
                        </td>
                    </tr>
                    <tr>
                        <td align="center" class="content">
                            <img src="https://drive.google.com/uc?export=view&id=1peIYOpT2g0LescQLjNM7xV0BqsD0wUW4" alt="Logotipo" style="height: 85px;"><br>
                            <h2>Hola, <?php echo e($user->persona->primer_nombre); ?> <?php echo e($user->persona->primer_apellido); ?></h2>
                            <p>Tu código de verificación para el acceso es:</p>
                            <div class="code-box"><?php echo e($code); ?></div>
                            <p>Este código expirará en 15 minutos.</p>
                        </td>
                    </tr>
                    <tr>
                        <td align="center" class="footer">
                            <p>Si no solicitaste este código, puedes ignorar este mensaje.</p>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
<?php /**PATH /var/www/html/resources/views/emails/two-factor-code.blade.php ENDPATH**/ ?>