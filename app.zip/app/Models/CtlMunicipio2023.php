<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CtlMunicipio2023 extends Model
{
    use HasFactory;

    // Especificar la tabla asociada
    protected $table = 'ctl_municipio2023';

    // Campos que pueden ser asignados masivamente
    protected $fillable = [
        'nombre',
        'id_departamento',
        'id_usuario_reg',
        'cabecera',
    ];

    // Relación con el modelo CtlDepartamento
    public function departamento()
    {
        return $this->belongsTo(CtlDepartamento::class, 'id_departamento');
    }
}
