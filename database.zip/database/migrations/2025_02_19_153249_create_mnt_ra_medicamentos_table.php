<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('mnt_ra_medicamento', function (Blueprint $table) {
            $table->id();

            $table->unsignedBigInteger('id_ram');
            $table->unsignedBigInteger('id_via_administracion')->nullable();
            $table->unsignedBigInteger('id_tipo_medicamento');
            $table->unsignedBigInteger('id_producto');
            $table->string('otro_medicamento', 120)->nullable();
            $table->string('dosis_unidades_intervalo', 120)->nullable();
            $table->timestamp('fecha_inicio')->nullable();
            $table->timestamp('fecha_final')->nullable();
            $table->unsignedBigInteger('id_usuario_registra')->nullable();

            // Claves foráneas
            $table->foreign('id_via_administracion')->references('id')->on('ctl_ra_via_de_administracion')->restrictOnDelete()->cascadeOnUpdate();
            $table->foreign('id_ram')->references('id')->on('sec_ram')->restrictOnDelete()->cascadeOnUpdate();
            $table->foreign('id_tipo_medicamento')->references('id')->on('ctl_ra_sospecha_medicamento')->restrictOnDelete()->cascadeOnUpdate();
            $table->foreign('id_producto')->references('id')->on('farm_catalogoproductos')->restrictOnDelete()->cascadeOnUpdate();
            $table->foreign('id_usuario_registra')->references('id')->on('fos_user_user')->restrictOnDelete()->cascadeOnUpdate();


            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('mnt_ra_medicamento');
    }
};
