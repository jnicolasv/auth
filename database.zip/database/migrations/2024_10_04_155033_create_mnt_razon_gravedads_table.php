<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('mnt_razon_gravedad', function (Blueprint $table) {
            $table->id();
            
            $table->unsignedBigInteger('id_razon_gravedad')->nullable();
            $table->unsignedBigInteger('id_reaccion_adversa')->nullable();
            
            // Definir la relación (clave foránea)
            $table->foreign('id_razon_gravedad')->references('id')->on('ctl_ra_razon_gravedad');
            $table->foreign('id_reaccion_adversa')->references('id')->on('sec_reaccion_adversa');
                  
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('mnt_razon_gravedad');
    }
};
