<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CtlRaProfesionSeeder extends Seeder
{
    public function run()
    {
        DB::table('ctl_ra_profesion')->insert([
            [
                'nombre_corto' => 'MEDI',
                'nombre' => 'Médico',
                'descripcion' => null,
                'activo' => true,
            ],
            [
                'nombre_corto' => 'FAR/QUIM',
                'nombre' => 'Farmacéutico/Químico farmacéutico',
                'descripcion' => null,
                'activo' => true,
            ],
            [
                'nombre_corto' => 'OTROPROF',
                'nombre' => 'Otro profesional de la salud no especificado',
                'descripcion' => null,
                'activo' => true,
            ],
            [
                'nombre_corto' => 'ABOGA',
                'nombre' => 'Abogado',
                'descripcion' => null,
                'activo' => true,
            ],
            [
                'nombre_corto' => 'USUA',
                'nombre' => 'Usuario',
                'descripcion' => null,
                'activo' => true,
            ],
            [
                'nombre_corto' => 'ENFERME',
                'nombre' => 'Enfermero',
                'descripcion' => null,
                'activo' => true,
            ],
            [
                'nombre_corto' => 'ODONTO',
                'nombre' => 'Odontólogo',
                'descripcion' => null,
                'activo' => true,
            ],
            [
                'nombre_corto' => 'PODOLO',
                'nombre' => 'Podólogo',
                'descripcion' => null,
                'activo' => true,
            ],
            [
                'nombre_corto' => 'FISIOTE',
                'nombre' => 'Fisioterapeuta',
                'descripcion' => null,
                'activo' => true,
            ],
            [
                'nombre_corto' => 'REFINSSA',
                'nombre' => 'Referente en institución de salud',
                'descripcion' => null,
                'activo' => true,
            ],
            [
                'nombre_corto' => 'DESCONO',
                'nombre' => 'Desconocido',
                'descripcion' => null,
                'activo' => true,
            ],
        ]);
    }
}
