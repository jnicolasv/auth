<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('ctl_estado_civil', function (Blueprint $table) {
            $table->id();
            $table->string('nombre', 15); // Campo nombre no nulo
            $table->string('label_femenino', 15)->nullable(); // Campo opcional para etiqueta femenina
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('ctl_estado_civil');
    }
};
