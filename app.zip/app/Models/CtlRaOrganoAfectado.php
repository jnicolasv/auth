<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CtlRaOrganoAfectado extends Model
{
    use HasFactory;

    protected $table = 'ctl_ra_organo_afectado';

    protected $fillable = [
        'nombre_corto',
        'nombre',
        'descripcion',
        'activo'
    ];

    // Relación con MntRaProblemaRelacionadoMedicamento
    public function problemasRelacionados()
    {
        return $this->hasMany(MntRaProblemaRelacionadoMedicamento::class, 'id_organo_afectado');
    }
}
