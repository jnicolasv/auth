@extends('layout-login')

@section('title', 'Recuperar Contraseña')

@section('content')
<form method="POST" action="{{ route('password.email') }}">
    @csrf
    <div class="mb-5">
        <p class="text-gray-700 text-lg text-center font-bold">Restablecer contraseña</p>
        <p class="text-gray-600 text-md text-center">Ingresa tu correo para recibir instrucciones</p>
    </div>
    <div class="mt-10">
        <div class="input-container">
            <label for="email" class="input-label">Correo eléctronico</label>
            <input type="email" id="email" name="email" class="input-field" value="{{ old('name', $filters['name'] ?? '') }}">
        </div>
    </div>

    <div class="flex flex-wrap justify-center mt-5 gap-4 w-full mx-auto">
        <a href="{{ route('login') }}" class="btn-secondary flex-1 min-w-[150px]">
            Cancelar
        </a>
        <button type="submit" class="btn-primary flex-1 min-w-[150px]">
            Enviar
        </button>
    </div>
</form>

@if (session('status'))
    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mt-4" role="alert">
        <p class="text-sm">{{ session('status') }}</p>
    </div>
@endif

@if ($errors->any())
    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mt-4" role="alert">
        @foreach ($errors->all() as $error)
            <p class="text-sm">{{ $error }}</p>
        @endforeach
    </div>
@endif

@endsection

@push('scripts')
<script>
    document.addEventListener('DOMContentLoaded', function() {
        document.getElementById('login').focus();
    });
</script>
@endpush