<?php $__env->startSection('title', 'Acceso Denegado'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex items-center justify-center w-full" style="min-height: calc(100vh - 143px);" 
     class="md:min-h-[calc(100vh-79px)]">
    <div class="mx-4 max-w-lg w-full sm:max-w-md md:max-w-lg lg:max-w-xl xl:max-w-2xl">
        <p class="text-3xl md:text-6xl font-bold text-gray-800 text-center">403</p>
        <p class="text-base md:text-xl text-gray-600 mt-4 text-center">Oops! No tienes permiso para acceder a esta página.</p>
        <div class="text-center mt-6">
            <a href="<?php echo e(url('/dashboard')); ?>" class="inline-block bg-[#576ca9] text-white px-6 py-3 rounded-lg shadow-lg hover:bg-[#455487] transition">
                Volver al inicio
            </a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/errors/403.blade.php ENDPATH**/ ?>