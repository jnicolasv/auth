<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Auth;

class EnsureTwoFactorIsVerified
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        $user = Auth::user();

        // Verificamos si el usuario tiene un código de 2FA y no lo ha verificado
        if ($user && $user->two_factor_code !== null) {
            // Redirigimos al formulario de 2FA, no al proceso de verificación (POST)
            return redirect()->route('two-factor.form')->withErrors(['code' => 'Debes verificar el código de doble factor.']);
        }

        return $next($request);
    }
}
