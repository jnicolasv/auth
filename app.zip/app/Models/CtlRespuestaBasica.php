<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CtlRespuestaBasica extends Model
{
    use HasFactory;

    protected $table = 'ctl_respuesta_basica';

    protected $fillable = [
        'nombre',
        'descripcion',
    ];

    public function ramDesaparece()
    {
        return $this->hasMany(SecRam::class, 'id_rb_desaparece_reaccion');
    }

    public function ramReaparece()
    {
        return $this->hasMany(SecRam::class, 'id_rb_reaparece_reaccion');
    }

    public function ramAntecedentes()
    {
        return $this->hasMany(SecRam::class, 'id_rb_antecedentes_reacciones_adversas');
    }
}
