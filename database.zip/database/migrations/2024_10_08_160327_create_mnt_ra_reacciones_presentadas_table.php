<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('mnt_ra_reacciones_presentadas', function (Blueprint $table) {
            $table->id();
            
            $table->unsignedInteger('id_esavi');
            $table->string('codigo', 15);
            $table->string('label_codigo_snomed', 250);
            $table->unsignedInteger('id_usuario_registra')->nullable();

            $table->foreign('id_esavi')->references('id')->on('sec_esavi')->onDelete('restrict')->onUpdate('cascade');
            $table->foreign('id_usuario_registra')->references('id')->on('fos_user_user')->onDelete('restrict')->onUpdate('cascade');
            
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('mnt_ra_reacciones_presentadas');
    }
};
