<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MntRaDetalleMedicamento extends Model
{
    use HasFactory;

    protected $table = 'mnt_ra_detalle_medicamento';

    protected $fillable = [
        'id_medicamento',
        'nombre_generico',
        'forma_farmaceutica',
        'nombre_comercial',
        'laboratorio_fabricante',
        'concentracion',
        'presentacion',
        'registro_sanitario',
        'lote',
        'vencimiento',
        'id_usuario_registra'
    ];

    // Relación con MntRaMedicamento (un medicamento puede tener varios detalles)
    public function medicamento()
    {
        return $this->belongsTo(MntRaMedicamento::class, 'id_medicamento');
    }

    // Relación con Usuario (registro)
    public function usuarioRegistra()
    {
        return $this->belongsTo(FosUserUser::class, 'id_usuario_registra');
    }

}
