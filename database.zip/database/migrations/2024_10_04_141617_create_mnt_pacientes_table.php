<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('mnt_paciente', function (Blueprint $table) {
            $table->id();
            
            $table->unsignedBigInteger('id_sis');
            $table->string('primer_nombre', 25);
            $table->string('segundo_nombre', 25)->nullable();
            $table->string('tercer_nombre', 25)->nullable();
            $table->string('primer_apellido', 25);
            $table->string('segundo_apellido', 25)->nullable();
            $table->string('apellido_casada', 25)->nullable();
            $table->date('fecha_nacimiento')->nullable();
            $table->unsignedBigInteger('id_pais_nacimiento')->nullable();
            $table->unsignedBigInteger('id_departamento_nacimiento')->nullable();
            $table->unsignedBigInteger('id_municipio_nacimiento')->nullable();
            $table->unsignedBigInteger('id_estado_civil')->nullable();
            $table->unsignedBigInteger('id_doc_ide_paciente')->nullable();
            $table->string('numero_doc_ide_paciente', 100)->nullable();
            $table->unsignedBigInteger('id_ocupacion')->nullable();
            $table->string('direccion', 200)->nullable();
            $table->string('telefono_casa', 10)->nullable();
            $table->unsignedBigInteger('id_departamento_domicilio')->nullable();
            $table->unsignedBigInteger('id_municipio_domicilio')->nullable();
            $table->unsignedBigInteger('id_canton_domicilio')->nullable();
            $table->integer('estado')->default(1);
            $table->unsignedBigInteger('id_nacionalidad')->nullable();
            $table->unsignedBigInteger('id_sexo');
            $table->timestamp('fecha_registro')->nullable();
            $table->text('nombre_completo_fonetico')->nullable();
            $table->text('apellido_completo_fonetico')->nullable();
            $table->string('correo_electronico', 60)->nullable();

            $table->foreign('id_pais_nacimiento')->references('id')->on('ctl_pais')->onDelete('restrict')->onUpdate('cascade');
            $table->foreign('id_departamento_nacimiento')->references('id')->on('ctl_departamento')->onDelete('restrict')->onUpdate('cascade');
            $table->foreign('id_municipio_nacimiento')->references('id')->on('ctl_municipio')->onDelete('restrict')->onUpdate('cascade');
            $table->foreign('id_estado_civil')->references('id')->on('ctl_estado_civil')->onDelete('restrict')->onUpdate('cascade');
            $table->foreign('id_doc_ide_paciente')->references('id')->on('ctl_documento_identidad')->onDelete('restrict')->onUpdate('cascade');
            $table->foreign('id_ocupacion')->references('id')->on('ctl_ocupacion')->onDelete('restrict')->onUpdate('cascade');
            $table->foreign('id_departamento_domicilio')->references('id')->on('ctl_departamento')->onDelete('restrict')->onUpdate('cascade');
            $table->foreign('id_municipio_domicilio')->references('id')->on('ctl_municipio')->onDelete('restrict')->onUpdate('cascade');
            $table->foreign('id_canton_domicilio')->references('id')->on('ctl_canton')->onDelete('restrict')->onUpdate('cascade');
            $table->foreign('id_nacionalidad')->references('id')->on('ctl_pais')->onDelete('restrict')->onUpdate('cascade');
            $table->foreign('id_sexo')->references('id')->on('ctl_sexo')->onDelete('restrict')->onUpdate('cascade');
            
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('mnt_paciente');
    }
};
