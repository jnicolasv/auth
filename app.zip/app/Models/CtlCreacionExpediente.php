<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CtlCreacionExpediente extends Model
{
    use HasFactory;

    // Especificar la tabla asociada
    protected $table = 'ctl_creacion_expediente';

    // Campos que pueden ser asignados masivamente
    protected $fillable = ['area'];

    // Relación con MntExpediente
    public function expedientes()
    {
        return $this->hasMany(MntExpediente::class, 'id_creacion_expediente');
    }
}
