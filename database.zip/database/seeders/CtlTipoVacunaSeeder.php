<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CtlTipoVacunaSeeder extends Seeder
{
    public function run()
    {
        DB::table('ctl_tipo_vacuna')->insert([
            [
                'nombre' => 'Esquema regular',
                'descripcion' => 'Esquema regular',
                'activo' => true,
            ],
            [
                'nombre' => 'Situaciones especiales',
                'descripcion' => 'Situaciones especiales',
                'activo' => true,
            ],
            [
                'nombre' => 'Grupos de riesgo',
                'descripcion' => 'Grupos de riesgo',
                'activo' => true,
            ],
            [
                'nombre' => 'Campañas',
                'descripcion' => 'Campañas',
                'activo' => true,
            ],
            [
                'nombre' => 'Dosis periódicas',
                'descripcion' => 'Dosis periódicas',
                'activo' => true,
            ],
        ]);
    }
}
