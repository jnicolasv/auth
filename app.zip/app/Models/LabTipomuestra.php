<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LabTipomuestra extends Model
{
    use HasFactory;

    protected $table = 'lab_tipomuestra';

    protected $fillable = [
        'tipomuestra',
        'habilitado',
        'abreviatura',
    ];

    public function examenesLaboratorioProcedimientos()
    {
        return $this->hasMany(MntRaExamenesLaboratorioProcedimientos::class, 'id_tipo_muestra');
    }
}
