<?php $__env->startSection('title', 'Reacciones adversas pendientes de validar'); ?>

<?php $__env->startSection('content'); ?>
<div class="p-6">
    <!-- Filters -->
    <div class="bg-white p-4 rounded shadow mb-4">

        <div class="flex flex-col md:flex-row md:justify-between md:items-center mb-4">
            <!-- Título -->
            <h2 class="text-2xl font-semibold text-[#576ca9] text-center sm:text-left">
                DETALLE DE ESAVI REPORTADO
            </h2>

            
        
            <!-- Contenedor de botones -->
            <div x-data="{ openAprobar: false, openRechazar: false }">
                <!-- Botones -->
                <div class="botones-container flex flex-col sm:flex-row sm:flex-nowrap gap-2 justify-center sm:justify-end mt-2 sm:mt-0">
                    <?php if($revisiones->isEmpty() || !$revisiones->pluck('role')->contains(auth()->user()->roles->pluck('name')->first())): ?>
                        <?php if(auth()->user()->hasRole('Región') || auth()->user()->hasRole('Sibasi')): ?>
                            <button @click="openAprobar = true" class="btn-success px-4 py-2 flex items-center gap-2 whitespace-nowrap">
                                <span class="material-symbols-outlined">check_box</span> Aprobar
                            </button>
                            <button @click="openRechazar = true" class="btn-danger px-4 py-2 flex items-center gap-2 whitespace-nowrap">
                                <span class="material-symbols-outlined">disabled_by_default</span> Rechazar
                            </button>
                        <?php endif; ?>
                    <?php endif; ?>
                    <a href="<?php echo e(route(in_array($reaccion->estado_verificacion, ['Aprobado', 'Rechazado']) ? 'reportes.validados' : 'reportes.pendientes')); ?>" class="btn-primary px-4 py-2 flex items-center whitespace-nowrap">
                        REGRESAR
                    </a>
                </div>
            
                <!-- Modal Aprobar -->
                <div x-show="openAprobar" x-cloak class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
                    <div class="bg-white p-6 rounded-lg shadow-lg w-full max-w-md md:max-w-lg lg:max-w-xl xl:max-w-2xl flex gap-4">
                        
                        <!-- Icono -->
                        <div class="flex items-center justify-center bg-green-100 p-4 rounded-lg">
                            <span class="material-symbols-outlined text-green-500 !text-[3rem]">check_circle</span>
                        </div>
                        <!-- Contenido -->
                        <div class="flex-1">
                            <h2 class="text-lg leading-tight font-semibold text-green-600">
                                ¿DESEA APROBAR EL REPORTE PARA ENVIARLO AL SISTEMA APOLO?
                            </h2>
                            <p class="mt-2 text-sm text-gray-700">
                                <strong>ESTABLECIMIENTO:</strong> 
                                <?php echo e($reaccion->empleado->establecimiento->nombre ?? ''); ?><br>
                                <strong>EXPEDIENTE:</strong> 
                                <?php $__currentLoopData = $reaccion->paciente->expedientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expediente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($expediente->id_establecimiento == $reaccion->id_establecimiento): ?>
                                        <?php echo e($expediente->numero); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($reaccion->paciente->primer_nombre); ?> <?php echo e($reaccion->paciente->segundo_nombre ?? ''); ?> <?php echo e($reaccion->paciente->tercer_nombre ?? ''); ?> <?php echo e($reaccion->paciente->primer_apellido); ?> <?php echo e($reaccion->paciente->segundo_apellido ?? ''); ?><br><br>
                                <strong>DEPENDENCIAS PENDIENTES DE VALIDAR</strong>
                                <ul class="list-disc ml-6">
                                    <?php if($revisiones->isEmpty()): ?>
                                        <li>REGIÓN</li>
                                        <li>SIBASI</li>
                                    <?php else: ?>
                                        <?php $__currentLoopData = $revisiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $revision): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($revision->role); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </ul>
                            </p>
                            <form action="<?php echo e(route('reportes.aprobar', $reaccion->id)); ?>" method="POST">
                                <div class="mt-4 flex justify-end space-x-2">
                                    <?php echo csrf_field(); ?>
                                    <button type="button" @click="openAprobar = false" class="px-4 py-2 bg-gray-300 rounded-lg">Cancelar</button>
                                    <button type="submit" class="px-4 py-2 bg-green-500 text-white rounded-lg">Aprobar</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Modal Rechazar -->
                <div x-show="openRechazar" x-cloak class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
                    <div class="bg-white p-6 rounded-lg shadow-lg w-full max-w-md md:max-w-lg lg:max-w-xl xl:max-w-2xl flex gap-4">
                        <!-- Icono -->
                        <div class="flex items-center justify-center bg-red-100 p-4 rounded-lg">
                            <span class="material-symbols-outlined text-red-500 !text-[3rem]">cancel</span>
                        </div>
                        <!-- Contenido -->
                        <div class="flex-1">
                            <h2 class="text-lg leading-tight font-semibold text-red-600">
                                ¿DESEA RECHAZAR EL REPORTE PARA ENVIARLO AL SISTEMA APOLO?
                            </h2>
                            <p class="mt-2 text-sm text-gray-700">
                            <strong>ESTABLECIMIENTO:</strong> 
                                <?php echo e($reaccion->empleado->establecimiento->nombre ?? ''); ?><br>
                                <strong>EXPEDIENTE:</strong> 
                                <?php $__currentLoopData = $reaccion->paciente->expedientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expediente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($expediente->id_establecimiento == $reaccion->id_establecimiento): ?>
                                        <?php echo e($expediente->numero); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 <?php echo e($reaccion->paciente->primer_nombre); ?> <?php echo e($reaccion->paciente->segundo_nombre ?? ''); ?> <?php echo e($reaccion->paciente->tercer_nombre ?? ''); ?> <?php echo e($reaccion->paciente->primer_apellido); ?> <?php echo e($reaccion->paciente->segundo_apellido ?? ''); ?><br><br>
                                EL REPORTE NO PODRÁ SER VALIDADO POR OTRA DEPENDENCIA, SE PROCEDERÁ AL DESCARTE Y SE DEBERÁ NOTIFICAR AL ESTABLECIMIENTO EL RECHAZO DEL REPORTE
                            </p>
                            <form action="<?php echo e(route('reportes.rechazar', $reaccion->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <p class="mt-2 text-sm text-gray-700">
                                    <strong>Motivo del rechazo:</strong>
                                    <textarea class="w-full mt-2 p-2 border rounded-md" rows="3" id="motivo_rechazo" name="motivo_rechazo" placeholder="Ingrese el motivo..."></textarea>
                                </p>
                                <div class="mt-4 flex justify-end space-x-2">
                                    <button type="button" @click="openRechazar = false" class="px-4 py-2 bg-gray-300 rounded-lg">Cancelar</button>
                                    <button type="submit" class="px-4 py-2 bg-red-500 text-white rounded-lg">Rechazar</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>

        <!-- Mostrar al admin quien lo ha aprobado -->
        <?php if(!$revisiones->isEmpty() && (auth()->user()->hasRole('Superadmin') || auth()->user()->hasRole('Administrador') || auth()->user()->hasRole('DIRTECS'))): ?>
            <div class="bg-green-100 text-green-700 text-lg px-2 py-1 rounded border border-green-400 flex items-center gap-2">
                <?php $__currentLoopData = $revisiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $revision): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="material-symbols-outlined">person_check</span> <span>Aprobado por <strong><?php echo e($revision->role); ?></strong> (<?php echo e($revision->primer_nombre); ?> <?php echo e($revision->primer_apellido); ?>)</span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        <!-- Notificaciones -->
        <div id="notificaciones">
            <?php if(session('success')): ?>
                <div class="bg-green-500 text-white p-2 mt-4 rounded-md relative">
                    <div class="flex items-center gap-2">
                        <span class="material-symbols-outlined">check_circle</span> 
                        <span><?php echo e(session('success')); ?></span>
                    </div>
                    <button class="notification-close-button" onclick="this.parentElement.style.display='none';"><span class="material-symbols-outlined">close</span></button>
                </div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="bg-red-500 text-white p-2 mt-4 rounded-md relative">
                    <div class="flex items-center gap-2">
                        <span class="material-symbols-outlined">cancel</span> 
                        <span><?php echo e(session('error')); ?></span>
                    </div>
                    <button class="notification-close-button" onclick="this.parentElement.style.display='none';"><span class="material-symbols-outlined">close</span></button>
                </div>
            <?php endif; ?>
        
            <?php if(session('warning')): ?>
                <div class="bg-yellow-500 text-white p-2 mt-4 rounded-md relative">
                    <div class="flex items-center gap-2">
                        <span class="material-symbols-outlined">error</span> 
                        <span><?php echo e(session('warning')); ?></span>
                    </div>
                    <button class="notification-close-button" onclick="this.parentElement.style.display='none';"><span class="material-symbols-outlined">close</span></button>
                </div>
            <?php endif; ?>
        
            <?php if(session('info')): ?>
                <div class="bg-blue-500 text-white p-2 mt-4 rounded-md relative">
                    <div class="flex items-center gap-2">
                        <span class="material-symbols-outlined">info</span> 
                        <span><?php echo e(session('info')); ?></span>
                    </div>
                    <button class="notification-close-button" onclick="this.parentElement.style.display='none';"><span class="material-symbols-outlined">close</span></button>
                </div>
            <?php endif; ?>
        </div>

        <hr class="col-span-3 mt-3 mb-4 border-t border-[#576ca9]">

        

        <div class="grid grid-cols-1 sm:grid-cols-[auto_1fr] border border-gray-300/50 text-sm">
            <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Fecha de agendamiento</div>
            <div class="p-2 border border-gray-300/50">** No se puede acceder a este dato **</div>
        
            <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Médico que agenda</div>
            <div class="p-2 border border-gray-300/50"><?php echo e($reaccion->empleado->nombre); ?> <?php echo e($reaccion->empleado->apellido); ?></div>
        
            <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Especialidad</div>
            <div class="p-2 border border-gray-300/50">** No se puede acceder a este dato **</div>
        </div>

        <div class="border border-gray-300/50 text-sm mt-4">
            <!-- Encabezado -->
            <div class="p-2 bg-sky-50 text-[#576ca9] text-lg font-semibold border border-gray-300/50">
                Reporte del evento
            </div>
        
            <!-- Contenido -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 2xl:grid-cols-6 border-t border-gray-300/50">

                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Fecha de notificacion</div>
                <div class="p-2 border border-gray-300/50"><?php echo e(\Carbon\Carbon::parse($reaccion->fecha_notificacion)->format('d-m-Y')); ?></div>
        
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Titulo del reporte</div>
                <div class="p-2 border border-gray-300/50"><?php echo e($reaccion->titulo_reporte); ?></div>
        
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Número de reporte local</div>
                <div class="p-2 border border-gray-300/50">** N/V **</div>
        
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Forma en que se detecta el caso</div>
                <div class="p-2 border border-gray-300/50"><?php echo e($reaccion->formaDetectarCaso->nombre); ?></div>
        
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Tipo de evento</div>
                <div class="p-2 border border-gray-300/50"><?php echo e($reaccion->tipoEvento->nombre); ?></div>
        
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Paciente grave</div>
                <div class="p-2 border border-gray-300/50"><?php echo e($reaccion->paciente_grave ? 'Sí' : 'No'); ?></div>

                <?php if($reaccion->paciente_grave): ?>
                    <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Razones de gravedad</div>
                    <div class="p-2 border border-gray-300/50"><?php echo e($reaccion->razones_gravedad); ?></div>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="border border-gray-300/50 text-sm mt-4">
            <!-- Encabezado -->
            <div class="p-2 bg-sky-50 text-[#576ca9] text-lg font-semibold border border-gray-300/50">
                Notificador
            </div>
        
            <!-- Contenido -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 2xl:grid-cols-6 border-t border-gray-300/50">

                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Nombre Completo</div>
                <div class="p-2 border border-gray-300/50"><?php echo e($reaccion->empleado->nombre); ?> <?php echo e($reaccion->empleado->apellido); ?></div>
        
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Correo Electrónico</div>
                <div class="p-2 border border-gray-300/50"><?php echo e($reaccion->empleado->correo_electronico ?? '--'); ?></div>
        
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Establecimiento</div>
                <div class="p-2 border border-gray-300/50"><?php echo e($reaccion->empleado->establecimiento->nombre ?? '--'); ?></div>
        
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Profesión</div>
                <div class="p-2 border border-gray-300/50"><?php echo e($reaccion->profesion->nombre ?? '--'); ?></div>
        
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Teléfono</div>
                <div class="p-2 border border-gray-300/50"><?php echo e($reaccion->empleado->numero_celular ?? '--'); ?></div>
        
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Clasificación del notificador</div>
                <div class="p-2 border border-gray-300/50">
                    <!-- Validar que haya un registro de SecEsavi -->
                    <?php if($reaccion->esavi): ?>
                        <?php echo e($reaccion->esavi->clasificacionNotificador->nombre ?? '--'); ?>

                    <?php else: ?>
                        No hay datos de ESAVI disponibles.
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="border border-gray-300/50 text-sm mt-4">
            <!-- Encabezado -->
            <div class="p-2 bg-sky-50 text-[#576ca9] text-lg font-semibold border border-gray-300/50">
                Información del paciente
            </div>
        
            <!-- Contenido -->
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-6 2xl:grid-cols-8 border-t border-gray-300/50">
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Número de Expediente</div>
                <div class="p-2 border border-gray-300/50">
                    <?php $__currentLoopData = $reaccion->paciente->expedientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expediente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($expediente->id_establecimiento == $reaccion->id_establecimiento): ?>
                            <?php echo e($expediente->numero); ?>

                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
        
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Nombre Completo</div>
                <div class="p-2 border border-gray-300/50"><?php echo e($reaccion->paciente->primer_nombre); ?> <?php echo e($reaccion->paciente->segundo_nombre ?? ''); ?> <?php echo e($reaccion->paciente->tercer_nombre ?? ''); ?> <?php echo e($reaccion->paciente->primer_apellido); ?> <?php echo e($reaccion->paciente->segundo_apellido ?? ''); ?></div>
        
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Sexo</div>
                <div class="p-2 border border-gray-300/50"><?php echo e($reaccion->sexo->nombre ?? '--'); ?></div>
        
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Departamento</div>
                <div class="p-2 border border-gray-300/50"><?php echo e($reaccion->paciente->departamentoDomicilio->nombre ?? '--'); ?></div>
        
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Municipio</div>
                <div class="p-2 border border-gray-300/50"><?php echo e($reaccion->paciente->municipioDomicilio->nombre ?? '--'); ?></div>
        
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Peso</div>
                <div class="p-2 border border-gray-300/50"><?php echo e($reaccion->peso ? $reaccion->peso . ' kg' : '--'); ?></div>

                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Talla</div>
                <div class="p-2 border border-gray-300/50"><?php echo e($reaccion->talla ? $reaccion->talla . ' cm' : '--'); ?></div>

                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Embarazo</div>
                <div class="p-2 border border-gray-300/50"><?php echo e($reaccion->embarazo ? 'Sí' : 'No'); ?></div>

                <?php if($reaccion->embarazo): ?>
                    <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Semanas de embarazo</div>
                    <div class="p-2 border border-gray-300/50"><?php echo e($reaccion->semana_gestacional); ?></div>
                <?php endif; ?>
            </div>
        </div>

        <?php if($reaccion->tipoReaccion->codigo == 'ESAVI'): ?>

        <div class="border border-gray-300/50 text-sm mt-4">
            <!-- Encabezado -->
            <div class="p-2 bg-sky-50 text-[#576ca9] text-lg font-semibold border border-gray-300/50">
                Historia Clínica
            </div>
        
            <!-- Contenido en grid -->
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-6 4xl:grid-cols-8 border-t border-gray-300/50">
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Fecha de detección/Consulta</div>
                <div class="p-2 border border-gray-300/50"><?php echo e(\Carbon\Carbon::parse($reaccion->fecha_deteccion)->format('d-m-Y')); ?></div>

                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Paciente fue Hospitalizado</div>
                <div class="p-2 border border-gray-300/50"><?php echo e($reaccion->fecha_ingreso ? 'Sí' : 'No'); ?></div>

                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Fecha de Ingreso</div>
                <div class="p-2 border border-gray-300/50"><?php echo e($reaccion->fecha_ingreso ? \Carbon\Carbon::parse($reaccion->fecha_ingreso)->format('d-m-Y') : '--'); ?></div>

                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Fecha de resolución de la reacción o evento</div>
                <div class="p-2 border border-gray-300/50"><?php echo e($reaccion->esavi->fecha_resolucion_evento ? \Carbon\Carbon::parse($reaccion->esavi->fecha_resolucion_evento)->format('d-m-Y') : '--'); ?></div>

                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Fecha de inicio del evento o ESAVI</div>
                <div class="p-2 border border-gray-300/50"><?php echo e($reaccion->esavi->fecha_inicio_esavi ? \Carbon\Carbon::parse($reaccion->esavi->fecha_inicio_esavi)->format('d-m-Y') : '--'); ?></div>

                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Hora de inicio del evento o ESAVI</div>
                <div class="p-2 border border-gray-300/50"><?php echo e($reaccion->esavi->fecha_inicio_esavi ? \Carbon\Carbon::parse($reaccion->esavi->fecha_inicio_esavi)->format('H:i') : '--'); ?></div>

                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Condición actual del paciente</div>
                <div class="p-2 border border-gray-300/50"><?php echo e($reaccion->condicionDesenlace ? $reaccion->condicionDesenlace->nombre : '--'); ?></div>

                <!-- Columna vacía -->
                <div class="p-2 hidden md:block md:col-span-2 lg:col-span-4 border border-gray-300/50"></div>  

                <div class="p-2 font-semibold bg-gray-100 sm:col-span-1 md:col-span-2 lg:col-span-2 border border-gray-300/50">Reacciones o eventos presentados</div>
                <div class="p-2 border border-gray-300/50 sm:col-span-1 md:col-span-2 lg:col-span-4">
                    <?php $__currentLoopData = $reaccion->esavi->reaccionesPresentadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reaccionPresentada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($reaccionPresentada->label_codigo_snomed); ?><?php if(!$loop->last): ?>, <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="p-2 font-semibold bg-gray-100 sm:col-span-1 md:col-span-2 lg:col-span-2 border border-gray-300/50">Descripción del cuadro clínico</div>
                <div class="p-2 border border-gray-300/50 sm:col-span-1 md:col-span-2 lg:col-span-4"><?php echo e($reaccion->esavi->descripcion_accion_tomada ?? '--'); ?></div>

                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Acción tomada ante la reacción o el evento</div>
                <div class="p-2 border border-gray-300/50 sm:col-span-1 lg:col-span-2"><?php echo e($reaccion->esavi->accionTomada ?? '--'); ?></div>

                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Descripción de la acción tomada</div>
                <div class="p-2 border border-gray-300/50 sm:col-span-1 lg:col-span-2"><?php echo e($reaccion->esavi->descripcion_accion_tomada ?? '--'); ?></div>
            </div>
        </div>

        <div class="border border-gray-300/50 text-sm mt-4">
            <!-- Encabezado -->
            <div class="p-2 bg-sky-50 text-[#576ca9] text-lg font-semibold border border-gray-300/50">
                Diagnósticos de la historia clínica
            </div>
        
            <!-- Tabla en pantallas grandes -->
            <div class="hidden lg:grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-6 border-t border-gray-300/50">
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Tipo de diagnóstico</div>
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Diagnóstico</div>
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Confirmación</div>
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Tipo de consulta</div>
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Especificación</div>
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Fecha y hora</div>
                
                <?php $__currentLoopData = $reaccion->esavi->diagnosticos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diagnostico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="p-2 border border-gray-300/50"><?php echo e($diagnostico->tipoDiagnostico->nombre); ?></div>
                    <div class="p-2 border border-gray-300/50"><?php echo e($diagnostico->cie10->codigo); ?></div>
                    <div class="p-2 border border-gray-300/50"><?php echo e($diagnostico->confirmado ? 'Sí' : 'No'); ?></div>
                    <div class="p-2 border border-gray-300/50"><?php echo e($diagnostico->tipoConsulta->nombre); ?></div>
                    <div class="p-2 border border-gray-300/50"><?php echo e($diagnostico->observacion ?? '--'); ?></div>
                    <div class="p-2 border border-gray-300/50"><?php echo e(\Carbon\Carbon::parse($diagnostico->fecha_hora_registra)->format('d/m/Y h:i A')); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        
            <!-- Tarjetas en pantallas pequeñas -->
            <div class="lg:hidden flex flex-col divide-y divide-gray-200">
                <?php $__currentLoopData = $reaccion->esavi->diagnosticos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diagnostico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 p-3 bg-white border border-gray-300/50 shadow-sm">
                    <div class="text-sm font-bold text-gray-700">Tipo de diagnóstico</div>
                    <div class="text-sm"><?php echo e($diagnostico->tipoDiagnostico->nombre); ?></div>
        
                    <div class="text-sm font-bold text-gray-700">Diagnóstico</div>
                    <div class="text-sm"><?php echo e($diagnostico->cie10->codigo); ?></div>
        
                    <div class="text-sm font-bold text-gray-700">Confirmación</div>
                    <div class="text-sm"><?php echo e($diagnostico->confirmado ? 'Sí' : 'No'); ?></div>
        
                    <div class="text-sm font-bold text-gray-700">Tipo de consulta</div>
                    <div class="text-sm"><?php echo e($diagnostico->tipoConsulta->nombre); ?></div>
        
                    <div class="text-sm font-bold text-gray-700">Especificación</div>
                    <div class="text-sm"><?php echo e($diagnostico->observacion ?? '--'); ?></div>
        
                    <div class="text-sm font-bold text-gray-700">Fecha y hora</div>
                    <div class="text-sm"><?php echo e(\Carbon\Carbon::parse($diagnostico->fecha_hora_registra)->format('d/m/Y h:i A')); ?></div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <div class="border border-gray-300/50 text-sm mt-4">
            <!-- Encabezado -->
            <div class="p-2 bg-sky-50 text-[#576ca9] text-lg font-semibold border border-gray-300/50">
                Antecedentes médicos personales y familiares relevantes
            </div>

            <!-- Contenido en grid -->
            <div class="grid grid-cols-6 border-t border-gray-300/50">
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50 col-span-6 md:col-span-3 lg:col-span-2">Enfermedades pre existentes al momento de presentarse el ESAVI, reacción o evento</div>
                <div class="p-2 border border-gray-300/50 col-span-6 md:col-span-3 lg:col-span-4"><?php echo e($reaccion->antecedentes); ?></div>

                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50 col-span-6 md:col-span-3 lg:col-span-1">Otros antecedentes</div>
                <div class="p-2 border border-gray-300/50 col-span-6 md:col-span-3 lg:col-span-2"><?php echo e($reaccion->otros_antecedentes ?? '--'); ?></div>
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50 col-span-6 md:col-span-3 lg:col-span-1">Enfermedades autoinmune, ¿Cuál?</div>
                <div class="p-2 border border-gray-300/50 col-span-6 md:col-span-3 lg:col-span-2"><?php echo e($reaccion->esavi->enfermedad_autoinmune ?? '--'); ?></div>

                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50 col-span-6 md:col-span-3 lg:col-span-3">Medicación concomitante, tratamiento con esteroides sistémicos > 10 días o otros inmunosupresores</div>
                <div class="p-2 border border-gray-300/50 col-span-6 md:col-span-3 lg:col-span-3"><?php echo e($reaccion->esavi->medicacion_concomitante ?? '--'); ?></div>

                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50 col-span-6 md:col-span-3 lg:col-span-2">Historia de ESAVI o eventos previos a dosis anteriores de vacunas aplicadas</div>
                <div class="p-2 border border-gray-300/50 col-span-6 md:col-span-3 lg:col-span-1"><?php echo e($reaccion->esavi->historia_esavi ? 'Sí' : 'No'); ?></div>
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50 col-span-6 md:col-span-3 lg:col-span-1">Tipo de reacción y vacuna</div>
                <div class="p-2 border border-gray-300/50 col-span-6 md:col-span-3 lg:col-span-2"><?php echo e($reaccion->esavi->historia_tipo_reaccion_vacuna ?? '--'); ?></div>

                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50 col-span-6 md:col-span-3 lg:col-span-2">Antecedentes familiares de reacciones adversas a vacunas</div>
                <div class="p-2 border border-gray-300/50 col-span-6 md:col-span-3 lg:col-span-1"><?php echo e($reaccion->esavi->antecedentes_familiares_esavi ? 'Sí' : 'No'); ?></div>
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50 col-span-6 md:col-span-3 lg:col-span-1">Tipo de reacción y vacuna</div>
                <div class="p-2 border border-gray-300/50 col-span-6 md:col-span-3 lg:col-span-2"><?php echo e($reaccion->esavi->antecedentes_tipo_reaccion_vacuna ?? '--'); ?></div>
            </div>
        </div>
        
        <div class="border border-gray-300/50 text-sm mt-4">
            <!-- Encabezado -->
            <div class="p-2 bg-sky-50 text-[#576ca9] text-lg font-semibold border border-gray-300/50">
            Exámenes de laboratorio y gabinete u otros procedimientos diagnósticos realizados
            </div>

            <!-- Contenido en grid -->
            <div class="hidden lg:grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 border-t border-gray-300/50">
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Examen Realizado</div>
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Tipo de Muestra</div>
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Resultados</div>
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Fecha de realización</div>

                <?php $__empty_1 = true; $__currentLoopData = $reaccion->esavi->examenesLaboratorioProcedimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $examen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="p-2 border border-gray-300/50"><?php echo e($examen->examen_realizado); ?></div>
                    <div class="p-2 border border-gray-300/50"><?php echo e($examen->tipoMuestra->tipomuestra); ?></div>
                    <div class="p-2 border border-gray-300/50"><?php echo e($examen->resultados); ?></div>
                    <div class="p-2 border border-gray-300/50"><?php echo e(\Carbon\Carbon::parse($examen->fecha_realizacion)->format('d/m/Y h:i A')); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="p-2 border border-gray-300/50 col-span-4 text-center">No hay registros ...</div>
                <?php endif; ?>
            </div>
            <!-- Tarjetas en pantallas pequeñas -->
            <div class="lg:hidden flex flex-col divide-y divide-gray-200">
                <?php $__empty_1 = true; $__currentLoopData = $reaccion->esavi->examenesLaboratorioProcedimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $examen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 p-3 bg-white border border-gray-300/50 shadow-sm">
                    <div class="text-sm font-bold text-gray-700">Examen Realizado</div>
                    <div class="text-sm"><?php echo e($examen->examen_realizado); ?></div>

                    <div class="text-sm font-bold text-gray-700">Tipo de Muestra</div>
                    <div class="text-sm"><?php echo e($examen->tipoMuestra->tipomuestra); ?></div>

                    <div class="text-sm font-bold text-gray-700">Resultados</div>
                    <div class="text-sm"><?php echo e($examen->resultados); ?></div>

                    <div class="text-sm font-bold text-gray-700">Fecha de realización</div>
                    <div class="text-sm"><?php echo e(\Carbon\Carbon::parse($examen->fecha_realizacion)->format('d/m/Y h:i A')); ?></div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="p-4 bg-white border border-gray-300/50 shadow-sm text-center">No hay registros ...</div>
                <?php endif; ?>
            </div>
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-6">
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Fecha de Egreso/Alta</div>
                <div class="p-2 border border-gray-300/50"><?php echo e($reaccion->esavi->fecha_egreso_alta ? \Carbon\Carbon::parse($reaccion->esavi->fecha_egreso_alta)->format('d/m/Y h:i A') : '--'); ?></div>
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Fecha de Muerte/Defunción</div>
                <div class="p-2 border border-gray-300/50"><?php echo e($reaccion->esavi->fecha_muerte_defuncion ? \Carbon\Carbon::parse($reaccion->esavi->fecha_muerte_defuncion)->format('d/m/Y h:i A') : '--'); ?></div>
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Resultado de la autopsia</div>
                <div class="p-2 border border-gray-300/50"><?php echo e($reaccion->esavi->autopsia ?? '--'); ?></div>
            </div>
        </div>

        <div class="border border-gray-300/50 text-sm mt-4">
            <!-- Encabezado -->
            <div class="p-2 bg-sky-50 text-[#576ca9] text-lg font-semibold border border-gray-300/50">
                Vacunas/Medicamentos concomitantes aplicadas
            </div>

            <!-- Tabla en pantallas grandes -->
            <div class="hidden lg:grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-8 border-t border-gray-300/50">
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Nombre de vacuna ó medicamento</div>
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Lote</div>
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Vía de Administración</div>
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Sitio anatómico de administración</div>
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Dosis</div>
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Fecha Vencimiento</div>
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">T° Conservación</div>
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50">Laboratorio</div>

                <?php $__empty_1 = true; $__currentLoopData = $reaccion->esavi->vacunasConcomitantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vacuna): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="p-2 border border-gray-300/50"><?php echo e($vacuna->nombre_vacuna); ?></div>
                    <div class="p-2 border border-gray-300/50"><?php echo e($vacuna->lote ?? '--'); ?></div>
                    <div class="p-2 border border-gray-300/50"><?php echo e($vacuna->viaAdministracion->nombre); ?></div>
                    <div class="p-2 border border-gray-300/50"><?php echo e($vacuna->regionCuerpo->nombre); ?></div>
                    <div class="p-2 border border-gray-300/50"><?php echo e($vacuna->dosis ?? '--'); ?></div>
                    <div class="p-2 border border-gray-300/50"><?php echo e(\Carbon\Carbon::parse($vacuna->fecha_vencimiento)->format('d/m/Y')); ?></div>
                    <div class="p-2 border border-gray-300/50"><?php echo e($vacuna->temperatura_conservacion ?? '--'); ?></div>
                    <div class="p-2 border border-gray-300/50"><?php echo e($vacuna->laboratorio ?? '--'); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="p-2 border border-gray-300/50 col-span-8 text-center">No hay registros ...</div>
                <?php endif; ?>
            </div>

            <!-- Tarjetas en pantallas pequeñas -->
            <div class="lg:hidden flex flex-col divide-y divide-gray-200">
                <?php $__empty_1 = true; $__currentLoopData = $reaccion->esavi->vacunasConcomitantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vacuna): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 p-3 bg-white border border-gray-300/50 shadow-sm">
                    <div class="text-sm font-bold text-gray-700">Nombre de vacuna ó medicamento</div>
                    <div class="text-sm"><?php echo e($vacuna->nombre_vacuna); ?></div>

                    <div class="text-sm font-bold text-gray-700">Lote</div>
                    <div class="text-sm"><?php echo e($vacuna->lote ?? '--'); ?></div>

                    <div class="text-sm font-bold text-gray-700">Vía de Administración</div>
                    <div class="text-sm"><?php echo e($vacuna->viaAdministracion->nombre); ?></div>

                    <div class="text-sm font-bold text-gray-700">Sitio anatómico de administración</div>
                    <div class="text-sm"><?php echo e($vacuna->regionCuerpo->nombre); ?></div>

                    <div class="text-sm font-bold text-gray-700">Dosis</div>
                    <div class="text-sm"><?php echo e($vacuna->dosis ?? '--'); ?></div>

                    <div class="text-sm font-bold text-gray-700">Fecha Vencimiento</div>
                    <div class="text-sm"><?php echo e(\Carbon\Carbon::parse($vacuna->fecha_vencimiento)->format('d/m/Y')); ?></div>

                    <div class="text-sm font-bold text-gray-700">T° Conservación</div>
                    <div class="text-sm"><?php echo e($vacuna->temperatura_conservacion ?? '--'); ?></div>

                    <div class="text-sm font-bold text-gray-700">Laboratorio</div>
                    <div class="text-sm"><?php echo e($vacuna->laboratorio ?? '--'); ?></div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="p-4 bg-white border border-gray-300/50 shadow-sm text-center">No hay registros ...</div>
                <?php endif; ?>
            </div>
        </div>

        <div class="border border-gray-300/50 text-sm mt-4">
            <!-- Encabezado -->
            <div class="p-2 bg-sky-50 text-[#576ca9] text-lg font-semibold border border-gray-300/50">
            Información de la vacuna sospechosa relacionada al ESAVI o evento
            </div>

            <!-- Tabla en pantallas grandes -->
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-10 border-t border-gray-300/50">

                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50 col-span-1 lg:col-span-2 xl:col-span-2">Número registro sanitario vacuna</div>
                <div class="p-2 border border-gray-300/50 col-span-1"><?php echo e($reaccion->esavi->vacunasSospechosas->numero_registro_sanitario ?? '--'); ?></div>
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50 col-span-1">Nombre Comercial</div>
                <div class="p-2 border border-gray-300/50 col-span-1 md:col-span-1 lg:col-span-2"><?php echo e($reaccion->esavi->vacunasSospechosas->nombre_comercial ?? '--'); ?></div>
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50 col-span-1">Dosis</div>
                <div class="p-2 border border-gray-300/50 col-span-1 lg:col-span-2 xl:col-span-1"><?php echo e($reaccion->esavi->vacunasSospechosas->numero_dosis ?? '--'); ?></div>
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50 col-span-1 lg:col-span-1 xl:col-span-1">Sitio Anatómico</div>
                <div class="p-2 border border-gray-300/50 col-span-1 lg:col-span-2 xl:col-span-1"><?php echo e($reaccion->esavi->vacunasSospechosas->regionCuerpo->nombre ?? '--'); ?></div>

                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50 col-span-1 lg:col-span-1 xl:col-span-1">Dosis de vacuna (ml)</div>
                <div class="p-2 border border-gray-300/50 col-span-1 lg:col-span-2 xl:col-span-1"><?php echo e($reaccion->esavi->vacunasSospechosas->dosis_vacuna_ml ?? '--'); ?></div>
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50 col-span-1 lg:col-span-2 xl:col-span-2">Temp. de conservación de vacuna</div>
                <div class="p-2 border border-gray-300/50 col-span-1"><?php echo e($reaccion->esavi->vacunasSospechosas->temperatura_conservacion ?? '--'); ?></div>
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50 col-span-1 lg:col-span-2 xl:col-span-1">Lugar de vacunación</div>
                <div class="p-2 border border-gray-300/50 col-span-1 md:col-span-1 lg:col-span-1 xl:col-span-2"><?php echo e($reaccion->esavi->vacunasSospechosas->vacunasSospechosas->nombre ?? '--'); ?></div>
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50 col-span-1 lg:col-span-2 xl:col-span-1">Sitio Anatómico Especifíco</div>
                <div class="p-2 border border-gray-300/50 col-span-1 md:col-span-1 lg:col-span-1 xl:col-span-1"><?php echo e($reaccion->esavi->vacunasSospechosas->otro_sitio_anatomico ?? '--'); ?></div>

                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50 col-span-1 md:col-span-2">Nombre y dirección del establecimiento</div>
                <div class="p-2 border border-gray-300/50 col-span-1 md:col-span-2 lg:col-span-4 xl:col-span-3"><?php echo e($reaccion->esavi->vacunasSospechosas->direccion_establecimiento ?? '--'); ?></div>
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50 col-span-1">Marco de aplicación</div>
                <div class="p-2 border border-gray-300/50 col-span-1 lg:col-span-2 xl:col-span-1"><?php echo e($reaccion->esavi->vacunasSospechosas->marcoAplicacion->nombre ?? '--'); ?></div>
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50 col-span-1">Indicación médica</div>
                <div class="p-2 border border-gray-300/50 col-span-1 md:col-span-1 lg:col-span-2"><?php echo e($reaccion->esavi->vacunasSospechosas->otra_indicacion_medica ?? '--'); ?></div>

                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50 col-span-1">Vía de administración</div>
                <div class="p-2 border border-gray-300/50 col-span-1 lg:col-span-2 xl:col-span-1"><?php echo e($reaccion->esavi->vacunasSospechosas->viaAdministracion->nombre ?? 'OTRA'); ?></div>
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50 col-span-1">Especifique</div>
                <div class="p-2 border border-gray-300/50 col-span-1 md:col-span-1 lg:col-span-2"><?php echo e($reaccion->esavi->vacunasSospechosas->otra_via_administracion ?? '--'); ?></div>
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50 col-span-1 lg:col-span-2 xl:col-span-1">Laboratorio fabricante</div>
                <div class="p-2 border border-gray-300/50 col-span-1 md:col-span-1 lg:col-span-2"><?php echo e($reaccion->esavi->vacunasSospechosas->laboratorio ?? '--'); ?></div>
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50 col-span-1">Lote</div>
                <div class="p-2 border border-gray-300/50 col-span-1"><?php echo e($reaccion->esavi->vacunasSospechosas->lote ?? '--'); ?></div>

                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50 col-span-1">Fecha de Caducidad</div>
                <div class="p-2 border border-gray-300/50 col-span-1"><?php echo e($reaccion->esavi->vacunasSospechosas->fecha_vencimiento ?? '--'); ?></div>
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50 col-span-1">Fecha de vacunación</div>
                <div class="p-2 border border-gray-300/50 col-span-1"><?php echo e($reaccion->esavi->vacunasSospechosas->fecha_vacunacion ? \Carbon\Carbon::parse($reaccion->esavi->vacunasSospechosas->fecha_vacunacion)->format('d/m/Y') : '--'); ?></div>
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50 col-span-1">Hora de vacunación</div>
                <div class="p-2 border border-gray-300/50 col-span-1"><?php echo e($reaccion->esavi->vacunasSospechosas->hora_vacunacion ? \Carbon\Carbon::parse($reaccion->esavi->vacunasSospechosas->hora_vacunacion)->format('H:i A') : '--'); ?></div>
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50 col-span-1">Recurso Vacunador</div>
                <div class="p-2 border border-gray-300/50 col-span-1 lg:col-span-2 xl:col-span-1"><?php echo e($reaccion->esavi->vacunasSospechosas->recursoVacunador->nombre ?? 'OTRO'); ?></div>
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50 col-span-1">Especifique</div>
                <div class="p-2 border border-gray-300/50 col-span-1 lg:col-span-2 xl:col-span-1"><?php echo e($reaccion->esavi->vacunasSospechosas->otro_recurso_vacunador ?? '--'); ?></div>

                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50 col-span-1 md:col-span-3 lg:col-span-4 xl:col-span-3">Resguardo del frasco biológico o involucrado o frasco del mismo lote</div>
                <div class="p-2 border border-gray-300/50 col-span-1 lg:col-span-2 xl:col-span-1"><?php echo e($reaccion->esavi->vacunasSospechosas->resguarda_frasco ? 'Sí' : 'No'); ?></div>
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50 col-span-1 md:col-span-2">Vacunas aplicadas por frasco</div>
                <div class="p-2 border border-gray-300/50 col-span-1 md:col-span-2 lg:col-span-1"><?php echo e($reaccion->esavi->vacunasSospechosas->total_vacunas_aplicadas ?? '--'); ?></div>
                <div class="p-2 font-semibold bg-gray-100 border border-gray-300/50 col-span-1 md:col-span-2">Vacunas por establecimiento</div>
                <div class="p-2 border border-gray-300/50 col-span-1 md:col-span-2 lg:col-span-1"><?php echo e($reaccion->esavi->vacunasSospechosas->total_vacunas_establecimientos ?? '--'); ?></div>
            </div>
        </div>

        <?php else: ?>

        

        <?php endif; ?>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/reportes/verificar.blade.php ENDPATH**/ ?>