<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CtlRaCondicionDesenlaceSeeder extends Seeder
{
    public function run()
    {
        DB::table('ctl_ra_condicion_desenlace')->insert([
            [
                'nombre_corto' => 'RECSINSE',
                'nombre' => 'Recuperado/resuelto',
                'descripcion' => 'Recuperado sin secuelas',
                'activo' => true,
            ],
            [
                'nombre_corto' => 'RECCONSE',
                'nombre' => 'Recuperado/resuelto con secuelas',
                'descripcion' => 'Recuperado con secuelas',
                'activo' => true,
            ],
            [
                'nombre_corto' => 'NORECUP',
                'nombre' => 'No recuperado/no resuelto',
                'descripcion' => 'No recuperado',
                'activo' => true,
            ],
            [
                'nombre_corto' => 'ENPROCRE',
                'nombre' => 'En recuperación/en resolución',
                'descripcion' => 'En proceso de recuperacion',
                'activo' => true,
            ],
            [
                'nombre_corto' => 'FALLE',
                'nombre' => 'Mortal',
                'descripcion' => 'Fallecido',
                'activo' => false,
            ],
            [
                'nombre_corto' => 'SEDESCO',
                'nombre' => 'Desconocido',
                'descripcion' => 'Se desconoce',
                'activo' => true,
            ],
        ]);
    }
}
