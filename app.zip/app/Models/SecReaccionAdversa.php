<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SecReaccionAdversa extends Model
{
    use HasFactory;

    protected $table = 'sec_reaccion_adversa';

    protected $fillable = [
        'id_forma_detectar_caso',
        'id_tipo_evento',
        'id_establecimiento',
        'id_profesion',
        'id_sexo',
        'id_condicion_desenlace',
        'id_historial_clinico',
        'id_empleado',
        'id_paciente',
        'fecha_consulta',
        'especialidad_consulta',
        'numero_reporte',
        'titulo_reporte',
        'fecha_notificacion',
        'forma_detectar_especifique',
        'paciente_grave',
        'peso',
        'talla',
        'embarazo',
        'lactando',
        'semana_gestacional',
        'edad_lactante',
        'responsable',
        'fecha_deteccion',
        'fecha_ingreso',
        'antecedentes',
        'otros_antecedentes',
        'id_pais',
        'id_tipo_reaccion',
        'id_usuario_registra',
        'estado_verificacion',
    ];

    public function formaDetectarCaso()
    {
        return $this->belongsTo(CtlRaFormaDetectarCaso::class, 'id_forma_detectar_caso');
    }

    public function tipoEvento()
    {
        return $this->belongsTo(CtlRaTipoEvento::class, 'id_tipo_evento');
    }

    public function establecimiento()
    {
        return $this->belongsTo(CtlEstablecimiento::class, 'id_establecimiento');
    }

    public function profesion()
    {
        return $this->belongsTo(CtlRaProfesion::class, 'id_profesion');
    }

    public function sexo()
    {
        return $this->belongsTo(CtlSexo::class, 'id_sexo');
    }

    public function condicionDesenlace()
    {
        return $this->belongsTo(CtlRaCondicionDesenlace::class, 'id_condicion_desenlace');
    }

    /*public function historialClinico()
    {
        return $this->belongsTo(HistorialClinico::class, 'id_historial_clinico');
    }*/

    public function empleado()
    {
        return $this->belongsTo(MntEmpleado::class, 'id_empleado');
    }

    public function paciente()
    {
        return $this->belongsTo(MntPaciente::class, 'id_paciente');
    }

    public function pais()
    {
        return $this->belongsTo(CtlPais::class, 'id_pais');
    }

    public function tipoReaccion()
    {
        return $this->belongsTo(CtlRaTipoReaccion::class, 'id_tipo_reaccion');
    }

    public function usuarioRegistra()
    {
        return $this->belongsTo(FosUserUser::class, 'id_usuario_registra'); 
    }

    public function esavi()
    {
        return $this->hasOne(SecEsavi::class, 'id_reaccion_adversa');
    }

    public function razonGravedades()
    {
        return $this->hasMany(MntRazonGravedad::class, 'id_reaccion_adversa');
    }

    // Obtener las revisiones de la reacción adversa
    public function revisiones()
    {
        return $this->hasMany(SecReaccionRevision::class, 'reaccion_adversa_id');
    }

}
