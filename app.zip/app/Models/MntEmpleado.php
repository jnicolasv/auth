<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MntEmpleado extends Model
{
    use HasFactory;

    protected $table = 'mnt_empleado';

    protected $fillable = [
        'id_sis',
        'nombre',
        'apellido',
        'fecha_nacimiento',
        'dui',
        'numero_celular',
        'correo_electronico',
        'id_establecimiento',
        'id_cargo_empleado',
        'id_tipo_empleado',
        'primer_nombre',
        'segundo_nombre',
        'tercer_nombre',
        'primer_apellido',
        'segundo_apellido',
        'apellido_casada',
        'id_persona_uuid',
    ];

    // Relación con SecReaccionAdversa (uno a muchos)
    public function reaccionesAdversas()
    {
        return $this->hasMany(SecReaccionAdversa::class, 'id_empleado');
    }

    // Relación con CtlEstablecimiento
    public function establecimiento()
    {
        return $this->belongsTo(CtlEstablecimiento::class, 'id_establecimiento');
    }
}
