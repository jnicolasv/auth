<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CtlEstadoCivil extends Model
{
    use HasFactory;

    // Especificar la tabla asociada
    protected $table = 'ctl_estado_civil';

    // Campos que pueden ser asignados masivamente
    protected $fillable = [
        'nombre',
        'label_femenino',
    ];

    // Relación con el modelo MntPaciente
    public function pacientes()
    {
        return $this->hasMany(MntPaciente::class, 'id_estado_civil');
    }
}
