<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SecReaccionRevision extends Model
{
    use HasFactory;

    protected $table = 'sec_reaccion_revision';

    protected $fillable = [
        'reaccion_adversa_id',
        'estado_revision',
        'fecha_revision',
        'observaciones',
        'usuario_id'
    ];

    public function reaccionAdversa()
    {
        return $this->belongsTo(SecReaccionAdversa::class, 'reaccion_adversa_id');
    }

    public function usuario()
    {
        return $this->belongsTo(User::class, 'usuario_id');
    }
}
