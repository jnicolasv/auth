<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('fos_user_user', function (Blueprint $table) {
            $table->id();

            $table->unsignedBigInteger('id_sis');
            $table->string('username', 255);
            $table->string('email', 255)->nullable();
            $table->timestamp('date_of_birth')->nullable();
            $table->string('firstname', 64)->nullable();
            $table->string('lastname', 64)->nullable();
            $table->string('gender', 1)->nullable();
            $table->string('phone', 64)->nullable();
            $table->integer('id_establecimiento')->nullable();
            $table->integer('id_empleado')->nullable();

            // Definición de las claves foráneas
            $table->foreign('id_establecimiento')->references('id')->on('ctl_establecimiento')->onDelete('restrict')->onUpdate('cascade');
            $table->foreign('id_empleado')->references('id')->on('mnt_empleado')->onDelete('restrict')->onUpdate('cascade');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('fos_user_user');
    }
};
