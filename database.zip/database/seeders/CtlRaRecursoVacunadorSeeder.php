<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CtlRaRecursoVacunadorSeeder extends Seeder
{
    public function run()
    {
        DB::table('ctl_ra_recurso_vacunador')->insert([
            [
                'nombre_corto' => 'E',
                'nombre' => 'Enfermera',
                'descripcion' => null,
                'activo' => true,
            ],
            [
                'nombre_corto' => 'TE',
                'nombre' => 'Técnico en enfermería',
                'descripcion' => null,
                'activo' => true,
            ],
            [
                'nombre_corto' => 'TMI',
                'nombre' => 'Técnico materno infantil',
                'descripcion' => null,
                'activo' => true,
            ],
            [
                'nombre_corto' => 'PS',
                'nombre' => 'Promotor de salud',
                'descripcion' => null,
                'activo' => true,
            ],
            [
                'nombre_corto' => 'M',
                'nombre' => 'Médico',
                'descripcion' => null,
                'activo' => true,
            ],
            [
                'nombre_corto' => 'O',
                'nombre' => 'Otro',
                'descripcion' => null,
                'activo' => true,
            ],
        ]);
    }
}
