<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MntCie10 extends Model
{
    use HasFactory;

    protected $table = 'mnt_cie10';

    protected $fillable = [
        'codigo',
        'grupom',
        'codgrupo',
        'diagnostico',
        'alarma',
        'sexo_cie10',
        'c_salida',
        'mayor',
        'menor',
        'critico',
        'unaccent_diagnostico',
        'activo',
        'odontologia',
        'causa_externa',
        'incluir_repetitiva',
    ];

    // Relación con SecRaDiagnostico
    public function secRaDiagnosticos()
    {
        return $this->hasMany(SecRaDiagnostico::class, 'id_cie10');
    }
}
