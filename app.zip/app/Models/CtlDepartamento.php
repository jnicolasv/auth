<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CtlDepartamento extends Model
{
    use HasFactory;

    // Especificar la tabla asociada
    protected $table = 'ctl_departamento';

    // Campos que pueden ser asignados masivamente
    protected $fillable = [
        'nombre',
        'codigo_cnr',
        'abreviatura',
        'id_pais',
        'iso31662',
        'codigo_rnpn',
    ];

    // Relación con el modelo CtlPais
    public function pais()
    {
        return $this->belongsTo(CtlPais::class, 'id_pais');
    }

    // Relacion con el modelo CtlMunicipio2023
    public function municipios2023()
    {
        return $this->hasMany(CtlMunicipio2023::class, 'id_departamento');
    }

    // Relación con el modelo CtlMunicipio
    public function municipios()
    {
        return $this->hasMany(CtlMunicipio::class, 'id_departamento');
    }
}
