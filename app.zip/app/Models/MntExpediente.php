<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MntExpediente extends Model
{
    use HasFactory;

    // Especificar la tabla asociada
    protected $table = 'mnt_expediente';

    // Campos que pueden ser asignados masivamente
    protected $fillable = [
        'id_sis',
        'numero',
        'id_paciente',
        'id_establecimiento',
        'habilitado',
        'id_creacion_expediente',
        'fecha_creacion',
        'hora_creacion',
        'numero_temporal',
        'expediente_fisico_eliminado',
        'cun',
        'uso_temporal',
        'carpeta_familiar',
        'id_establecimiento_origen',
        'historial_neonato',
        'id_expediente_madre',
        'nui',
    ];

    // Relación con Paciente
    public function paciente()
    {
        return $this->belongsTo(MntPaciente::class, 'id_paciente');
    }

    // Relación con Establecimiento
    public function establecimiento()
    {
        return $this->belongsTo(CtlEstablecimiento::class, 'id_establecimiento');
    }

    // Relación con Creación de Expediente
    public function creacionExpediente()
    {
        return $this->belongsTo(CtlCreacionExpediente::class, 'id_creacion_expediente');
    }

    // Relación con Establecimiento Origen
    public function establecimientoOrigen()
    {
        return $this->belongsTo(CtlEstablecimiento::class, 'id_establecimiento_origen');
    }

    // Relación con Expediente Madre
    public function expedienteMadre()
    {
        return $this->belongsTo(MntExpediente::class, 'id_expediente_madre');
    }
}
