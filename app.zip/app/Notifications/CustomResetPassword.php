<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use App\Mail\ResetPasswordEmail;
use Illuminate\Support\Facades\Mail;

class CustomResetPassword extends Notification
{
    use Queueable;
    public $token;

    /**
     * Create a new notification instance.
     */
    public function __construct($token)
    {
        $this->token = $token;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @return array<int, string>
     */
    public function via(object $notifiable): array
    {
        return ['mail'];
    }

    /**
     * Get the mail representation of the notification.
     */
    public function toMail(object $notifiable): MailMessage
    {
        $url = url(route('password.reset', ['token' => $this->token, 'email' => $notifiable->getEmailForPasswordReset()], false));

        return (new MailMessage)
            ->subject('Restablecimiento de contraseña')
            ->view('emails.reset-password', [ // Aquí usas la vista personalizada
                'url' => $url,
                'user' => $notifiable,
            ]);
            // ->greeting('¡Hola!')
            // ->line('Estás recibiendo este correo porque solicitaste restablecer tu contraseña.')
            // ->action('Restablecer contraseña', $url)
            // ->line('Si no solicitaste un restablecimiento de contraseña, no se requiere ninguna acción adicional.');
            // ->salutation('Saludos, el equipo de tu aplicación.');
    }

    /**
     * Get the array representation of the notification.
     *
     * @return array<string, mixed>
     */
    public function toArray(object $notifiable): array
    {
        return [
            //
        ];
    }
}
