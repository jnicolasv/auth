<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CtlRaTipoEvento extends Model
{
    use HasFactory;

    protected $table = 'ctl_ra_tipo_evento';

    protected $fillable = [
        'nombre_corto',
        'nombre',
        'descripcion',
        'modulo',
        'activo',
    ];

    // Relación con SecReaccionAdversa (uno a muchos)
    public function reaccionesAdversas()
    {
        return $this->hasMany(SecReaccionAdversa::class, 'id_tipo_evento');
    }
}
