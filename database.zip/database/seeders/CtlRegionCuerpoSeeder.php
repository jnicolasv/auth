<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CtlRegionCuerpoSeeder extends Seeder
{
    public function run()
    {
        DB::table('ctl_region_cuerpo')->insert([
            [
                'nombre' => 'Cabeza',
                'descripcion' => 'Representa región superior del cuerpo sobre la cual el médico determina hallazgos asociados al examen físico',
            ],
            [
                'nombre' => 'Cuello',
                'descripcion' => 'Representa región del cuerpo que comprende la transición entre el cráneo , tronco y las extremedidades superiores.',
            ],
            [
                'nombre' => 'Tórax',
                'descripcion' => 'Representa región del cuerpo comprendida entre la base del cuello y el diafragma.',
            ],
            [
                'nombre' => 'Pulmones',
                'descripcion' => 'Representa región del cuerpo que incluye además otros órganos del sistema respiratorio.',
            ],
            [
                'nombre' => 'Corazón',
                'descripcion' => 'Representa región del cuerpo asociada al sistema circulatorio.',
            ],
            [
                'nombre' => 'Abdomen',
                'descripcion' => 'Representa región del cuerpo que comprende la cavidad abdominal y los órganos internos asociados (Esófago,estómago,etc.).',
            ],
            [
                'nombre' => 'Genitales',
                'descripcion' => 'Representa región del cuerpo que incluye órganos del sistema reproductor.',
            ],
            [
                'nombre' => 'Músculo esquelético',
                'descripcion' => 'Representa tipos de músculos estriados unidos al esqueleto.',
            ],
            [
                'nombre' => 'Piel',
                'descripcion' => 'Representa el sistema integumentario del cuerpo.',
            ],
            [
                'nombre' => 'Neurológico',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Boca',
                'descripcion' => ' Es la abertura corporal por la que se ingieren alimentos y  desempeña funciones importantes en diversas actividades como el lenguaje y en expresiones faciales.',
            ],
            [
                'nombre' => 'Ganglios',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Vulva',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Vagina',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Uretra',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Cervix',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Útero',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Pene',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Testículos',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Meato Uretral',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Ano',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Mandíbula',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Oído',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Nariz',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Dientes',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Lengua',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Garganta',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Hombros',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Brazos',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Codos',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Manos',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Muñeca',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Ingle',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Piernas',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Rodillas',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Tobillos',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Pies',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Dedos de las Manos',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Dedos de los Pies',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Cadera',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Epigastrio',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Hipogastrio',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Frente',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Axilas',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Muslos',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Ojos',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Rostro/Cara',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Espalda',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Glúteos',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Labios',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Pechos/Mamas/Senos',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Mentón',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Mejilla',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Orejas',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Ombligo',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Pubis',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Uñas',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Vientre',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Extremidades',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Fosas Nasales',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Ovarios',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Ojo Izquierdo',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Ojo Derecho',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Carrillos',
                'descripcion' => 'Comunmente conocidos como mejillas',
            ],
            [
                'nombre' => 'Encias',
                'descripcion' => '',
            ],
            [
                'nombre' => 'Paladar',
                'descripcion' => 'Comunmente conocido como el cielo de la boca',
            ],
            [
                'nombre' => 'Rodilla Izquierda',
                'descripcion' => '',
            ],
            [
                'nombre' => 'Rodilla Derecha',
                'descripcion' => '',
            ],
            [
                'nombre' => 'Brazo Izquierdo',
                'descripcion' => '',
            ],
            [
                'nombre' => 'Brazo Derecho',
                'descripcion' => '',
            ],
            [
                'nombre' => 'Hombro Izquierdo',
                'descripcion' => '',
            ],
            [
                'nombre' => 'Hombro Derecho',
                'descripcion' => '',
            ],
            [
                'nombre' => 'Pie Izquierdo',
                'descripcion' => '',
            ],
            [
                'nombre' => 'Pie Derecho',
                'descripcion' => '',
            ],
            [
                'nombre' => 'Mano Izquierda',
                'descripcion' => '',
            ],
            [
                'nombre' => 'Mano Derecha',
                'descripcion' => '',
            ],
            [
                'nombre' => 'Clavicula',
                'descripcion' => '',
            ],
            [
                'nombre' => 'Codo Izquierdo',
                'descripcion' => '',
            ],
            [
                'nombre' => 'Codo Derecho',
                'descripcion' => '',
            ],
            [
                'nombre' => 'Antebrazo Izquierdo',
                'descripcion' => '',
            ],
            [
                'nombre' => 'Antebrazo Derecho',
                'descripcion' => '',
            ],
            [
                'nombre' => 'Pelvis',
                'descripcion' => '',
            ],
            [
                'nombre' => 'Muslo Izquierdo',
                'descripcion' => '',
            ],
            [
                'nombre' => 'Muslo Derecho',
                'descripcion' => '',
            ],
            [
                'nombre' => 'Pierna Izquierda',
                'descripcion' => '',
            ],
            [
                'nombre' => 'Pierna Derecha',
                'descripcion' => '',
            ],
            [
                'nombre' => 'Muñeca Izquierda',
                'descripcion' => '',
            ],
            [
                'nombre' => 'Muñeca Derecha',
                'descripcion' => '',
            ],
            [
                'nombre' => 'Tobillo Izquierdo',
                'descripcion' => '',
            ],
            [
                'nombre' => 'Tobillo Derecho',
                'descripcion' => '',
            ],
            [
                'nombre' => 'Ortejos',
                'descripcion' => 'Dedos de los pies',
            ],
            [
                'nombre' => 'Apariencia General',
                'descripcion' => 'Apariencia general del menor de edad',
            ],
            [
                'nombre' => 'Ortolani',
                'descripcion' => 'Evaluación de cadera a menor de 28 dias',
            ],
            [
                'nombre' => 'Barlow',
                'descripcion' => 'Evaluación de cadera a menor de 28 dias',
            ],
            [
                'nombre' => 'Próstata',
                'descripcion' => 'Glándula pequeña en los hombres. Es parte del sistema reproductor del hombre.',
            ],
            [
                'nombre' => 'Nuca',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Columna Vertebral',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Recto',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Cardiovascular',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Pulsos',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Cordón umbulical',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Moro',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Succión',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Búsqueda',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Anomalías congénitas aparentes',
                'descripcion' => null,
            ],
            [
                'nombre' => 'Impresión diagnóstica',
                'descripcion' => null,
            ],
        ]);
    }
}
