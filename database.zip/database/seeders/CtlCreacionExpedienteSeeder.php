<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CtlCreacionExpedienteSeeder extends Seeder
{
    public function run()
    {
        DB::table('ctl_creacion_expediente')->insert([
            ['area' => 'Consulta Externa'],
            ['area' => 'Emergencia'],
            ['area' => 'ESDOMED'],
            ['area' => 'B.M.'],
            ['area' => 'Centro Oftalmológico'],
            ['area' => 'Hospitalización']
        ]);
    }
}
