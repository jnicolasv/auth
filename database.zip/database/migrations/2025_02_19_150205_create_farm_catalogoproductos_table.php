<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('farm_catalogoproductos', function (Blueprint $table) {
            $table->id();

            $table->string('codigo', 8);
            $table->unsignedBigInteger('idtipoproducto')->nullable();
            $table->unsignedBigInteger('idunidadmedida')->default(0);
            $table->text('nombre');
            $table->unsignedBigInteger('niveluso')->nullable();
            $table->text('concentracion')->nullable();
            $table->text('formafarmaceutica')->nullable();
            $table->text('presentacion')->nullable();
            $table->unsignedInteger('prioridad')->nullable();
            $table->decimal('precioactual', 20, 3)->nullable();
            $table->unsignedInteger('aplicalote')->default(0)->nullable();
            $table->decimal('existenciaactual', 15, 3)->default(0);
            $table->text('especificacionestecnicas')->nullable();
            $table->string('codigonacionesunidas', 20)->nullable();
            $table->unsignedInteger('pertenecelistadooficial')->nullable();
            $table->unsignedInteger('estadoproducto')->default(1);
            $table->text('observacion')->nullable();
            $table->char('auusuariocreacion', 15)->nullable();
            $table->timestamp('aufechacreacion')->nullable();
            $table->string('auusuariomodificacion', 15)->nullable();
            $table->timestamp('aufechamodificacion')->nullable();
            $table->unsignedInteger('estasincronizada')->default(0)->nullable();
            $table->unsignedBigInteger('idestablecimiento')->nullable();
            $table->char('clasificacion', 1)->nullable();
            $table->unsignedBigInteger('areatecnica')->nullable();
            $table->unsignedBigInteger('tipouaci')->nullable();
            $table->unsignedBigInteger('idespecificogasto')->nullable();
            $table->decimal('ultimoprecio', 20, 3)->nullable();
            $table->unsignedBigInteger('idterapeutico')->default(0);
            $table->char('idestado', 1)->default('H')->nullable();
            $table->unsignedInteger('divisormedicina')->nullable();
            $table->unsignedInteger('cuantificable')->default(0);

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('farm_catalogoproductos');
    }
};
