<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CtlRaTipoEventoSeeder extends Seeder
{
    public function run()
    {
        DB::table('ctl_ra_tipo_evento')->insert([
            [
                'nombre_corto' => 'RAM',
                'nombre' => 'RAM',
                'descripcion' => null,
                'modulo' => 'RAM/PRM',
                'activo' => true,
            ],
            [
                'nombre_corto' => 'ESAVI',
                'nombre' => 'ESAVI',
                'descripcion' => null,
                'modulo' => 'ESAVI',
                'activo' => true,
            ],
            [
                'nombre_corto' => 'FALLTERA',
                'nombre' => 'Falla terapéutica',
                'descripcion' => null,
                'modulo' => 'RAM/PRM',
                'activo' => true,
            ],
            [
                'nombre_corto' => 'INEFIVAC',
                'nombre' => 'Ineficiencia de Vacuna',
                'descripcion' => null,
                'modulo' => 'ESAVI',
                'activo' => true,
            ],
            [
                'nombre_corto' => 'ERRMEDI',
                'nombre' => 'Error de medicación',
                'descripcion' => null,
                'modulo' => 'RAM/PRM',
                'activo' => true,
            ],
            [
                'nombre_corto' => 'ERRPROG',
                'nombre' => 'Error programático',
                'descripcion' => null,
                'modulo' => 'ESAVI',
                'activo' => true,
            ],
            [
                'nombre_corto' => 'MFALFRAU',
                'nombre' => 'Falsificado/Fraudulento',
                'descripcion' => null,
                'modulo' => 'RAM/PRM',
                'activo' => true,
            ],
            [
                'nombre_corto' => 'VFALFRAU',
                'nombre' => 'Vacuna Falsificada/Fraudulenta',
                'descripcion' => null,
                'modulo' => 'ESAVI',
                'activo' => true,
            ],
            [
                'nombre_corto' => 'USOOFF',
                'nombre' => 'Uso off -label',
                'descripcion' => null,
                'modulo' => 'AMBOS',
                'activo' => true,
            ],
            [
                'nombre_corto' => 'INTER',
                'nombre' => 'Interacción',
                'descripcion' => null,
                'modulo' => 'RAM/PRM',
                'activo' => true,
            ],
            [
                'nombre_corto' => 'INTOX',
                'nombre' => 'Intoxicación',
                'descripcion' => null,
                'modulo' => 'RAM/PRM',
                'activo' => true,
            ],
            [
                'nombre_corto' => 'EXPOS',
                'nombre' => 'Exposición',
                'descripcion' => null,
                'modulo' => 'AMBOS',
                'activo' => true,
            ],
        ]);
    }
}
