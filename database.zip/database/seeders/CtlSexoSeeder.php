<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CtlSexoSeeder extends Seeder
{
    public function run()
    {
        DB::table('ctl_sexo')->insert([
            [
                'nombre' => 'Masculino',
                'abreviatura' => 'M',
            ],
            [
                'nombre' => 'Femenino',
                'abreviatura' => 'F',
            ],
        ]);
    }
}
