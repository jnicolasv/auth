<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use App\Models\FosUserUser;
use App\Models\MntEmpleado;
use App\Models\MntExpediente;
use App\Models\MntPaciente;
use App\Models\MntRaExamenesLaboratorioProcedimientos;
use App\Models\MntRaReaccionesPresentadas;
use App\Models\MntRaVacunasConcomitantes;
use App\Models\SecEsavi;
use App\Models\SecRaDiagnostico;
use App\Models\SecReaccionAdversa;
use App\Models\SecVacunaSospechosaEsavi;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class ReaccionAdversaController extends Controller
{
    // protected $apiService;

    // public function __construct(ApiService $apiService)
    // {
    //     $this->apiService = $apiService;
    // }

    public function login_user(Request $request)
    {
        $data = $request->json()->all();
        $credentials = [
            'name' => $data['username'], 
            'password' => $data['password']
        ];
        
        if (Auth::attempt($credentials)) {
            $user = Auth::user();
            $token = $user->createToken('authToken')->plainTextToken;

            return response()->json([
                'token' => $token,
                'message' => 'Success'
            ]);
        }

        return response()->json([
            'message' => 'Unauthorized'
        ], 401);
    }

    public function registrar_reaccion_adversa(Request $request)
    {   
        // Extraer los datos del request
        $data = $request->json()->all();

        // Define las reglas de validación
        $validator = Validator::make($data, [
            'paciente.id' => 'required|integer',
            'paciente.primer_nombre' => 'required|string|max:255',
            'paciente.segundo_nombre' => 'nullable|string|max:255',
            'paciente.fecha_nacimiento' => 'required|date_format:Y-m-d',
            'paciente.fecha_registro' => 'nullable|date_format:Y-m-d',

            'empleado.id' => 'required|integer',
            'empleado.nombre' => 'required|string',
            'empleado.apellido' => 'required|string',

            'usuario.id' => 'required|integer',
            'usuario.username' => 'required|string',
            'usuario.id_establecimiento' => 'required|integer',
            'usuario.id_empleado' => 'required|integer',
            'usuario.date_of_birth' => 'nullable|date_format:Y-m-d',

            'expediente.id' => 'required|integer',
            'expediente.numero' => 'required|string',
            'expediente.id_paciente' => 'required|integer',
            'expediente.id_establecimiento' => 'required|integer',
            'expediente.fecha_creacion' => 'nullable|date_format:Y-m-d',

            'reaccion_adversa.id' => 'required|integer',
            'reaccion_adversa.id_forma_detectar_caso' => 'required|integer',
            'reaccion_adversa.id_tipo_evento' => 'required|integer',
            'reaccion_adversa.id_establecimiento' => 'required|integer',
            'reaccion_adversa.id_profesion' => 'required|integer',
            'reaccion_adversa.id_sexo' => 'required|integer',
            'reaccion_adversa.id_condicion_desenlace' => 'required|integer',
            'reaccion_adversa.id_historial_clinico' => 'required|integer',
            'reaccion_adversa.id_empleado' => 'required|integer',
            'reaccion_adversa.id_paciente' => 'required|integer',
            'reaccion_adversa.id_pais' => 'required|integer',
            'reaccion_adversa.id_tipo_reaccion' => 'required|integer',
            'reaccion_adversa.id_usuario_registra' => 'required|integer',
            'reaccion_adversa.fecha_notificacion' => 'required|date_format:Y-m-d',
            'reaccion_adversa.fecha_deteccion' => 'required|date_format:Y-m-d',
            'reaccion_adversa.fecha_ingreso' => 'nullable|date_format:Y-m-d',

            'esavi.id' => 'required|integer',
            'esavi.id_clasificacion_notificador' => 'required|integer',
            'esavi.id_accion_tomada' => 'required|integer',
            'esavi.id_clasificacion_final' => 'required|integer',
            'esavi.id_usuario_registra' => 'nullable|integer',
            'esavi.fecha_resolucion_evento' => 'nullable|date_format:Y-m-d',
            'esavi.fecha_inicio_esavi' => 'nullable|date_format:Y-m-d',
            'esavi.fecha_egreso_alta' => 'nullable|date_format:Y-m-d',
            'esavi.fecha_muerte_defuncion' => 'nullable|date_format:Y-m-d',

            'vacunas_sospechosas.*.id' => 'nullable|integer',
            'vacunas_sospechosas.*.id_via_administracion' => 'nullable|integer',
            'vacunas_sospechosas.*.id_tipo_vacuna' => 'nullable|integer',
            'vacunas_sospechosas.*.id_region_cuerpo' => 'nullable|integer',
            'vacunas_sospechosas.*.id_recurso_vacunador' => 'nullable|integer',
            'vacunas_sospechosas.*.id_marco_aplicacion' => 'nullable|integer',
            'vacunas_sospechosas.*.id_lugar_vacunacion' => 'nullable|integer',
            'vacunas_sospechosas.*.id_vacuna' => 'nullable|integer',
            'vacunas_sospechosas.*.id_usuario_registra' => 'nullable|integer',
            'vacunas_sospechosas.*.numero_registro_sanitario' => 'string',
            'vacunas_sospechosas.*.nombre_comercial' => 'nullable|string',
            'vacunas_sospechosas.*.fecha_vencimiento' => 'nullable|date_format:Y-m-d',
            'vacunas_sospechosas.*.fecha_vacunacion' => 'nullable|date_format:Y-m-d',

            'examenes_laboratorio.*.id' => 'required|integer',
            'examenes_laboratorio.*.id_tipo_muestra' => 'required|integer',
            'examenes_laboratorio.*.id_esavi' => 'required|integer',
            'examenes_laboratorio.*.id_usuario_registra' => 'required|integer',
            'examenes_laboratorio.*.fecha_realizacion' => 'required|date_format:Y-m-d H:i:s',

            'vacunas_concomitantes.*.id' => 'required|integer',
            'vacunas_concomitantes.*.id_esavi' => 'required|integer',
            'vacunas_concomitantes.*.id_region_cuerpo' => 'required|integer',
            'vacunas_concomitantes.*.id_via_administracion' => 'required|integer',
            'vacunas_concomitantes.*.id_vacuna' => 'required|integer',
            'vacunas_concomitantes.*.id_tipo_vacuna' => 'required|integer',
            'vacunas_concomitantes.*.id_usuario_registra' => 'required|integer',
            'vacunas_concomitantes.*.fecha_vencimiento_vacuna' => 'required|date_format:Y-m-d',

            'diagnosticos.*.id' => 'required|integer',
            'diagnosticos.*.id_tipo_diagnostico' => 'required|integer',
            'diagnosticos.*.id_cie10' => 'required|integer',
            'diagnosticos.*.id_tipo_consulta' => 'required|integer',
            'diagnosticos.*.id_vacuna' => 'required|integer',
            'diagnosticos.*.id_usuario_registra' => 'nullable|integer',
        ]);

        // Verifica si la validación falla
        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errors' => $validator->errors(),
            ], 422);
        }

        // Iniciar transacción
        DB::beginTransaction();

        try {

            // A. Validar si existe el paciente
            $pacienteData = $data['paciente'];
            $existePaciente = false;

            $query = MntPaciente::query();

            // Si existe el número de documento, solo buscar por este campo
            if (!empty($pacienteData['numero_doc_ide_paciente'])) {
                $query->where('numero_doc_ide_paciente', $pacienteData['numero_doc_ide_paciente']);
            } else {
                // Si no tiene documento, buscar por otros campos
                if (!empty($pacienteData['fecha_nacimiento'])) {
                    $query->where('fecha_nacimiento', $pacienteData['fecha_nacimiento']);
                }
                if (!empty($pacienteData['id_pais_nacimiento'])) {
                    $query->where('id_pais_nacimiento', $pacienteData['id_pais_nacimiento']);
                }
                if (!empty($pacienteData['id_nacionalidad'])) {
                    $query->where('id_nacionalidad', $pacienteData['id_nacionalidad']);
                }
                if (!empty($pacienteData['id_sexo'])) {
                    $query->where('id_sexo', $pacienteData['id_sexo']);
                }
                if (!empty($pacienteData['nombre_completo_fonetico'])) {
                    $query->where('nombre_completo_fonetico', $pacienteData['nombre_completo_fonetico']);
                }
                if (!empty($pacienteData['apellido_completo_fonetico'])) {
                    $query->where('apellido_completo_fonetico', $pacienteData['apellido_completo_fonetico']);
                }
            }

            $pacienteExistente = $query->first();

            // Si se encuentra un paciente, marcar como existente
            if ($pacienteExistente) {
                $existePaciente = true;
            }

            // Si el paciente ya existe, se intentará crear el expediente asociado al paciente encontrado
            if ($existePaciente == true) {
                // B. Validar si existe el expediente
                $expedienteData = $data['expediente'];
                $expedienteExistente = MntExpediente::where('numero', $expedienteData['numero'])
                ->where('id_establecimiento', $expedienteData['id_establecimiento'])
                ->first();

                if (!$expedienteExistente) {
                    // II. Antes de guardar la reaccion se guardara el expediente
                    $expediente = MntExpediente::create([
                        'id_sis' => $expedienteData['id'],
                        'numero' => $expedienteData['numero'],
                        'id_paciente' => $pacienteExistente->id,  // Relacionar con paciente (existente)
                        'id_establecimiento' => $expedienteData['id_establecimiento'],
                        'habilitado' => $expedienteData['habilitado'],
                        'id_creacion_expediente' => $expedienteData['id_creacion_expediente'],
                        'fecha_creacion' => $expedienteData['fecha_creacion'],
                        'hora_creacion' => $expedienteData['hora_creacion'],
                        'numero_temporal' => $expedienteData['numero_temporal'] ?? false,
                        'expediente_fisico_eliminado' => $expedienteData['expediente_fisico_eliminado'] ?? false,
                        'cun' => $expedienteData['cun'] ?? false,
                        'uso_temporal' => $expedienteData['uso_temporal'] ?? false,
                        'carpeta_familiar' => $expedienteData['carpeta_familiar'] ?? null,
                        'id_establecimiento_origen' => $expedienteData['id_establecimiento_origen'] ?? null,
                        'historial_neonato' => $expedienteData['historial_neonato'] ?? null,
                        'id_expediente_madre' => $expedienteData['id_expediente_madre'] ?? null,
                        'nui' => $expedienteData['nui'] ?? null,
                    ]);
                }
            }else{
                // I. Antes de guardar la reaccion se guardara el paciente
                $paciente = MntPaciente::create([
                    'id_sis' => $pacienteData['id'],
                    'primer_nombre' => $pacienteData['primer_nombre'],
                    'segundo_nombre' => $pacienteData['segundo_nombre'] ?? '',
                    'tercer_nombre' => $pacienteData['tercer_nombre'] ?? '',
                    'primer_apellido' => $pacienteData['primer_apellido'],
                    'segundo_apellido' => $pacienteData['segundo_apellido'] ?? '',
                    'apellido_casada' => $pacienteData['apellido_casada'] ?? '',
                    'fecha_nacimiento' => $pacienteData['fecha_nacimiento'] ?? null,
                    'id_pais_nacimiento' => $pacienteData['id_pais_nacimiento'],
                    'id_departamento_nacimiento' => $pacienteData['id_departamento_nacimiento'],
                    'id_municipio_nacimiento' => $pacienteData['id_municipio_nacimiento'],
                    'id_estado_civil' => $pacienteData['id_estado_civil'],
                    'id_doc_ide_paciente' => $pacienteData['id_doc_ide_paciente'],
                    'numero_doc_ide_paciente' => $pacienteData['numero_doc_ide_paciente'],
                    'id_ocupacion' => $pacienteData['id_ocupacion'],
                    'direccion' => $pacienteData['direccion'],
                    'telefono_casa' => $pacienteData['telefono_casa'] ?? '',
                    'id_departamento_domicilio' => $pacienteData['id_departamento_domicilio'],
                    'id_municipio_domicilio' => $pacienteData['id_municipio_domicilio'],
                    'id_canton_domicilio' => $pacienteData['id_canton_domicilio'],
                    'estado' => $pacienteData['estado'],
                    'id_nacionalidad' => $pacienteData['id_nacionalidad'],
                    'id_sexo' => $pacienteData['id_sexo'],
                    'fecha_registro' => $pacienteData['fecha_registro'],
                    'nombre_completo_fonetico' => $pacienteData['nombre_completo_fonetico'],
                    'apellido_completo_fonetico' => $pacienteData['apellido_completo_fonetico'],
                    'correo_electronico' => $pacienteData['correo_electronico'] ?? '',
                ]);

                // B. Validar si existe el expediente
                $expedienteData = $data['expediente'];
                $expedienteExistente = MntExpediente::where('numero', $expedienteData['numero'])
                ->where('id_establecimiento', $expedienteData['id_establecimiento'])
                ->first();

                if (!$expedienteExistente) {
                    // II. Antes de guardar la reaccion se guardara el expediente
                    $expediente = MntExpediente::create([
                        'id_sis' => $expedienteData['id'],
                        'numero' => $expedienteData['numero'],
                        'id_paciente' => $paciente->id,  // Relacionar con paciente
                        'id_establecimiento' => $expedienteData['id_establecimiento'],
                        'habilitado' => $expedienteData['habilitado'],
                        'id_creacion_expediente' => $expedienteData['id_creacion_expediente'],
                        'fecha_creacion' => $expedienteData['fecha_creacion'],
                        'hora_creacion' => $expedienteData['hora_creacion'],
                        'numero_temporal' => $expedienteData['numero_temporal'] ?? false,
                        'expediente_fisico_eliminado' => $expedienteData['expediente_fisico_eliminado'] ?? false,
                        'cun' => $expedienteData['cun'] ?? false,
                        'uso_temporal' => $expedienteData['uso_temporal'] ?? false,
                        'carpeta_familiar' => $expedienteData['carpeta_familiar'] ?? null,
                        'id_establecimiento_origen' => $expedienteData['id_establecimiento_origen'] ?? null,
                        'historial_neonato' => $expedienteData['historial_neonato'] ?? null,
                        'id_expediente_madre' => $expedienteData['id_expediente_madre'] ?? null,
                        'nui' => $expedienteData['nui'] ?? null,
                    ]);
                }
            }

            // C. Validar si existe el empleado
            $empleadoData = $data['empleado'];
            $empleadoExistente = MntEmpleado::where('dui', $empleadoData['dui'])
            ->where('id_establecimiento', $empleadoData['id_establecimiento'])
            ->first();

            if ($empleadoExistente) {
                // D. Validar si existe el usuario relacionado al empleado
                $usuarioData = $data['usuario'];
                $usuarioExistente = FosUserUser::where('username', $usuarioData['username'])
                ->where('id_establecimiento', $usuarioData['id_establecimiento'])
                ->where('id_empleado', $usuarioData['id_empleado'])
                ->first();

                if(!$usuarioExistente) {
                    // IV. Antes de guardar la reaccion se guardara el usuario relacionado al empleado
                    $usuarioData = $data['usuario'];
                    $usuario = FosUserUser::create([
                        'id_sis' => $usuarioData['id'],
                        'username' => $usuarioData['username'],
                        'email' => $usuarioData['email'],
                        'date_of_birth' => $usuarioData['date_of_birth'] ?? null,
                        'firstname' => $usuarioData['firstname'] ?? '',
                        'lastname' => $usuarioData['lastname'] ?? '',
                        'gender' => $usuarioData['gender'] ?? '',
                        'phone' => $usuarioData['phone'] ?? '',
                        'id_establecimiento' => $usuarioData['id_establecimiento'],
                        'id_empleado' => $empleadoExistente->id,  // Relacionar con empleado (existente)
                    ]);
                }
            }else{
                // III. Antes de guardar la reaccion se guardara el empleado
                $empleado = MntEmpleado::create([
                    'id_sis' => $empleadoData['id'],
                    'nombre' => $empleadoData['nombre'],
                    'apellido' => $empleadoData['apellido'],
                    'fecha_nacimiento' => $empleadoData['fecha_nacimiento'],
                    'dui' => $empleadoData['dui'],
                    'numero_celular' => $empleadoData['numero_celular'],
                    'correo_electronico' => $empleadoData['correo_electronico'],
                    'id_establecimiento' => $empleadoData['id_establecimiento'],
                    'id_cargo_empleado' => $empleadoData['id_cargo_empleado'],
                    'id_tipo_empleado' => $empleadoData['id_tipo_empleado'],
                    'habilitado' => $empleadoData['habilitado'],
                    'primer_nombre' => $empleadoData['primer_nombre'],
                    'segundo_nombre' => $empleadoData['segundo_nombre'],
                    'apellido_casada' => $empleadoData['apellido_casada'],
                    'id_persona_uuid' => $empleadoData['id_persona_uuid'],
                ]);

                // D. Validar si existe el usuario relacionado al empleado
                $usuarioData = $data['usuario'];
                $usuarioExistente = FosUserUser::where('username', $usuarioData['username'])
                ->where('id_establecimiento', $usuarioData['id_establecimiento'])
                ->where('id_empleado', $usuarioData['id_empleado'])
                ->first();

                if(!$usuarioExistente) {
                    // return response()->json([
                    //     'success' => false,
                    //     'message' => 'El usuario NO existe.',
                    //     'data' => $data['usuario'],
                    // ], 400);
                    // IV. Antes de guardar la reaccion se guardara el usuario relacionado al empleado
                    $usuarioData = $data['usuario'];
                    $usuario = FosUserUser::create([
                        'id_sis' => $usuarioData['id'],
                        'username' => $usuarioData['username'],
                        'email' => $usuarioData['email'],
                        'date_of_birth' => $usuarioData['date_of_birth'] ?? null,
                        'firstname' => $usuarioData['firstname'] ?? '',
                        'lastname' => $usuarioData['lastname'] ?? '',
                        'gender' => $usuarioData['gender'] ?? '',
                        'phone' => $usuarioData['phone'] ?? '',
                        'id_establecimiento' => $usuarioData['id_establecimiento'],
                        'id_empleado' => $empleado->id,  // Relacionar con empleado
                    ]);
                }
                
            }

            // Setear empleado y paciente nuevos o existentes
            $idEmpleado = isset($empleado) ? $empleado->id : $empleadoExistente->id;
            $idUsuario = isset($usuario) ? $usuario->id : $usuarioExistente->id;
            $idPaciente = isset($paciente) ? $paciente->id : $pacienteExistente->id;

            // 1. Guardar la información principal en sec_reaccion_adversa
            $reaccionData = $data['reaccion_adversa'];
            $reaccionAdversa = SecReaccionAdversa::create([
                // 'id' => $data['id'],
                'id_forma_detectar_caso' => $reaccionData['id_forma_detectar_caso'],
                'id_tipo_evento' => $reaccionData['id_tipo_evento'],
                'id_establecimiento' => $reaccionData['id_establecimiento'],
                'id_profesion' => $reaccionData['id_profesion'],
                'id_sexo' => $reaccionData['id_sexo'],
                'id_condicion_desenlace' => $reaccionData['id_condicion_desenlace'],
                'id_historial_clinico' => $reaccionData['id_historial_clinico'],
                'id_empleado' => $idEmpleado,  // Relacionar con empleado
                'id_paciente' => $idPaciente,  // Relacionar con paciente
                'titulo_reporte' => $reaccionData['titulo_reporte'],
                'fecha_notificacion' => $reaccionData['fecha_notificacion'],
                'forma_detectar_especifique' => $reaccionData['forma_detectar_especifique'] ?? '',
                'paciente_grave' => $reaccionData['paciente_grave'],
                'peso' => $reaccionData['peso'],
                'talla' => $reaccionData['talla'],
                'embarazo' => $reaccionData['embarazo'],
                'lactando' => $reaccionData['lactando'],
                'semana_gestacional' => $reaccionData['semana_gestacional'] ?? null,
                'edad_lactante' => $reaccionData['edad_lactante'] ?? null,
                'responsable' => $reaccionData['responsable'] ?? null,
                'fecha_deteccion' => $reaccionData['fecha_deteccion'],
                'fecha_ingreso' => $reaccionData['fecha_ingreso'] ?? null,
                'antecedentes' => $reaccionData['antecedentes'] ?? null,
                'otros_antecedentes' => $reaccionData['otros_antecedentes'] ?? null,
                'id_pais' => $reaccionData['id_pais'],
                'id_tipo_reaccion' => $reaccionData['id_tipo_reaccion'],
                'id_usuario_registra' => $idUsuario, // Relacionar con usuario
            ]);

            // 2. Guardar ESAVI
            if (isset($data['esavi'])) {
                $esaviData = $data['esavi'];
                $esavi = SecEsavi::create([
                    // 'id' => $esaviData['id'],
                    'id_clasificacion_notificador' => $esaviData['id_clasificacion_notificador'],
                    'id_accion_tomada' => $esaviData['id_accion_tomada'],
                    'unidad_efectora_empleado' => $esaviData['unidad_efectora_empleado'] ?? null,
                    'condiciones_medicas_embarazo' => $esaviData['condiciones_medicas_embarazo'] ?? null,
                    'fecha_resolucion_evento' => $esaviData['fecha_resolucion_evento'] ?? null,
                    'fecha_inicio_esavi' => $esaviData['fecha_inicio_esavi'] ?? null,
                    'descripcion_cuadro_clinico' => $esaviData['descripcion_cuadro_clinico'] ?? null,
                    'descripcion_accion_tomada' => $esaviData['descripcion_accion_tomada'] ?? null,
                    'enfermedad_autoinmune' => $esaviData['enfermedad_autoinmune'] ?? null,
                    'medicacion_concomitante' => $esaviData['medicacion_concomitante'] ?? null,
                    'historia_esavi' => $esaviData['historia_esavi'] ?? null,
                    'historia_tipo_reaccion_vacuna' => $esaviData['historia_tipo_reaccion_vacuna'] ?? null,
                    'antecedentes_familiares_esavi' => $esaviData['antecedentes_familiares_esavi'] ?? null,
                    'antecedentes_tipo_reaccion_vacuna' => $esaviData['antecedentes_tipo_reaccion_vacuna'] ?? null,
                    'fecha_egreso_alta' => $esaviData['fecha_egreso_alta'] ?? null,
                    'fecha_muerte_defuncion' => $esaviData['fecha_muerte_defuncion'] ?? null,
                    'autopsia' => $esaviData['autopsia'] ?? null,
                    'id_clasificacion_final' => $esaviData['id_clasificacion_final'],
                    'id_usuario_registra' => $idUsuario, // Relacionar con usuario
                    'id_reaccion_adversa' => $reaccionAdversa->id,  // Relacionar con reaccion_adversa
                ]);
            }

            // 3. Guardar las Vacunas Sospechosas
            if (isset($data['vacunas_sospechosas']) && count($data['vacunas_sospechosas']) > 0) {
                foreach ($data['vacunas_sospechosas'] as $vacuna) {
                    SecVacunaSospechosaEsavi::create([
                        'id_via_administracion' => $vacuna['id_via_administracion'] ?? null,
                        'id_tipo_vacuna' => $vacuna['id_tipo_vacuna'],
                        'id_region_cuerpo' => $vacuna['id_region_cuerpo'] ?? null,
                        'id_recurso_vacunador' => $vacuna['id_recurso_vacunador'] ?? null,
                        'id_marco_aplicacion' => $vacuna['id_marco_aplicacion'] ?? null,
                        'id_lugar_vacunacion' => $vacuna['id_lugar_vacunacion'] ?? null,
                        'id_vacuna' => $vacuna['id_vacuna'],
                        'numero_registro_sanitario' => $vacuna['numero_registro_sanitario'] ?? null,
                        'nombre_comercial' => $vacuna['nombre_comercial'],
                        'numero_dosis' => $vacuna['numero_dosis'] ?? null,
                        'dosis_vacuna_ml' => $vacuna['dosis_vacuna_ml'] ?? null,
                        'otro_sitio_anatomico' => $vacuna['otro_sitio_anatomico'] ?? null,
                        'temperatura_conservacion' => $vacuna['temperatura_conservacion'] ?? null,
                        'direccion_establecimiento' => $vacuna['direccion_establecimiento'] ?? null,
                        'otra_indicacion_medica' => $vacuna['otra_indicacion_medica'] ?? null,
                        'otra_via_administracion' => $vacuna['otra_via_administracion'] ?? null,
                        'laboratorio' => $vacuna['laboratorio'] ?? null,
                        'lote' => $vacuna['lote'] ?? null,
                        'fecha_vencimiento' => $vacuna['fecha_vencimiento'] ?? null,
                        'fecha_vacunacion' => $vacuna['fecha_vacunacion'] ?? null,
                        'hora_vacunacion' => $vacuna['hora_vacunacion'] ?? null,
                        'otro_recurso_vacunador' => $vacuna['otro_recurso_vacunador'] ?? null,
                        'resguarda_frasco' => $vacuna['resguarda_frasco'] ?? null,
                        'total_vacunas_aplicadas' => $vacuna['total_vacunas_aplicadas'] ?? null,
                        'total_vacunas_establecimientos' => $vacuna['total_vacunas_establecimientos'] ?? null,
                        'id_usuario_registra' => $idUsuario, // Relacionar con usuario
                        'id_esavi' => $esavi->id,  // Relacionar con sec_esavi
                    ]);
                }
            }

            // 4. Guardar Examenes laboratorio
            if (isset($data['examenes_laboratorio']) && count($data['examenes_laboratorio']) > 0) {
                foreach ($data['examenes_laboratorio'] as $examen) {
                    MntRaExamenesLaboratorioProcedimientos::create([
                        'examen_realizado' => $examen['examen_realizado'],
                        'id_tipo_muestra' => $examen['id_tipo_muestra'],
                        'resultados' => $examen['resultados'],
                        'fecha_realizacion' => $examen['fecha_realizacion'],
                        'id_usuario_registra' => $idUsuario, // Relacionar con usuario
                        'id_esavi' => $esavi->id,  // Relacionar con sec_esavi
                    ]);
                }
            }

            // 5. Guardar Vacunas Concomitantes
            if(isset($data['vacunas_concomitantes']) && count($data['vacunas_concomitantes']) > 0) {
                foreach ($data['vacunas_concomitantes'] as $vacuna) {
                    MntRaVacunasConcomitantes::create([
                        'id_region_cuerpo' => $vacuna['id_region_cuerpo'],
                        'id_via_administracion' => $vacuna['id_via_administracion'],
                        'id_vacuna' => $vacuna['id_vacuna'],
                        'id_tipo_vacuna' => $vacuna['id_tipo_vacuna'],
                        'nombre_vacuna' => $vacuna['nombre_vacuna'],
                        'dosis_vacuna' => $vacuna['dosis_vacuna'],
                        'laboratorio_vacuna' => $vacuna['laboratorio_vacuna'],
                        'temperatura_vacuna' => $vacuna['temperatura_vacuna'],
                        'fecha_vencimiento_vacuna' => $vacuna['fecha_vencimiento_vacuna'],
                        'lote_vacuna' => $vacuna['lote_vacuna'],
                        'id_usuario_registra' => $idUsuario, // Relacionar con usuario
                        'id_esavi' => $esavi->id,  // Relacionar con sec_esavi
                    ]);
                }
            }

            // 6. Guardar las Reacciones Presentadas
            if (isset($data['reacciones_presentadas']) && count($data['reacciones_presentadas']) > 0) {
                foreach ($data['reacciones_presentadas'] as $reaccion) {
                    MntRaReaccionesPresentadas::create([
                        'codigo' => $reaccion['codigo'],
                        'label_codigo_snomed' => $reaccion['label_codigo_snomed'],
                        'id_usuario_registra' => $idUsuario, // Relacionar con usuario
                        'id_esavi' => $esavi->id,  // Relacionar con sec_esavi
                    ]);
                }
            }

            // 7. Guardar los Diagnósticos en sec_diagnosticos
            if (isset($data['diagnosticos']) && count($data['diagnosticos']) > 0) {
                foreach ($data['diagnosticos'] as $diagnostico) {
                    SecRaDiagnostico::create([
                        'id_tipo_diagnostico' => $diagnostico['id_tipo_diagnostico'],
                        'id_cie10' => $diagnostico['id_cie10'],
                        'id_tipo_consulta' => $diagnostico['id_tipo_consulta'],
                        'id_vacuna' => $diagnostico['id_vacuna'],
                        'observacion' => $diagnostico['observacion'] ?? null,
                        'confirmado' => $diagnostico['confirmado'],
                        'presuntivo' => $diagnostico['presuntivo'],
                        'id_usuario_registra' => $idUsuario, // Relacionar con usuario
                        'id_esavi' => $esavi->id,  // Relacionar con sec_esavi
                    ]);
                }
            }

            // Confirmar transacción
            DB::commit();

            // Devolver respuesta de éxito
            return response()->json([
                'success' => true,
                'message' => 'Datos guardados correctamente.',
                'reaccion_adversa' => $reaccionAdversa,
            ], 201);

        } catch (\Throwable $th) {
            // Revertir transacción en caso de error
            DB::rollBack();

            // Devolver respuesta de error
            return response()->json([
                'success' => false,
                'message' => 'Ocurrió un error al guardar los datos: ' . $th->getMessage(),
            ], 500);
        }
        
    }

    public function obtener_reacciones_adversas(Request $request)
    {
        $filtros = $request->json()->all();
        $fechaInicio = null;
        $fechaFin = null;
        if ( isset($filtros['fechaInicio']) ) {
            $fechaInicio = Carbon::parse($filtros['fechaInicio'])->startOfDay()->format('Y-m-d H:i:s');
            $fechaFin = Carbon::parse($filtros['fechaFin'])->endOfDay()->format('Y-m-d H:i:s');            
        }

        $reacciones_adversas = SecReaccionAdversa::from('sec_reaccion_adversa as ra')
        ->join('mnt_expediente as me', function($join) {
            $join->on('me.id_paciente', '=', 'ra.id_paciente')
                ->on('me.id_establecimiento', '=', 'ra.id_establecimiento');
        })
        ->with([
            'formaDetectarCaso:id,nombre,nombre_corto',
            'tipoEvento:id,nombre,nombre_corto',
            'establecimiento',
            'establecimiento.tipoEstablecimiento:id,nombre',
            'profesion:id,nombre,nombre_corto',
            'condicionDesenlace:id,nombre,nombre_corto',
            'pais:id,nombre',
            'empleado:id,nombre,apellido,numero_celular,correo_electronico',
            'paciente:id,primer_nombre,segundo_nombre,primer_apellido,segundo_apellido,numero_doc_ide_paciente,id_sexo,id_pais_nacimiento,id_doc_ide_paciente,id_departamento_domicilio,id_municipio_domicilio,id_canton_domicilio',
            'paciente.sexo:id,nombre',
            'paciente.paisNacimiento:id,nombre',
            'paciente.departamentoDomicilio:id,nombre',
            'paciente.municipioDomicilio:id,nombre',
            'paciente.docIdePaciente:id,nombre,abreviatura',
            'esavi.diagnosticos.cie10:id,codigo,diagnostico',
            'esavi.reaccionesPresentadas',
            'esavi.vacunasSospechosas' => function ($query) {
                $query
                ->with([
                    'viaAdministracion:id,nombre,abreviatura',
                    'regionCuerpo:id,nombre',
                    'recursoVacunador:id,nombre,nombre_corto,descripcion,activo',
                    'marcoAplicacion:id,nombre,nombre_corto,descripcion,activo',
                    'lugarVacunacion:id,nombre,nombre_corto,descripcion,activo',
                    'vacuna:id',
                    'tipoVacuna:id,nombre,descripcion',
                ]);
            }
        ])
        ->when($fechaInicio && $fechaFin, function ($query) use ($fechaInicio, $fechaFin) {
            $query->whereBetween('ra.created_at', [$fechaInicio, $fechaFin]);
        })
        ->select('ra.*', 'me.id as id_exp','me.numero') // Selecciona las columnas que necesitas
        ->orderBy('ra.id', 'asc')
        ->paginate(20);

        $response = $reacciones_adversas->map(function ($reaccion_adversa) {
            return [
                'id' => $reaccion_adversa->id,
                'reaccion_adversa' => [
                    'id' => $reaccion_adversa->id,
                    'forma_detectar_caso' => $reaccion_adversa->formaDetectarCaso,
                    'tipo_evento' => $reaccion_adversa->tipoEvento,
                    'establecimiento' => [
                        'id' => $reaccion_adversa->establecimiento->id,
                        'nombre' => $reaccion_adversa->establecimiento->nombre,
                        'tipo_establecimiento' => $reaccion_adversa->establecimiento->tipoEstablecimiento->nombre,
                    ],
                    'profesion' => $reaccion_adversa->profesion,
                    'condicion_desenlace' => $reaccion_adversa->condicionDesenlace,
                    'empleado' => $reaccion_adversa->empleado->nombre . ' ' . $reaccion_adversa->empleado->apellido ?? '',
                    'telefono_empleado' => $reaccion_adversa->empleado->numero_celular ?? '',
                    'correo_empleado' => $reaccion_adversa->empleado->correo_electronico ?? '',
                    'titulo_reporte' => $reaccion_adversa->titulo_reporte,
                    'fecha_notificacion' => $reaccion_adversa->fecha_notificacion,
                    'forma_detectar_especifique' => $reaccion_adversa->forma_detectar_especifique,
                    'paciente_grave' => $reaccion_adversa->paciente_grave,
                    'peso' => $reaccion_adversa->peso,
                    'talla' => $reaccion_adversa->talla,
                    'emabarazo' => $reaccion_adversa->emabarazo == null ? false : $reaccion_adversa->emabarazo,
                    'lactando' => $reaccion_adversa->lactando == null ? false : $reaccion_adversa->lactando,
                    'semana_gestacional' => $reaccion_adversa->semana_gestacional ?? 0,
                    'edad_lactante' => $reaccion_adversa->edad_lactante,
                    'responsable' => $reaccion_adversa->responsable,
                    'fecha_deteccion' => $reaccion_adversa->fecha_deteccion,
                    'fecha_ingreso' => $reaccion_adversa->fecha_ingreso,
                    'antecedentes' => $reaccion_adversa->antecedentes,
                    'otros_antecedentes' => $reaccion_adversa->otros_antecedentes,
                    'pais' => $reaccion_adversa->pais,
                    'expediente' => [
                        'id' => $reaccion_adversa->id_exp,
                        'numero' => $reaccion_adversa->numero,
                        'paciente' => [
                            'id' => $reaccion_adversa->paciente->id,
                            'primer_nombre' => $reaccion_adversa->paciente->primer_nombre,
                            'segundo_nombre' => $reaccion_adversa->paciente->segundo_nombre,
                            'tercer_nombre' => $reaccion_adversa->paciente->tercer_nombre,
                            'primer_apellido' => $reaccion_adversa->paciente->primer_apellido,
                            'segundo_apellido' => $reaccion_adversa->paciente->segundo_apellido,
                            'apellido_casada' => $reaccion_adversa->paciente->apellido_casada,
                            'fecha_nacimiento' => $reaccion_adversa->paciente->fecha_nacimiento,
                            'numero_doc_ide_paciente' => $reaccion_adversa->paciente->numero_doc_ide_paciente,
                            'tipo_doc_id_paciente' => $reaccion_adversa->paciente->docIdePaciente,
                            'direccion' => $reaccion_adversa->paciente->direccion,
                            'telefono_casa' => $reaccion_adversa->paciente->telefono_casa,
                            'sexo' => $reaccion_adversa->paciente->sexo,
                            'pais' => $reaccion_adversa->paciente->paisNacimiento,
                            'departamento' => $reaccion_adversa->paciente->departamentoDomicilio,
                            'municipio' => $reaccion_adversa->paciente->municipioDomicilio,
                        ],
                    ],                    
                    'sec_ra_diagnostico' => $reaccion_adversa->esavi->diagnosticos->map(function ($diagnostico) {
                        return [
                            'id' => $diagnostico->id,
                            'id_tipo_diagnostico' => $diagnostico->id_tipo_diagnostico,
                            'cie10' => [
                                'id' => $diagnostico->cie10->id,
                                'codigo' => $diagnostico->cie10->codigo,
                                'diagnostico' => $diagnostico->cie10->diagnostico,
                                'estandar' => 'cie',
                                'version' => '10',
                            ],
                            'tipo_consulta' => [
                                'id' => $diagnostico->tipoConsulta->id,
                                'nombre' => $diagnostico->tipoConsulta->nombre,
                            ],
                            'confirmado' => $diagnostico->confirmado,
                            'especificacion' => $diagnostico->especificacion ?? '',
                        ];
                    }),
                    'clasificacion_notificador' => [
                        'id' => $reaccion_adversa->esavi->clasificacionNotificador->id,
                        'nombre' => $reaccion_adversa->esavi->clasificacionNotificador->nombre,
                        'nombre_corto' => $reaccion_adversa->esavi->clasificacionNotificador->nombre_corto,
                        'descripcion' => $reaccion_adversa->esavi->clasificacionNotificador->descripcion ?? '',
                    ],
                    'accion_tomada' => [
                        'id' => $reaccion_adversa->esavi->accionTomada->id,
                        'nombre' => $reaccion_adversa->esavi->accionTomada->nombre,
                        'nombre_corto' => $reaccion_adversa->esavi->accionTomada->nombre_corto,
                        'descripcion' => $reaccion_adversa->esavi->accionTomada->descripcion ?? '',
                        'modulo' => $reaccion_adversa->esavi->accionTomada->modulo,
                    ],
                    'unidad_efectora_empleado' => $reaccion_adversa->esavi->unidad_efectora_empleado,
                    'condiciones_medicas_embarazo' => $reaccion_adversa->esavi->condiciones_medicas_embarazo,
                    'fecha_resolucion_evento' => $reaccion_adversa->esavi->fecha_resolucion_evento,
                    'descripcion_cuadro_clinico' => $reaccion_adversa->esavi->descripcion_cuadro_clinico,
                    'descripcion_accion_tomada' => $reaccion_adversa->esavi->descripcion_accion_tomada,
                    'enfermedad_autoinmune' => $reaccion_adversa->esavi->enfermedad_autoinmune,
                    'medicacion_concomitante' => $reaccion_adversa->esavi->medicacion_concomitante,
                    'historia_esavi' => $reaccion_adversa->esavi->historia_esavi,
                    'historia_tipo_reaccion_vacuna' => $reaccion_adversa->esavi->historia_tipo_reaccion_vacuna,
                    'antecedentes_familiares_esavi' => $reaccion_adversa->esavi->antecedentes_familiares_esavi,
                    'antecedentes_tipo_reaccion_adversa' => $reaccion_adversa->esavi->antecedentes_tipo_reaccion_adversa,
                    'fecha_egreso_alta' => $reaccion_adversa->esavi->fecha_egreso_alta,
                    'fecha_muerte_defuncion' => $reaccion_adversa->esavi->fecha_muerte_defuncion,
                    'reacciones_presentadas' => $reaccion_adversa->esavi->reaccionesPresentadas->map(function ($reaccion){
                        return [
                            'id' => $reaccion->id,
                            'codigo' => $reaccion->codigo,
                            'label_codigo_snomed' => $reaccion->label_codigo_snomed,
                            'estandard' => 'snomed',
                            'version' => '8.1.0',
                        ];
                    }),
                    'vacunas_concomitantes' => $reaccion_adversa->esavi->vacunasConcomitantes->isNotEmpty() ? $reaccion_adversa->esavi->vacunasConcomitantes->map(function ($concomitantes){
                        return [
                            'region_cuerpo' => [
                                'id' => $concomitantes->regionCuerpo->id,
                                'nombre' => $concomitantes->regionCuerpo->nombre,
                                'descripcion' => $concomitantes->regionCuerpo->descripcion,
                            ],
                            'via_administracion' => [
                                'id' => $concomitantes->viaAdministracion->id,
                                'nombre' => $concomitantes->viaAdministracion->nombre,
                                'abreviatura' => $concomitantes->viaAdministracion->abreviatura,
                            ],
                            'nombre_vacuna' => $concomitantes->nombre_vacuna,
                            'tipo_vacuna' => [
                                'id' => $concomitantes->tipoVacuna->id,
                                'nombre' => $concomitantes->tipoVacuna->nombre,
                                'descripcion' => $concomitantes->tipoVacuna->descripcion,
                            ],
                            'dosis_vacuna' => $concomitantes->dosis_vacuna,
                            'laboratorio_vacuna' => $concomitantes->laboratorio_vacuna,
                            'fecha_vencimiento' => $concomitantes->fecha_vencimiento_vacuna,
                        ];
                    }) : null,
                    'vacuna_sospechosa' => [
                        'via_administracion' => $reaccion_adversa->esavi->vacunasSospechosas->viaAdministracion,
                        'region_cuerpo' => $reaccion_adversa->esavi->vacunasSospechosas->regionCuerpo,
                        'recurso_vacunador' => $reaccion_adversa->esavi->vacunasSospechosas->recursoVacunador,
                        'marco_aplicacion' => $reaccion_adversa->esavi->vacunasSospechosas->marcoAplicacion,
                        'lugar_aplicacion' => $reaccion_adversa->esavi->vacunasSospechosas->lugarVacunacion,
                        'id_vacuna' => $reaccion_adversa->esavi->vacunasSospechosas->vacuna->id,
                        'tipo_vacuna' => $reaccion_adversa->esavi->vacunasSospechosas->tipoVacuna,
                        'numero_registro_sanitario' => $reaccion_adversa->esavi->vacunasSospechosas->numero_registro_sanitario,
                        'nombre_comercial' => $reaccion_adversa->esavi->vacunasSospechosas->nombre_comercial,
                        'numero_dosis' => $reaccion_adversa->esavi->vacunasSospechosas->numero_dosis,
                        'dosis_vacuna_ml' => $reaccion_adversa->esavi->vacunasSospechosas->dosis_vacuna_ml,
                        'otro_sitio_anatomico' => $reaccion_adversa->esavi->vacunasSospechosas->otro_sitio_anatomico,
                        'temperatura_conservacion' => $reaccion_adversa->esavi->vacunasSospechosas->temperatura_conservacion,
                        'direccion_establecimiento' => $reaccion_adversa->esavi->vacunasSospechosas->direccion_establecimiento,
                        'otra_indicacion_medica' => $reaccion_adversa->esavi->vacunasSospechosas->otra_indicacion_medica,
                        'otra_via_administracion' => $reaccion_adversa->esavi->vacunasSospechosas->otra_via_administracion,
                        'laboratorio' => $reaccion_adversa->esavi->vacunasSospechosas->laboratorio,
                        'lote' => $reaccion_adversa->esavi->vacunasSospechosas->lote,
                        'fecha_vencimiento' => $reaccion_adversa->esavi->vacunasSospechosas->fecha_vencimiento,
                        'fecha_vacunacion' => $reaccion_adversa->esavi->vacunasSospechosas->fecha_vacunacion,
                        'hora_vacunacion' => $reaccion_adversa->esavi->vacunasSospechosas->hora_vacunacion,
                        'otro_recurso_vacunador' => $reaccion_adversa->esavi->vacunasSospechosas->otro_recurso_vacunador,
                        'resguarda_frasco' => $reaccion_adversa->esavi->vacunasSospechosas->resguarda_frasco,
                        'total_vacunas_aplicadas' => $reaccion_adversa->esavi->vacunasSospechosas->total_vacunas_aplicadas,
                        'total_vacunas_establecimientos' => $reaccion_adversa->esavi->vacunasSospechosas->total_vacunas_establecimientos,
                    ],
                ],
            ];
        });

        return response()->json([
            'data' => $response,
            'pagination' => [
                'total' => $reacciones_adversas->total(),
                'per_page' => $reacciones_adversas->perPage(),
                'current_page' => $reacciones_adversas->currentPage(),
                'last_page' => $reacciones_adversas->lastPage(),
                'from' => $reacciones_adversas->firstItem() ?? 0,
                'to' => $reacciones_adversas->lastItem() ?? 0,
            ],
        ]);
    }

}
