<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CtlRaFormaDetectarCaso extends Model
{
    use HasFactory;

    // Especifica la tabla asociada al modelo
    protected $table = 'ctl_ra_forma_detectar_caso';

    // Define los atributos que pueden ser asignados masivamente
    protected $fillable = [
        'nombre_corto',
        'nombre',
        'descripcion',
        'activo'
    ];

    public function esavi()
    {
        return $this->hasMany(SecEsavi::class, 'id_forma_detectar_caso');
    }
}
