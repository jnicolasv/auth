<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('sec_ram', function (Blueprint $table) {
            $table->id();

            $table->unsignedBigInteger('id_reaccion_adversa');
            $table->boolean('paciente_hospitalizado');
            $table->timestamp('fecha_alta')->nullable();
            $table->string('indicaciones_uso_medicamento', 120)->nullable();
            $table->string('examenes_laboratorio', 200)->nullable();
            $table->unsignedBigInteger('id_rb_desaparece_reaccion')->nullable();
            $table->unsignedBigInteger('id_rb_reaparece_reaccion')->nullable();
            $table->unsignedBigInteger('id_rb_antecedentes_reacciones_adversas')->nullable();
            $table->boolean('discapacidad_por_ram');
            $table->string('descripcion_discapacidad', 250)->nullable();
            $table->boolean('ram_por_tb')->default(false);
            $table->unsignedBigInteger('id_usuario_registra')->nullable();
            $table->unsignedBigInteger('id_accion_tomada')->nullable();

            $table->foreign('id_reaccion_adversa')->references('id')->on('sec_reaccion_adversa')->onDelete('restrict')->onUpdate('cascade');
            $table->foreign('id_rb_desaparece_reaccion')->references('id')->on('ctl_respuesta_basica');
            $table->foreign('id_rb_reaparece_reaccion')->references('id')->on('ctl_respuesta_basica');
            $table->foreign('id_rb_antecedentes_reacciones_adversas')->references('id')->on('ctl_respuesta_basica');
            $table->foreign('id_accion_tomada')->references('id')->on('ctl_ra_accion_tomada');
            $table->foreign('id_usuario_registra')->references('id')->on('fos_user_user')->onDelete('restrict')->onUpdate('cascade');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('sec_ram');
    }
};
