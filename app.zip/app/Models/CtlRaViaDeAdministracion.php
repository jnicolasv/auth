<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CtlRaViaDeAdministracion extends Model
{
    use HasFactory;

    protected $table = 'ctl_ra_via_de_administracion';

    protected $fillable = [
        'nombre_corto',
        'nombre',
        'descripcion',
        'activo',
    ];

    // Relaciones
    public function vacunasConcomitantes()
    {
        return $this->hasMany(MntRaVacunasConcomitantes::class, 'id_via_administracion');
    }
}
