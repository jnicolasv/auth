<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>@yield('title', 'Login')</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />

    <link href="https://fonts.cdnfonts.com/css/museo-sans-rounded" rel="stylesheet">

    {{-- <link href="{{ asset('build/css/app.css') }}" rel="stylesheet">
    <script src="{{ asset('build/js/app.js') }}"></script> --}}


    {{-- <script src="https://cdn.tailwindcss.com"></script>
    <!-- Cargar estilos con Vite --> --}}
    {{-- @vite('resources/css/output.css') --}}
    <link rel="stylesheet" href="{{ asset('css/output.css') }}">

</head>
<body class="bg-[#EDF3FF] h-screen flex flex-col justify-between">
        <!-- Contenedor principal -->
    <div class="flex flex-grow flex-col lg:flex-row">

        <!-- Imagen a la izquierda -->
        <div class="lg:w-1/2 xl:w-2/3 w-full h-60 lg:h-full">
            <img src="{{ asset('images/img-login.png') }}" alt="Estadísticas" class="w-full h-full object-cover">
        </div>

        <!-- Login a la derecha -->
        <div class="lg:w-1/2 xl:w-1/3 w-full h-full flex items-center justify-center p-6">
            <div class="bg-white/90 shadow-2xl rounded-lg p-6 lg:p-8 w-full h-full flex flex-col justify-center mx-auto px-10 2xl:px-20">
                <div class="text-center mb-10">
                    <!-- Aquí puedes colocar los logos -->
                    <img src="{{ asset('images/logo.png') }}" alt="Logo" class="mx-auto h-30 max-h-30 mb-4 w-auto">
                    <h2 class="text-2xl font-bold text-[#576ca9] mt-8">
                        Sistema Centralizado de Reacciones Adversas
                    </h2>
                </div>

                <div id="zona_inicio_sesion">
                    <!-- Formulario Inicio de sesion -->
                    <!-- Recuperar cuenta -->
                    @yield('content')
                </div>

            </div>
        </div> <!-- Fin Login -->

    </div>

    <!-- Footer -->
    <footer class="bg-[#576ca9] text-white text-right py-2 pr-4 text-sm lg:text-base">
        <stron>Dirección de Tecnologías de Información y Comunicaciones © 2025</stron>
    </footer>

    {{-- <script>
        document.getElementById('zona_recuperar_contra').style.display = 'none';

        document.getElementById('btn_recuperar_contra').addEventListener('click', function(event) {
            event.preventDefault();
            document.getElementById('zona_recuperar_contra').style.display = 'block';
            document.getElementById('zona_inicio_sesion').style.display = 'none';
        });

        document.getElementById('bnt_cancelar_recuperacion').addEventListener('click', function(event) {
            event.preventDefault();
            document.getElementById('zona_recuperar_contra').style.display = 'none';
            document.getElementById('zona_inicio_sesion').style.display = 'block';
        });
    </script> --}}

    <!-- Cargar scripts con Vite -->
    {{-- @vite('resources/js/app.js') --}}
    {{-- <script src="{{ asset('js/app.js') }}"></script> --}}

</body>
</html>
