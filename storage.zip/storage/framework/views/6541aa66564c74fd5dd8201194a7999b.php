<?php $__env->startSection('title', 'Usuarios'); ?>

<?php $__env->startSection('content'); ?>
<div class="p-6">
    <!-- Filters -->
    <div class="bg-white p-4 rounded shadow mb-4">
        <div class="border-2 border-[#576ca9] bg-[#edf3ff] p-2 rounded-2xl mb-4 text-center">
            <h2 class="text-xl font-semibold text-[#576ca9]">Usuarios del Sistema</h2>
        </div>
        
        <!-- Formulario de filtros -->
        <form method="GET" action="<?php echo e(route('users.index')); ?>" class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-x-4 gap-y-6 mt-6">

            <div class="input-container">
                <label for="name" class="input-label">Nombre</label>
                <input type="text" id="name" name="name" class="input-field" value="<?php echo e(old('name', $filters['name'] ?? '')); ?>">
            </div>
            <div class="input-container">
                <label for="role" class="input-label">Tipo de Usuario</label>
                <select id="role" name="role" class="select-field bg-white">
                    <option value="" disabled selected>Seleccione</option>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($role->name); ?>" <?php echo e((old('role', $filters['role'] ?? '') == $role->name) ? 'selected' : ''); ?>>
                            <?php echo e($role->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="input-container">
                <label for="status" class="input-label">Estado</label>
                <select id="status" name="status" class="select-field bg-white">
                    <option value="" disabled selected>Seleccione</option>
                    <option value="Habilitado" <?php echo e((old('status', $filters['status'] ?? '') == 'Habilitado') ? 'selected' : ''); ?>>Habilitado</option>
                    <option value="Deshabilitado" <?php echo e((old('status', $filters['status'] ?? '') == 'Deshabilitado') ? 'selected' : ''); ?>>Deshabilitado</option>
                </select>
            </div>
            <!-- Botones agrupados -->
            <div class="input-container">
                <button type="submit" class="input-button btn-primary">FILTRAR</button>
            </div>
            <div class="input-container">
                <a href="<?php echo e(route('users.index')); ?>" class="input-button btn-secondary">LIMPIAR</a>
            </div>

        </form>
        <hr class="col-span-3 my-4 border-t border-[#576ca9]">
        <div class="col-span-1 flex justify-end mb-4">
            <a href="<?php echo e(route('users.create')); ?>" class="bg-[#576ca9] hover:bg-[#455a8a] text-white pt-3.5 pb-3 px-4 rounded inline-flex items-center text-base">
                <span class="material-symbols-outlined mr-2 text-base">person_add</span>
                AGREGAR USUARIO
            </a>
        </div>

        <!-- Notificaciones -->
        <div id="notificaciones">
            <?php if(session('success')): ?>
                <div class="bg-green-500 text-white p-2 mt-4 rounded-md relative">
                    <div class="flex items-center gap-2">
                        <span class="material-symbols-outlined">check_circle</span> 
                        <span><?php echo e(session('success')); ?></span>
                    </div>
                    <button class="notification-close-button" onclick="this.parentElement.style.display='none';"><span class="material-symbols-outlined">close</span></button>
                </div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="bg-red-500 text-white p-2 mt-4 rounded-md relative">
                    <div class="flex items-center gap-2">
                        <span class="material-symbols-outlined">cancel</span> 
                        <span><?php echo e(session('error')); ?></span>
                    </div>
                    <button class="notification-close-button" onclick="this.parentElement.style.display='none';"><span class="material-symbols-outlined">close</span></button>
                </div>
            <?php endif; ?>
        
            <?php if(session('warning')): ?>
                <div class="bg-yellow-500 text-white p-2 mt-4 rounded-md relative">
                    <div class="flex items-center gap-2">
                        <span class="material-symbols-outlined">error</span> 
                        <span><?php echo e(session('warning')); ?></span>
                    </div>
                    <button class="notification-close-button" onclick="this.parentElement.style.display='none';"><span class="material-symbols-outlined">close</span></button>
                </div>
            <?php endif; ?>
        
            <?php if(session('info')): ?>
                <div class="bg-blue-500 text-white p-2 mt-4 rounded-md relative">
                    <div class="flex items-center gap-2">
                        <span class="material-symbols-outlined">info</span> 
                        <span><?php echo e(session('info')); ?></span>
                    </div>
                    <button class="notification-close-button" onclick="this.parentElement.style.display='none';"><span class="material-symbols-outlined">close</span></button>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- Tabla de usuarios -->
        <div class="bg-white p-4 rounded shadow overflow-x-auto responsive-table">
            <table class="w-full border-collapse border border-gray-200">
                <thead class="bg-[#576ca9] text-white">
                    <tr>
                        <th class="p-2 border">Nombre</th>
                        <th class="p-2 border">Apellido</th>
                        <th class="p-2 border">Correo</th>
                        <th class="p-2 border">Tipo usuario</th>
                        <th class="p-2 border">Estado</th>
                        <th class="p-2 border">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="odd:bg-gray-100">
                            
                            <td class="p-2 border">
                                <?php echo e($user->persona->primer_nombre ?? ''); ?>

                                <?php echo e($user->persona->segundo_nombre ?? ''); ?>

                                <?php echo e($user->persona->tercer_nombre ?? ''); ?>

                            </td>
                            <td class="p-2 border">
                                <?php echo e($user->persona->primer_apellido ?? ''); ?>

                                <?php echo e($user->persona->segundo_apellido ?? ''); ?>

                            </td>
                            <td class="p-2 border"><?php echo e($user->email); ?></td>
                            <td class="p-2 border"><?php echo e($user->getRoleNames()->implode(', ')); ?></td>
                            <td class="p-2 border text-center">
                                <?php if(auth()->id() === $user->id): ?>
                                    <span id="status-<?php echo e($user->id); ?>" class="<?php echo e($user->status == 'Deshabilitado' ? 'btn-disable' : 'btn-enable'); ?>">
                                        <?php echo e($user->status); ?>

                                    </span>
                                <?php else: ?>
                                    <span id="status-<?php echo e($user->id); ?>" class="<?php echo e($user->status == 'Deshabilitado' ? 'btn-disable' : 'btn-enable'); ?>" onclick="toggleStatus(<?php echo e($user->id); ?>)">
                                        <?php echo e($user->status); ?>

                                    </span>
                                <?php endif; ?>
                            </td>                            
                            <td class="p-2 border text-center">
                                <div class="flex justify-center space-x-3">
                                    <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="text-[#576ca9]"><span class="material-symbols-outlined">edit_square</span></a>
                                    <?php if(auth()->user()->hasRole('Superadmin')): ?>
                                        <button type="button" class="text-red-500" onclick="showDeleteModal(<?php echo e($user->id); ?>, '<?php echo e($user->email); ?>')"><span class="material-symbols-outlined">delete</span></button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <!-- Paginación -->
            <div class="mt-6">
                <div class="pagination">
                    <?php echo e($users->appends(request()->query())->links()); ?>

                </div>
            </div>
            
        </div> <!-- Fin de la tabla de usuarios -->

    </div>
</div>

<!-- Modal de Confirmación -->
<div id="deleteModal" class="hidden fixed z-50 inset-0 bg-gray-800 bg-opacity-50 flex items-center justify-center">
    <div class="bg-white p-6 rounded shadow-lg w-3/4 md:w-2/3 lg:w-2/4">
        <h2 class="text-xl font-semibold text-gray-800 mb-4 flex items-center">
            <span class="material-symbols-outlined mr-2">warning</span>
            Confirmar eliminación
        </h2>
        <p id="confirmationMessage"></p>
        <div class="flex justify-end mt-4">
            <form id="deleteForm" method="POST" action="">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="bg-red-500 text-white py-2 px-4 rounded mr-2">
                    Sí, eliminar
                </button>
            </form>
            <button onclick="closeDeleteModal()" class="bg-gray-500 text-white py-2 px-4 rounded">
                Cancelar
            </button>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    // Validar que el campo de filtro nombre solo se puedan ingresar letras y espacios
    document.getElementById('name').addEventListener('keyup', function (e) {
        const regex = /[^a-zA-Z\s]/g;
        e.target.value = e.target.value.replace(regex, '');
    });

    function showDeleteModal(userId, email) {
        const deleteModal = document.getElementById('deleteModal');
        const deleteForm = document.getElementById('deleteForm');
        const confirmationMessage = document.getElementById('confirmationMessage');
        confirmationMessage.textContent = `¿Estás seguro de que deseas eliminar el usuario con correo: ${email}? Esta acción no se puede deshacer.`;
        deleteForm.action = `/users/${userId}`;
        deleteModal.classList.remove('hidden');
    }

    function closeDeleteModal() {
        const deleteModal = document.getElementById('deleteModal');
        deleteModal.classList.add('hidden');
    }

    function toggleStatus(userId) {
        fetch(`/users/${userId}/toggle-status`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
            }
        })
        .then(response => response.json())
        .then(data => {
            const notificationsDiv = document.getElementById('notificaciones');
            notificationsDiv.innerHTML = ''; // Limpiar notificaciones anteriores

            if (data.error) {
                // Mostrar notificación de error
                const errorNotification = document.createElement('div');
                errorNotification.className = 'bg-red-500 text-white p-2 mt-4 rounded-md relative';
                errorNotification.textContent = data.error;
                const closeButton = document.createElement('button');
                closeButton.className = 'notification-close-button';
                closeButton.innerHTML = '<span class="material-symbols-outlined">close</span>';
                closeButton.onclick = function() {
                    errorNotification.style.display = 'none';
                };
                errorNotification.appendChild(closeButton);
                notificationsDiv.appendChild(errorNotification);
            } else {
                const statusElement = document.getElementById(`status-${userId}`);
                statusElement.textContent = data.status;
                statusElement.className = data.status == 'Deshabilitado' ? 'btn-disable' : 'btn-enable';

                // Mostrar notificación de éxito
                const successNotification = document.createElement('div');
                successNotification.className = 'bg-green-500 text-white p-2 mt-4 rounded-md relative';
                successNotification.textContent = 'Estado actualizado correctamente.';
                const closeButton = document.createElement('button');
                closeButton.className = 'notification-close-button';
                closeButton.innerHTML = '<span class="material-symbols-outlined">close</span>';
                closeButton.onclick = function() {
                    successNotification.style.display = 'none';
                };
                successNotification.appendChild(closeButton);
                notificationsDiv.appendChild(successNotification);
            }
        })
        .catch(error => console.error('Error:', error));
    }
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/users/index.blade.php ENDPATH**/ ?>