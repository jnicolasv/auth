<?php

namespace App\Http\Controllers\web;

use App\Http\Controllers\Controller;
use App\Models\MntPersona;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Role;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Log;
use Spatie\Permission\Models\Permission;
use App\Mail\SendPasswordMail;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Validator;

class UserController extends Controller
{
    public function index(Request $request)
    {
        // Usuario en sesion
        $userAuth = Auth::user();
        $roleAuth = $userAuth->roles->first()->name;

        $query = User::query()
                ->select('users.*')
                ->leftJoin('mnt_persona', 'users.id', '=', 'mnt_persona.usuario_id');
        
        // Filtro por nombre
        if ($request->has('name')) {
            $searchTerm = '%' . $request->input('name') . '%';
            $query->where(function ($q) use ($searchTerm) {
            $q->where('name', 'like', $searchTerm)
              ->orWhereHas('persona', function ($q) use ($searchTerm) {
                  $q->where('primer_nombre', 'like', $searchTerm)
                ->orWhere('segundo_nombre', 'like', $searchTerm)
                ->orWhere('tercer_nombre', 'like', $searchTerm)
                ->orWhere('primer_apellido', 'like', $searchTerm)
                ->orWhere('segundo_apellido', 'like', $searchTerm);
              });
            });
        }

        // Filtro por rol
        if ($request->has('role')) {
            $query->whereHas('roles', function ($q) use ($request) {
                $q->where('name', $request->input('role'));
            });
        }

        // Filtro por estado
        if ($request->has('status')) {
            $status = $request->input('status') === 'Habilitado' ? true : false;
            $query->where('status', $status);
        }

        // Excluir usuario con nombre 'userApi'
        $query->where('name', '!=', 'userApi');

        // Excluir usuario con rol 'Superadmin'
        $query->whereDoesntHave('roles', function ($query) {
            $query->where('name', 'Superadmin');
        });

        // Excluir el propio usuario
        // $query->where('users.id', '!=', $userAuth->id);

        // Ordenar por nombre de usuario
        $query->orderBy('mnt_persona.primer_nombre')
              ->orderBy('mnt_persona.segundo_nombre')
              ->orderBy('mnt_persona.primer_apellido')
              ->orderBy('mnt_persona.segundo_apellido');

        // Paginación con 10 usuarios por página
        $users = $query->paginate(10);

        // $users = $query->toSql();  // Esto te mostrará la consulta SQL generada
        // dd($users);

        // Roles para los selects
        $roles = Role::all()->filter(function ($role) use ($roleAuth) {
            if ($roleAuth === 'Superadmin') {
                return $role->name !== 'Superadmin'; // Superadmin no ve su propio rol
            }
            if ($roleAuth === 'Administrador') {
                return $role->name !== 'Superadmin' && $role->name !== 'Administrador'; // Admin no ve su propio rol ni el rol Superadmin
            }
            return false; // Otros roles no pueden ver ningún rol
        });

        // dd($roles);

        // Pasar los filtros actuales a la vista
        return view('users.index', [
            'users' => $users,
            'filters' => $request->only('name', 'role', 'status'), // Pasar los filtros actuales para que permanezcan en el formulario
            'roles' => $roles,
        ]);
    }


    public function create()
    {
        $userAuth = Auth::user();
        $roleAuth = $userAuth->roles->first()->name;

        // Roles para los selects
        $roles = Role::all()->filter(function ($role) use ($roleAuth) {
            if ($roleAuth === 'Superadmin') {
                return $role->name !== 'Superadmin'; // Superadmin no ve su propio rol
            }
            if ($roleAuth === 'Administrador') {
                return $role->name !== 'Superadmin' && $role->name !== 'Administrador'; // Admin no ve su propio rol ni el rol Superadmin
            }
            return false; // Otros roles no pueden ver ningún rol
        });

        return view('users.create', compact('roles'));
    }

    public function store(Request $request)
    {
        // Verificar permisos
        $this->authorize('Crear usuarios'); // Lanza 403 si no tiene permiso
        
        // Validaciones
        $request->validate([
            'primer_nombre' => 'required|string|regex:/^[\pL\s]+$/u|min:3|max:25',
            'segundo_nombre' => 'nullable|string|regex:/^[\pL\s]+$/u|min:3|max:25',
            'tercer_nombre' => 'nullable|string|regex:/^[\pL\s]+$/u|min:3|max:25',
            'primer_apellido' => 'required|string|regex:/^[\pL\s]+$/u|min:3|max:25',
            'segundo_apellido' => 'nullable|string|regex:/^[\pL\s]+$/u|min:3|max:25',
            'fecha_nacimiento' => [
                'required',
                'date',
                function ($attribute, $value, $fail) {
                    $age = \Carbon\Carbon::parse($value)->age;
                    if ($age < 18) {
                        $fail('El usuario debe tener al menos 18 años.');
                    }
                },
            ],
            'nro_documento' => 'required|string|regex:/^\d{8}-\d{1}$/|max:10|unique:mnt_persona,nro_documento',
            'correo_institucional' => 'required|email|max:150|unique:users,email|regex:/^[\w\.-]+@salud\.gob\.sv$/',
            'role' => 'required|exists:roles,name',
            'establecimiento' => [
                'required_if:role,Región,Sibasi',
                'exists:ctl_establecimiento,id',
            ],
        ]);
        
        // Verificar los permisos del usuario autenticado, para evitar asignar roles no permitidos
        $userAuth = Auth::user();
        $roleAuth = $userAuth->roles->first()->name;

        if ($roleAuth === 'Administrador' && !in_array($request->role, ['DIRTECS', 'Región', 'Sibasi'])) {
            return back()->with('error', 'No tienes permiso para asignar este rol.');
        }

        if ($roleAuth === 'DIRTECS' && !in_array($request->role, ['Región', 'Sibasi'])) {
            return back()->with('error', 'No tienes permiso para asignar este rol.');
        }

        try {
            // Inciar transacción
            DB::beginTransaction();

            // Generación del nombre de usuario
            $primerNombre = $request->primer_nombre;
            $segundoNombre = $request->segundo_nombre;
            $primerApellido = $request->primer_apellido;

            // Crear el nombre de usuario
            $name = strtolower(substr($primerNombre, 0, 1) . $primerApellido);
            $counter = 1;

            while (User::where('name', $name)->exists()) {
                if ($counter < strlen($primerNombre)) {
                    $name = strtolower(substr($primerNombre, 0, $counter) . $primerApellido);
                } elseif ($segundoNombre && $counter - strlen($primerNombre) < strlen($segundoNombre)) {
                    $name = strtolower(substr($primerNombre, 0, 1) . substr($segundoNombre, 0, $counter - strlen($primerNombre)) . $primerApellido);
                } else {
                    $name = strtolower(substr($primerNombre, 0, 1) . $primerApellido . $counter);
                }
                $counter++;
            }

            // Genera una contraseña aleatoria de 8 caracteres
            $password = Str::random(8);

            // Deshabilitar temporalmente las marcas de tiempo
            // User::unsetEventDispatcher();

            // Normalizar el nombre de usuario
            $name = Str::ascii($name);
            $name = str_replace(['ñ', 'Ñ'], 'ni', $name);

            // Crear el usuario primero
            $user = User::create([
                'name' => $name,
                'email' => $request->correo_institucional,
                'password' => Hash::make($password),
                'status' => $request->has('status') ? (bool)$request->status : true,
            ]);

            // Establecer manualmente el campo created_at
            // $user->created_at = now();
            $user->save();

            // Volver a habilitar las marcas de tiempo
            // User::setEventDispatcher(app('events'));

            // Asegurar que el ID fue asignado
            if (!$user || !$user->id) {
                DB::rollBack();
                throw new \Exception("No se pudo crear el usuario.");
            }

            // Crear la persona asociada al usuario
            MntPersona::create([
                'primer_nombre' => $request->primer_nombre,
                'segundo_nombre' => $request->segundo_nombre,
                'tercer_nombre' => $request->tercer_nombre,
                'primer_apellido' => $request->primer_apellido,
                'segundo_apellido' => $request->segundo_apellido,
                'fecha_nacimiento' => $request->fecha_nacimiento,
                'nro_documento' => $request->nro_documento,
                'establecimiento_id' => $request->establecimiento,
                'usuario_id' => $user->id,
            ]);

            // Asignar el rol al usuario
            $user->assignRole($request->role);

            // Enviar el correo con la contraseña
            /*try {
                Mail::to($user->email)->send(new SendPasswordMail($user, $password));
            } catch (\Exception $e) {
                DB::rollBack(); // Deshacer cambios
                Log::error('Error enviando correo: ' . $e->getMessage());
                return back()->with('error', 'No se pudo enviar el correo con la contraseña. Verifique la configuración de correo.');
            }*/
            try {
                // Generar el enlace de verificación
                $verificationUrl = URL::temporarySignedRoute(
                    'verification.verify',
                    now()->addMinutes(60),
                    ['id' => $user->id, 'hash' => sha1($user->email)]
                );
            
                // Enviar el correo con el enlace de verificación
                Mail::to($user->email)->send(new SendPasswordMail($user, $password, $verificationUrl));
            } catch (\Exception $e) {
                DB::rollBack(); // Deshacer cambios
                Log::error('Error enviando correo: ' . $e->getMessage());
                return back()->with('error', 'No se pudo enviar el correo con la contraseña. Verifique la configuración de correo.');
            }

            // Si todo es exitoso, commit de la transacción
            DB::commit();

            return redirect()->route('users.index')->with('success', 'Usuario creado con éxito.');

        } catch (\Exception $e) {
            // Si ocurre algún error, se revierte la transacción
            DB::rollBack();
            return back()->with('error', 'Hubo un problema al crear el usuario. Por favor, intenta de nuevo.');
            // Registrar el log del error
            Log::error('Error al crear usuario: ' . $e->getMessage());
        }

    }

    public function verifyEmail($id, $hash)
    {
        // Buscar el usuario por el ID
        $user = User::findOrFail($id);

        // Comprobar si el hash es válido para el correo del usuario
        if (!hash_equals(sha1($user->getEmailForVerification()), $hash)) {
            return redirect()->route('login')->with('error', 'El enlace de verificación no es válido.');
        }

        // Actualizar el campo email_verified_at con la fecha y hora actual
        if ($user->update(['email_verified_at' => now()])) {
            return redirect()->route('login')->with('status', 'Email verificado correctamente.');
        } else {
            return redirect()->route('login')->with('error', 'No se pudo verificar el email.');
        }
        
    }

    public function edit(User $user)
    {
        $userAuth = Auth::user();
        $roleAuth = $userAuth->roles->first()->name;

        // Roles para los selects
        $roles = Role::all()->filter(function ($role) use ($roleAuth) {
            if ($roleAuth === 'Superadmin') {
                return $role->name !== 'Superadmin'; // Superadmin no ve su propio rol
            }
            if ($roleAuth === 'Administrador') {
                return $role->name !== 'Superadmin' && $role->name !== 'Administrador'; // Admin no ve su propio rol ni el rol Superadmin
            }
            return false; // Otros roles no pueden ver ningún rol
        });

        $establecimientos = DB::table('ctl_establecimiento')
            ->where('id_tipo_establecimiento', $user->roles->first()->name === 'Región' ? 12 : 13)
            ->where('activo', true)
            ->get();

        return view('users.edit', compact('user', 'roles', 'establecimientos'));
    }

    public function update(Request $request, User $user)
    {
        // Validar datos de entrada
        $request->validate([
            'primer_nombre' => 'required|string|regex:/^[\pL\s]+$/u|min:3|max:25',
            'segundo_nombre' => 'nullable|string|regex:/^[\pL\s]+$/u|min:3|max:25',
            'tercer_nombre' => 'nullable|string|regex:/^[\pL\s]+$/u|min:3|max:25',
            'primer_apellido' => 'required|string|regex:/^[\pL\s]+$/u|min:3|max:25',
            'segundo_apellido' => 'nullable|string|regex:/^[\pL\s]+$/u|min:3|max:25',
            'fecha_nacimiento' => [
            'required',
            'date',
            function ($attribute, $value, $fail) {
                $age = \Carbon\Carbon::parse($value)->age;
                if ($age < 18) {
                $fail('El usuario debe tener al menos 18 años.');
                }
            },
            ],
            'nro_documento' => 'required|string|regex:/^\d{8}-\d{1}$/|max:10|unique:mnt_persona,nro_documento,' . $user->persona->id,
            'correo_institucional' => 'required|email|max:150|unique:users,email,' . $user->id . '|regex:/^[\w\.-]+@salud\.gob\.sv$/',
            'role' => 'required|exists:roles,name',
            'establecimiento' => [
                'required_if:role,Región,Sibasi',
                'exists:ctl_establecimiento,id',
            ],
        ]);

        // Verificar los permisos del usuario autenticado, para evitar asignar roles no permitidos
        $userAuth = Auth::user();
        $roleAuth = $userAuth->roles->first()->name;

        if ($roleAuth === 'Administrador' && !in_array($request->role, ['DIRTECS', 'Región', 'Sibasi'])) {
            return back()->with('error', 'No tienes permiso para asignar este rol.');
        }

        if ($roleAuth === 'DIRTECS' && !in_array($request->role, ['Región', 'Sibasi'])) {
            return back()->with('error', 'No tienes permiso para asignar este rol.');
        }

        try {
            // Comenzamos la transacción
            DB::beginTransaction();

            // Actualizar datos de la persona asociada
            $persona = $user->persona;
            $persona->primer_nombre = $request->primer_nombre;
            $persona->segundo_nombre = $request->segundo_nombre;
            $persona->tercer_nombre = $request->tercer_nombre;
            $persona->primer_apellido = $request->primer_apellido;
            $persona->segundo_apellido = $request->segundo_apellido;
            $persona->fecha_nacimiento = $request->fecha_nacimiento;
            $persona->nro_documento = $request->nro_documento;
            $persona->save();

            // Actualizar email del usuario si ha sido modificado
            if ($user->email !== $request->correo_institucional) {
                $user->email = $request->correo_institucional;
            }

            // Actualizar rol del usuario
            $user->syncRoles($request->role);
            $user->save();

            // Si todo es exitoso, commit de la transacción
            DB::commit();

            // Redirigir con mensaje de éxito
            return redirect()->route('users.index')->with('success', 'Usuario actualizado con éxito.');

        } catch (\Exception $e) {
            // Si ocurre algún error, se revierte la transacción
            DB::rollBack();
            
            // Redirigir con mensaje de error
            return redirect()->back()->withErrors(['error' => 'Hubo un error al actualizar el usuario. Por favor, intenta de nuevo.']);
            
            // Registrar el error en los logs (opcional)
            Log::error('Error actualizando usuario: ' . $e->getMessage());
        }
    }


    public function destroy(User $user)
    {
        $user->delete();
        return redirect()->route('users.index')->with('success', 'Usuario eliminado con éxito.');
    }

    public function toggleStatus(User $user)
    {
        try {
            $estado = $user->status;
            if($estado == 'Habilitado') {
                $user->status = false;
            } else {
                $user->status = true;
            }
            $user->save();

            return response()->json(['status' => $user->status]);
        } catch (\Exception $e) {
            Log::error('Error toggling user status: ' . $e->getMessage());
            return response()->json(['error' => 'Hubo un error al cambiar el estado del usuario.'], 500);
        }
    }

    public function changePassword(Request $request)
    {
        // Reglas de validación
        $validator = Validator::make($request->all(), [
            'actual_contra' => ['required'],
            'nueva_contra' => ['required', 'string', 'min:8', 'confirmed'],
        ], [
            'actual_contra.required' => 'La contraseña actual es obligatoria.',
            'nueva_contra.required' => 'La nueva contraseña es obligatoria.',
            'nueva_contra.min' => 'La nueva contraseña debe tener al menos 8 caracteres.',
            'nueva_contra.confirmed' => 'La confirmación de la nueva contraseña no coincide.',
        ]);

        // Si la validación falla, devolver errores
        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $user = Auth::user();

        // Verificar si la contraseña actual es correcta
        if (!Hash::check($request->actual_contra, $user->password)) {
            return response()->json(['errors' => ['actual_contra' => ['La contraseña actual no es correcta.']]], 422);
        }

        // Cambiar la contraseña
        $user->password = Hash::make($request->nueva_contra);
        $user->password_changed_at = now();
        $user->save();

        return response()->json(['message' => 'Contraseña cambiada con éxito.'], 200);
    }


    // Métodos para gestionar roles
    public function indexRoles()
    {
        $roles = Role::all();
        $permissions = Permission::all();
        return view('users.rolPermission', compact('roles', 'permissions'));
    }

    public function storeRole(Request $request)
    {
        Role::create($request->all());
        return redirect()->route('roles.index')->with('success', 'Rol creado correctamente.');
    }

    public function updateRole(Request $request, Role $role)
    {
        $role->update($request->all());
        return redirect()->route('roles.index')->with('success', 'Rol actualizado correctamente.');
    }

    public function destroyRole(Role $role)
    {
        $role->delete();
        return redirect()->route('roles.index')->with('success', 'Rol eliminado correctamente.');
    }

    public function assignPermissions(Request $request)
    {
        $role = Role::find($request->role_id);
        $role->syncPermissions($request->permissions);
        return redirect()->route('roles.index')->with('success', 'Permisos asignados correctamente.');
    }

    public function storePermission(Request $request)
    {
        Permission::create($request->all());
        return redirect()->route('roles.index')->with('success', 'Permiso creado correctamente.');
    }

    public function updatePermission(Request $request, Permission $permission)
    {
        $permission->update($request->all());
        return redirect()->route('roles.index')->with('success', 'Permiso actualizado correctamente.');
    }

    public function destroyPermission(Permission $permission)
    {
        $permission->delete();
        return redirect()->route('roles.index')->with('success', 'Permiso eliminado correctamente.');
    }

    public function getRolePermissions(Role $role)
    {
        return response()->json([
            'permissions' => $role->permissions->pluck('id')->toArray()
        ]);
    }

    public function obtenerEstablecimientosPorRole($role)
    {
        try {
            $allowedRoles = ['Región', 'Sibasi'];
            if (!in_array($role, $allowedRoles)) {
                return response()->json(['error' => 'Rol no válido.'], 400);
            }
    
            $tipoEstablecimiento = $role === 'Región' ? 12 : 13;
    
            $establecimientos = DB::table('ctl_establecimiento')
                ->where('id_tipo_establecimiento', $tipoEstablecimiento)
                ->where('activo', true)
                ->get();
    
            return response()->json(['establecimientos' => $establecimientos], 200);

        } catch (\Exception $e) {
            Log::error('Error obteniendo establecimientos por rol: ' . $e->getMessage());
            return response()->json(['error' => 'Hubo un error al obtener los establecimientos.'], 500);
        }
    }
}
