<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('ctl_canton', function (Blueprint $table) {
            $table->id();
            $table->string('nombre', 150)->nullable(); // Campo nombre
            $table->string('codigo_digestyc', 5)->nullable(); // Campo código DIGESTYC
            $table->unsignedSmallInteger('id_municipio')->nullable(); // Llave foránea con referencia a ctl_municipio

            // Llave foránea
            $table->foreign('id_municipio')->references('id')->on('ctl_municipio')->onDelete('restrict')->onUpdate('cascade');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('ctl_canton');
    }
};
