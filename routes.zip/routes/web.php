<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\web\AuthController;
use App\Http\Controllers\web\UserController;
use App\Http\Controllers\web\ReportController;
use App\Http\Middleware\EnsureTwoFactorIsVerified;
use Illuminate\Foundation\Auth\EmailVerificationRequest;

//----------------
// Rutas de inicio
//----------------
Route::get('/', function () {
    return view('/logins/login');
});
Route::get('/login', function () {
    return view('/logins/login');
});

//--------------------------
// Rutas para login y logout
//--------------------------
Route::post('/login', [AuthController::class, 'login'])->name('login');
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

//--------------------------------
// Rutas para registro de usuarios
//--------------------------------
Route::get('/email/verify/{id}/{hash}', [UserController::class, 'verifyEmail'])
    ->middleware(['signed'])
    ->name('verification.verify'); // Verificación del email.

//--------------------------------
// Rutas para recuperar contraseña
//--------------------------------
Route::get('/two-factor', [AuthController::class, 'showTwoFactorForm'])->name('two-factor.form'); // Vista del formulario para ingresar el código 2FA.
Route::post('/two-factor/verify', [AuthController::class, 'verifyTwoFactor'])->name('two-factor.verify'); // Verificación del código 2FA.
Route::post('/two-factor/cancel', [AuthController::class, 'cancelTwoFactor'])->name('two-factor.cancel'); // Cancelar la verificación del código 2FA.

Route::get('/password/email', [AuthController::class, 'showLinkRequestForm'])->name('password.email'); // Vista para ingresar el correo de recuperación.
Route::post('/password/email', [AuthController::class, 'sendResetLink'])->name('password.send.email'); // Procesar envío del enlace de recuperación.

Route::get('/password/reset/{token}', [AuthController::class, 'showResetForm'])->name('password.reset'); // Vista para ingresar la nueva contraseña.
Route::post('/password/reset/update', [AuthController::class, 'resetPassword'])->name('password.update'); // Procesar el restablecimiento de la contraseña.

//-----------------------------------
// Rutas protegidas con autenticación
//-----------------------------------
Route::middleware(['auth', EnsureTwoFactorIsVerified::class])->group(function () {
    //--------------
    // Rutas de menu
    //--------------
    Route::get('/dashboard', function () {
        return view('dashboard');
    });
    Route::get('/settings', function () {
        return view('users.settings');
    })->name('ajustes');
    Route::get('/reportes/pendientes', [ReportController::class, 'reportesPendientes'])
        ->middleware('can:Ver reportes pendientes')    
        ->name('reportes.pendientes');
    Route::get('/reportes/validados', [ReportController::class, 'reportesValidados'])
        ->middleware('can:Ver reportes validados')    
        ->name('reportes.validados');

    //--------------------
    // Rutas para usuarios
    //--------------------
    Route::resource('users', UserController::class)
        ->middleware([
        'can:Ver usuarios,index',
        'can:Crear usuarios,create',
        'can:Crear usuarios,store',
        'can:Editar usuarios,edit',
        'can:Editar usuarios,update',
        'can:Eliminar usuarios,destroy'
    ]);
    // Obtener los establecimientos para cuando se registra un nuevo usuario de 'Region' o 'Sibasi'
    Route::get('/obtener/establecimientos/{role}', [UserController::class, 'obtenerEstablecimientosPorRole'])
        ->middleware(['can:Crear usuarios', 'can:Editar usuarios']);
    // Cambiar estado del usuario
    Route::post('/users/{user}/toggle-status', [UserController::class, 'toggleStatus'])
        ->middleware('can:Editar usuarios')
        ->name('users.toggleStatus');
    // Cambiar contraseña
    Route::post('/change-password', [UserController::class, 'changePassword'])
        ->name('password.change');

    //----------------------------
    // Rutas para roles y permisos
    //----------------------------
    Route::get('/roles', [UserController::class, 'indexRoles'])
        ->middleware('can:Ver roles')
        ->name('roles.index');
    Route::post('/roles', [UserController::class, 'storeRole'])
        ->middleware('can:Crear roles')
        ->name('roles.store');
    Route::put('/roles/{role}', [UserController::class, 'updateRole'])
        ->middleware('can:Editar roles')
        ->name('roles.update');
    Route::delete('/roles/{role}', [UserController::class, 'destroyRole'])
        ->middleware('can:Eliminar roles')
        ->name('roles.destroy');

    Route::post('/roles/assign-permissions', [UserController::class, 'assignPermissions'])
        ->middleware('can:Asignar permisos')
        ->name('roles.assignPermissions');
    Route::get('/roles/{role}/permissions', [UserController::class, 'getRolePermissions'])
        ->middleware('can:Ver permisos')
        ->name('roles.getPermissions');

    Route::post('/permissions', [UserController::class, 'storePermission'])
        ->middleware('can:Crear permisos')
        ->name('permissions.store');
    Route::put('/permissions/{permission}', [UserController::class, 'updatePermission'])
        ->middleware('can:Editar permisos')
        ->name('permissions.update');
    Route::delete('/permissions/{permission}', [UserController::class, 'destroyPermission'])
        ->middleware('can:Eliminar permisos')
        ->name('permissions.destroy');

    //------------------------------
    // Rutas para verificar reportes
    //------------------------------
    Route::get('/reporte/verificar/{id}', [ReportController::class, 'verificarReporte'])
        ->middleware(['can:Ver detalle reportes pendientes','can:Ver detalle reportes validados'])
        ->name('reporte.verificar');
    Route::post('/reportes/aprobar/{id}', [ReportController::class, 'aprobarReporte'])
        ->middleware('can:Aprobar reporte')
        ->name('reportes.aprobar');
    Route::post('/reportes/rechazar/{id}', [ReportController::class, 'rechazarReporte'])
        ->middleware('can:Rechazar reporte')
        ->name('reportes.rechazar');
});