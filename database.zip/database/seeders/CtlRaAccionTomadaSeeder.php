<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CtlRaAccionTomadaSeeder extends Seeder
{
    public function run()
    {
        DB::table('ctl_ra_accion_tomada')->insert([
            [
                'nombre_corto' => 'TRATERAP',
                'nombre' => 'Tratamiento terapéutico',
                'descripcion' => null,
                'modulo' => 'AMBOS',
                'activo' => true,
            ],
            [
                'nombre_corto' => 'MEDRET',
                'nombre' => 'Medicamento retirado',
                'descripcion' => null,
                'modulo' => 'RAM/PRM',
                'activo' => true,
            ],
            [
                'nombre_corto' => 'DOSAUM',
                'nombre' => 'Dosis aumentada',
                'descripcion' => null,
                'modulo' => 'RAM/PRM',
                'activo' => true,
            ],
            [
                'nombre_corto' => 'DOSRED',
                'nombre' => 'Dosis reducida',
                'descripcion' => null,
                'modulo' => 'RAM/PRM',
                'activo' => true,
            ],
            [
                'nombre_corto' => 'DOSNOMOD',
                'nombre' => 'Dosis no modificada',
                'descripcion' => null,
                'modulo' => 'RAM/PRM',
                'activo' => true,
            ],
            [
                'nombre_corto' => 'CAMMAR',
                'nombre' => 'Cambio de marca',
                'descripcion' => null,
                'modulo' => 'RAM/PRM',
                'activo' => true,
            ],
            [
                'nombre_corto' => 'OBSSEG',
                'nombre' => 'Observación/seguimiento',
                'descripcion' => null,
                'modulo' => 'AMBOS',
                'activo' => true,
            ],
        ]);
    }
}
