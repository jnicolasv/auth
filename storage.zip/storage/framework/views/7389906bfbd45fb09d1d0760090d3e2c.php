<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Aplicación'); ?></title>
    <link rel="icon" href="<?php echo e(asset('images/favicon.ico')); ?>" type="image/x-icon">
    <link rel="stylesheet" href="<?php echo e(asset('css/output.css')); ?>">
    <script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet">
    
    <link href="https://fonts.cdnfonts.com/css/museo-sans-rounded" rel="stylesheet">
    <!-- Agrega los estilos de Flatpickr -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/themes/airbnb.css">

    <!-- Manejar los tamaños de la barra lateral -->
    <style>
        #sidebar {
            width: var(--sidebar-width);
        }
        #main-content {
            margin-left: var(--sidebar-width);
        }
    </style>
    <script>
        const sidebarOpen = localStorage.getItem('sidebarOpen') === 'true';
        document.documentElement.style.setProperty('--sidebar-width', sidebarOpen ? '330px' : '90px');
    </script>
    <!-- Manejar los tamaños de la barra lateral -->
    
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body class="bg-gray-100">
    <div class="h-screen">
        <!-- Sidebar -->
        <aside id="sidebar" class="bg-[#576ca9] text-white custom-shadow p-4 fixed h-full transition-all duration-300">
            <div class="toggleMenu">
                <button id="openSidebar" class="text-white absolute top-4 left-4 z-10">
                    <span class="material-symbols-outlined">menu</span>
                </button>
                <button id="closeSidebar" class="text-white absolute top-4 left-4 z-10 hidden">
                    <span class="material-symbols-outlined">close</span>
                </button>
            </div>
            <ul>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Ver usuarios')): ?>
                <li class="mb-4 flex items-center gap-2 menu-item" data-route="users.index">
                    <a href="<?php echo e(route('users.index')); ?>" class="flex items-center gap-2 w-full" id="users-index">
                        <span class="material-symbols-outlined">person</span>
                        <span>Gestión de Usuarios</span>
                    </a>
                </li>
                <?php endif; ?>
                <li class="mb-4 flex items-center gap-2 menu-item">
                    <a href="<?php echo e(route('reportes.validados')); ?>" class="flex items-center gap-2 w-full" id="reportes-validados">
                        <span class="material-symbols-outlined">task</span>
                        <span>Reportes Validados</span>
                    </a>
                </li>
                <li class="flex items-center gap-2 menu-item">
                    <a href="<?php echo e(route('reportes.pendientes')); ?>" class="flex items-center gap-2 w-full" id="reportes-pendientes">
                        <span class="material-symbols-outlined">file_copy</span>
                        <span>Reportes Pendientes de Validar</span>
                    </a>
                </li>
            </ul>
        </aside>

        <!-- Main Content -->
        <div id="main-content" class="flex-1 ml-[90px] transition-all duration-300">
            <div class="p-4 flex flex-col sm:flex-row items-center justify-between border-b border-gray-200 shadow-md">
                <h1 class="text-center sm:text-left text-base sm:text-lg md:text-xl font-bold break-words w-full sm:w-auto text-gray-600 md:ml-3">
                    SISTEMA CENTRALIZADO DE REACCIONES ADVERSAS
                </h1>
                <div class="mt-2 sm:mt-0 flex sm:block justify-center w-full sm:w-auto md:mr-2.5 relative">
                    <!-- Botón de configuración -->
                    <button id="settingsButton" class="text-gray-600">
                        <span class="material-symbols-outlined" style="font-size: 2.5rem; font-weight: normal;">settings</span>
                    </button>
                
                    <!-- Menú de configuración -->
                    <div id="settingsMenu" 
                        class="hidden absolute z-10 w-64 bg-white shadow-md border rounded 
                               mt-[80px] sm:mt-0 sm:right-0 sm:left-auto left-1/2 -translate-x-1/2 sm:translate-x-0">
                        <ul>
                            <li class="px-2 py-2">
                                <div class="border rounded-lg p-2 text-center">
                                    <span class="block text-lg font-bold"><?php echo e(Auth::user()->persona->primer_nombre); ?> <?php echo e(Auth::user()->persona->primer_apellido); ?></span>
                                    <?php if(Auth::user()->getRoleNames()->isNotEmpty()): ?>
                                    <span class="block text-sm text-gray-500">
                                        <?php echo e(Auth::user()->getRoleNames()->first()); ?>

                                    </span>
                                    <?php else: ?>
                                    <span class="block text-sm text-gray-500">
                                        Sin rol asignado
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </li>
                            <li class="px-4 py-2 hover:bg-gray-100">
                                <a href="<?php echo e(route('ajustes')); ?>" class="w-full flex items-center gap-2">
                                    <span class="material-symbols-outlined">settings</span>
                                    Ajustes
                                </a>
                            </li>
                            <li class="px-4 py-2 border-t hover:bg-gray-100 flex items-center gap-2">
                                <span class="material-symbols-outlined">logout</span>
                                <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" class="block w-full">Cerrar Sesión</a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="hidden">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </li>
                        </ul>
                    </div>
                </div>
                
                
            </div>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <!-- Agrega los scripts de Flatpickr -->
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <!-- Traducción al español -->
    <script src="https://cdn.jsdelivr.net/npm/flatpickr/dist/l10n/es.js"></script>
    
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html><?php /**PATH /var/www/html/resources/views/layout.blade.php ENDPATH**/ ?>