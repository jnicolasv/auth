<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MntRaMedicamento extends Model
{
    use HasFactory;

    protected $table = 'mnt_ra_medicamento';

    protected $fillable = [
        'id_ram',
        'id_via_administracion',
        'id_tipo_medicamento',
        'id_producto',
        'otro_medicamento',
        'dosis_unidades_intervalo',
        'fecha_inicio',
        'fecha_final',
        'id_usuario_registra',
    ];

    // Relaciones
    public function ram()
    {
        return $this->belongsTo(SecRam::class, 'id_ram');
    }

    public function tipoMedicamento()
    {
        return $this->belongsTo(CtlRaSospechaMedicamento::class, 'id_tipo_medicamento');
    }

    public function catalogoProducto()
    {
        return $this->belongsTo(FarmCatalogoproducto::class, 'id_producto');
    }

    public function usuarioRegistra()
    {
        return $this->belongsTo(FosUserUser::class, 'id_usuario_registra');
    }
}
