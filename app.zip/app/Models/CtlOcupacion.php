<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CtlOcupacion extends Model
{
    use HasFactory;

    // Especificar la tabla asociada
    protected $table = 'ctl_ocupacion';

    // Campos que pueden ser asignados masivamente
    protected $fillable = [
        'nombre',
        'id_sumeve',
    ];

    // Relación con MntPaciente
    public function pacientes()
    {
        return $this->hasMany(MntPaciente::class, 'id_ocupacion');
    }
}
