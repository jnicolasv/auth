<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CtlNacionalidadSeeder extends Seeder
{
    public function run()
    {
        DB::table('ctl_nacionalidad')->insert([
            [
                'nacionalidad' => 'Salvadoreña',
                'catalogo_maestro' => '67',
            ],
            [
                'nacionalidad' => 'Guatemalteca',
                'catalogo_maestro' => '93',
            ],
            [
                'nacionalidad' => 'Hondureña',
                'catalogo_maestro' => '101',
            ],
            [
                'nacionalidad' => 'Nicaragüense',
                'catalogo_maestro' => '156',
            ],
            [
                'nacionalidad' => 'Costarricense',
                'catalogo_maestro' => '59',
            ],
            [
                'nacionalidad' => 'Panameña',
                'catalogo_maestro' => '169',
            ],
            [
                'nacionalidad' => 'Otras Nacionalidades',
                'catalogo_maestro' => null,
            ],
        ]);
    }
}
