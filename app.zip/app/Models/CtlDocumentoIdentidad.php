<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CtlDocumentoIdentidad extends Model
{
    use HasFactory;

    // Especificar la tabla asociada
    protected $table = 'ctl_documento_identidad';

    // Campos que pueden ser asignados masivamente
    protected $fillable = [
        'nombre',
        'abreviatura',
    ];

    // Relación con MntPaciente
    public function pacientes()
    {
        return $this->hasMany(MntPaciente::class, 'id_doc_ide_paciente');
    }
}
