<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('ctl_municipio', function (Blueprint $table) {
            $table->id();
            $table->string('nombre', 150); // Campo nombre
            $table->string('codigo_cnr', 5)->nullable(); // Campo código CNR
            $table->string('abreviatura', 5)->nullable(); // Campo abreviatura
            $table->unsignedBigInteger('id_departamento'); // Relación con la tabla ctl_departamento
            $table->string('codigo_rnpn', 4)->nullable(); // Campo código RNP
            $table->unsignedBigInteger('municipio2023id')->nullable(); // Relación opcional con ctl_municipio2023

            // Llaves foráneas
            $table->foreign('id_departamento')->references('id')->on('ctl_departamento')->onDelete('restrict')->onUpdate('cascade');
            $table->foreign('municipio2023id')->references('id')->on('ctl_municipio2023')->onDelete('restrict')->onUpdate('cascade');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('ctl_municipio');
    }
};
