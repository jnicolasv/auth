<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FarmCatalogoproducto extends Model
{
    use HasFactory;

    protected $table = 'farm_catalogoproductos';

    // Campos que son asignables masivamente
    protected $fillable = [
        'codigo',
        'idtipoproducto',
        'idunidadmedida',
        'nombre',
        'niveluso',
        'concentracion',
        'formafarmaceutica',
        'presentacion',
        'prioridad',
        'precioactual',
        'aplicalote',
        'existenciaactual',
        'especificacionestecnicas',
        'codigonacionesunidas',
        'pertenecelistadooficial',
        'estadoproducto',
        'observacion',
        'auusuariocreacion',
        'aufechacreacion',
        'auusuariomodificacion',
        'aufechamodificacion',
        'estasincronizada',
        'idestablecimiento',
        'clasificacion',
        'areatecnica',
        'tipouaci',
        'idespecificogasto',
        'ultimoprecio',
        'idterapeutico',
        'idestado',
        'divisormedicina',
        'cuantificable'
    ];

    public function medicamentos()
    {
        return $this->hasMany(MntRaMedicamento::class);
    }
}
