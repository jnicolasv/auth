<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SecVacunaSospechosaEsavi extends Model
{
    use HasFactory;

    protected $table = 'sec_vacuna_sospechosa_esavi';

    protected $fillable = [
        'id_via_administracion',
        'id_tipo_vacuna',
        'id_region_cuerpo',
        'id_recurso_vacunador',
        'id_marco_aplicacion',
        'id_lugar_vacunacion',
        'id_vacuna',
        'numero_registro_sanitario',
        'nombre_comercial',
        'numero_dosis',
        'dosis_vacuna_ml',
        'otro_sitio_anatomico',
        'temperatura_conservacion',
        'direccion_establecimiento',
        'otra_indicacion_medica',
        'otra_via_administracion',
        'laboratorio',
        'lote',
        'fecha_vencimiento',
        'fecha_vacunacion',
        'hora_vacunacion',
        'otro_recurso_vacunador',
        'resguarda_frasco',
        'total_vacunas_aplicadas',
        'total_vacunas_establecimientos',
        'id_esavi',
        'id_usuario_registra',
    ];

    // Relaciones
    public function esavi()
    {
        return $this->belongsTo(SecEsavi::class, 'id_esavi');
    }

    public function vacuna()
    {
        return $this->belongsTo(CtlVacunas::class, 'id_vacuna');
    }

    public function recursoVacunador()
    {
        return $this->belongsTo(CtlRaRecursoVacunador::class, 'id_recurso_vacunador');
    }

    public function marcoAplicacion()
    {
        return $this->belongsTo(CtlRaMarcoAplicacion::class, 'id_marco_aplicacion');
    }

    public function vacunasSospechosas()
    {
        return $this->belongsTo(CtlRaLugarVacunacion::class, 'id_lugar_vacunacion');
    }

    public function viaAdministracion()
    {
        return $this->belongsTo(FarmViaAdministracion::class, 'id_via_administracion');
    }

    public function tipoVacuna()
    {
        return $this->belongsTo(CtlRaSospechaMedicamento::class, 'id_tipo_vacuna');
    }

    public function regionCuerpo()
    {
        return $this->belongsTo(CtlRegionCuerpo::class, 'id_region_cuerpo');
    }

    public function usuarioRegistra()
    {
        return $this->belongsTo(FosUserUser::class, 'id_usuario_registra');
    }
}
