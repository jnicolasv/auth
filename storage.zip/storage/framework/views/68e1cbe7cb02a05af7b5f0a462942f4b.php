<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .responsive-table {
        overflow-x: auto;
    }
    table {
        min-width: 100%;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="p-6">
    <div class="bg-white p-4 rounded shadow mb-4">

        <!-- Notificacion para cambiar la contreseña -->
        <?php if(session('password_change_alert')): ?>
            <div class="bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-3 rounded relative mb-4" role="alert">
                <p class="text-sm flex items-center gap-2"><span class="material-symbols-outlined">error</span> <?php echo e(session('password_change_alert')); ?></p>
            </div>
        <?php endif; ?>

        <div class="border-2 border-[#576ca9] bg-[#edf3ff] p-2 rounded-2xl mb-4 text-center">
            <h2 class="text-xl font-semibold text-[#576ca9]">Dashboard del Sistema</h2>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js/dashboard.js')); ?>"></script>
<script>
    $(document).ready(function() {
        /*$('#tablaUsuarios').DataTable({
            language: {
                url: '//cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json'
            },
            responsive: true,
            paging: true,
            searching: true,
        });*/
    });
</script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/dashboard.blade.php ENDPATH**/ ?>