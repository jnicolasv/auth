<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MntRaVacunasConcomitantes extends Model
{
    use HasFactory;

    protected $table = 'mnt_ra_vacunas_concomitantes';

    protected $fillable = [
        'id_esavi',
        'id_region_cuerpo',
        'id_via_administracion',
        'id_vacuna',
        'id_tipo_vacuna',
        'nombre_vacuna',
        'dosis_vacuna',
        'laboratorio_vacuna',
        'temperatura_vacuna',
        'fecha_vencimiento_vacuna',
        'lote_vacuna',
        'id_usuario_registra',
    ];

    // Relaciones
    public function esavi()
    {
        return $this->belongsTo(SecEsavi::class, 'id_esavi');
    }

    public function regionCuerpo()
    {
        return $this->belongsTo(CtlRegionCuerpo::class, 'id_region_cuerpo');
    }

    public function viaAdministracion()
    {
        return $this->belongsTo(CtlRaViaDeAdministracion::class, 'id_via_administracion');
    }

    public function vacuna()
    {
        return $this->belongsTo(CtlVacunas::class, 'id_vacuna');
    }

    public function tipoVacuna()
    {
        return $this->belongsTo(CtlRaSospechaMedicamento::class, 'id_tipo_vacuna');
    }

    public function usuarioRegistra()
    {
        return $this->belongsTo(FosUserUser::class, 'id_usuario_registra');
    }
}
