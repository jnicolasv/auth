<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('mnt_ra_vacunas_concomitantes', function (Blueprint $table) {
            $table->id();

            $table->unsignedBigInteger('id_esavi');
            $table->unsignedBigInteger('id_region_cuerpo');
            $table->unsignedBigInteger('id_via_administracion');
            $table->unsignedBigInteger('id_vacuna');
            $table->unsignedBigInteger('id_tipo_vacuna');
            $table->string('nombre_vacuna', 50)->nullable();
            $table->string('dosis_vacuna', 8);
            $table->string('laboratorio_vacuna', 50);
            $table->decimal('temperatura_vacuna', 5, 2);
            $table->date('fecha_vencimiento_vacuna')->nullable();
            $table->string('lote_vacuna', 10)->nullable();
            $table->unsignedBigInteger('id_usuario_registra')->nullable();
            
            // Claves foráneas
            $table->foreign('id_esavi')->references('id')->on('sec_esavi')->onUpdate('cascade')->onDelete('restrict');
            $table->foreign('id_region_cuerpo')->references('id')->on('ctl_region_cuerpo')->onUpdate('cascade')->onDelete('restrict');
            $table->foreign('id_via_administracion')->references('id')->on('ctl_ra_via_de_administracion')->onUpdate('cascade')->onDelete('restrict');
            $table->foreign('id_vacuna')->references('id')->on('ctl_vacunas')->onUpdate('cascade')->onDelete('restrict');
            $table->foreign('id_tipo_vacuna')->references('id')->on('ctl_ra_sospecha_medicamento')->onUpdate('cascade')->onDelete('restrict');
            $table->foreign('id_usuario_registra')->references('id')->on('fos_user_user')->onUpdate('cascade')->onDelete('restrict');
                
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('mnt_ra_vacunas_concomitantes');
    }
};
