<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('mnt_empleado', function (Blueprint $table) {
            $table->id();
            
            $table->unsignedBigInteger('id_sis');
            $table->string('nombre', 100)->nullable();
            $table->string('apellido', 100)->nullable();
            $table->date('fecha_nacimiento')->nullable();
            $table->text('dui')->nullable();
            $table->string('numero_celular', 10)->nullable();
            $table->string('correo_electronico', 50)->nullable();
            $table->unsignedBigInteger('id_establecimiento')->nullable();
            $table->unsignedBigInteger('id_cargo_empleado')->nullable();
            $table->unsignedBigInteger('id_tipo_empleado')->nullable();
            $table->string('primer_nombre', 25)->nullable();
            $table->string('segundo_nombre', 25)->nullable();
            $table->string('tercer_nombre', 25)->nullable();
            $table->string('primer_apellido', 30)->nullable();
            $table->string('segundo_apellido', 30)->nullable();
            $table->string('apellido_casada', 30)->nullable();
            $table->uuid('id_persona_uuid')->nullable();

            $table->foreign('id_establecimiento')->references('id')->on('ctl_establecimiento')->onDelete('restrict')->onUpdate('restrict');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('mnt_empleado');
    }
};
