<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CtlCanton extends Model
{
    use HasFactory;

    // Especificar la tabla asociada
    protected $table = 'ctl_canton';

    // Campos que pueden ser asignados masivamente
    protected $fillable = [
        'nombre',
        'codigo_digestyc',
        'id_municipio',
    ];

    // Relación con CtlMunicipio
    public function municipio()
    {
        return $this->belongsTo(CtlMunicipio::class, 'id_municipio');
    }
}
