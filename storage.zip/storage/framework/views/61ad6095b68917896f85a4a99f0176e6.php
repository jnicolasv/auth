<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bienvenido/a al Sistema Centralizado de Reacciones Adversas</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 14px;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .ii a[href] {
            color: #fff;
        }
        .email-wrapper {
            width: 100%;
            background-color: #f4f4f4;
            padding: 20px 0;
        }
        .email-container {
            max-width: 600px;
            background: #ffffff;
            border-radius: 12px;
            padding: 15px;
            border: 1px solid #eee;
        }
        .header {
            background: #293653;
            padding: 20px;
            color: #ffffff;
            font-size: 24px;
            font-weight: bold;
            text-align: center;
        }
        .content {
            padding: 20px;
            color: #333333;
            text-align: center;
            font-size: 16px;
        }
        .data-content {
            background: ##e8e8f0;
            border-radius: 8px;
            margin: 10px;
            border: 1px solid #eee;
        }
        .button {
            display: inline-block;
            background: #455A8A;
            color: #ffffff !important;
            padding: 12px 24px;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
            margin: 20px auto;
            text-align: center;
        }
        .button:hover {
            background: #293653;
        }
        .footer {
            background: #d4d4dc ;
            color: #293653 ;
            padding: 10px;
            font-size: 14px;
            border-radius: 0 0 8px 8px;
            text-align: center;
        }
        .footer a {
            color: #ffffff;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" class="email-wrapper">
        <tr>
            <td align="center">
                <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="600" class="email-container">
                    <tr>
                        <td align="center" class="header">
                             
                            <img src="https://drive.google.com/uc?export=view&id=10XE3WuEyWsYDhXHeT7_vm2wOLm0MsASS" alt="Icon lock" style="height: 40px;"><br>
                            Acceso a tu Cuenta
                        </td>
                    </tr>
                    <tr>
                        <td align="center" class="content">
                             
                            <img src="https://drive.google.com/uc?export=view&id=1peIYOpT2g0LescQLjNM7xV0BqsD0wUW4" alt="Logotipo" style="height: 85px;"><br>
                            <h2>Bienvenido/a, <?php echo e($name); ?></h2>
                            <p>Has sido registrado en el Sistema Centralizado de Reacciones Adversas. Estos son tus datos de acceso:</p>
                            <div class="data-content">
                                <p><strong>Correo:</strong> <?php echo strip_tags($email); ?></p>
                                <p><strong>Contraseña:</strong> <?php echo strip_tags($password); ?></p>
                            </div>
                            <p>Por favor, recuerda cambiar tu contraseña después de iniciar sesión para mantener tu cuenta segura. Para completar el registro, por favor haz clic en el siguiente enlace para verificar tu dirección de correo electrónico:</p>
                            <a href="<?php echo e($verificationUrl); ?>" class="button">Ingresar al Sistema</a>
                        </td>
                    </tr>
                    <tr>
                        <td align="center" class="footer">
                            <p>&copy; <?php echo e(date('Y')); ?> Sistema Centralizado de Reacciones Adversas. Todos los derechos reservados.</p>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
<?php /**PATH /var/www/html/resources/views/emails/send-password.blade.php ENDPATH**/ ?>