<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('mnt_ra_examenes_laboratorio_procedimientos', function (Blueprint $table) {
            $table->id();

            $table->string('examen_realizado', 150);
            $table->unsignedBigInteger('id_tipo_muestra');
            $table->string('resultados', 500);
            $table->timestamp('fecha_realizacion');
            $table->unsignedBigInteger('id_esavi');
            $table->unsignedBigInteger('id_usuario_registra')->nullable();

            // Claves foráneas
            $table->foreign('id_tipo_muestra')->references('id')->on('lab_tipomuestra')->onUpdate('cascade')->onDelete('restrict');
            $table->foreign('id_esavi')->references('id')->on('sec_esavi')->onUpdate('cascade')->onDelete('restrict');
            $table->foreign('id_usuario_registra')->references('id')->on('fos_user_user')->onUpdate('cascade')->onDelete('restrict');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('mnt_ra_examenes_laboratorio_procedimientos');
    }
};
