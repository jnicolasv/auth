<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->boolean('status')->default(true); // 'true' significa habilitado por defecto
            $table->timestamp('password_changed_at')->nullable(); // Fecha de cambio de contraseña
            $table->boolean('two_factor')->default(false); // 'false' significa deshabilitado por defecto
            $table->string('two_factor_code')->nullable(); // Código de verificación 2FA
            $table->timestamp('two_factor_expires_at')->nullable(); // Fecha de expiración del código 2FA
            $table->integer('two_factor_method')->default(1); // Método de verificación 2FA
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            // Eliminar todos los campos
            $table->dropColumn([
                'status',
                'password_changed_at',
                'two_factor',
                'two_factor_code',
                'two_factor_expires_at',
                'two_factor_method'
            ]);
        });
    }
};
