<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MntPaciente extends Model
{
    use HasFactory;

    protected $table = 'mnt_paciente';

    protected $fillable = [
        'id_sis',
        'primer_nombre',
        'segundo_nombre',
        'tercer_nombre',
        'primer_apellido',
        'segundo_apellido',
        'apellido_casada',
        'fecha_nacimiento',
        'id_pais_nacimiento',
        'id_departamento_nacimiento',
        'id_municipio_nacimiento',
        'id_estado_civil',
        'id_doc_ide_paciente',
        'numero_doc_ide_paciente',
        'id_ocupacion',
        'direccion',
        'telefono_casa',
        'id_departamento_domicilio',
        'id_municipio_domicilio',
        'id_canton_domicilio',
        'estado',
        'id_nacionalidad',
        'id_sexo',
        'fecha_registro',
        'nombre_completo_fonetico',
        'apellido_completo_fonetico',
        'correo_electronico',
    ];

    // Relación con SecReaccionAdversa (uno a muchos)
    public function reaccionesAdversas()
    {
        return $this->hasMany(SecReaccionAdversa::class, 'id_paciente');
    }

    // Relación con MntExpediente
    public function expedientes()
    {
        return $this->hasMany(MntExpediente::class, 'id_paciente');
    }

    // Relación con CtlPais
    public function paisNacimiento()
    {
        return $this->belongsTo(CtlPais::class, 'id_pais_nacimiento');
    }

    // Relación con CtlDepartamento
    public function departamentoNacimiento()
    {
        return $this->belongsTo(CtlDepartamento::class, 'id_departamento_nacimiento');
    }

    // Relación con CtlMunicipio
    public function municipioNacimiento()
    {
        return $this->belongsTo(CtlMunicipio::class, 'id_municipio_nacimiento');
    }

    // Relación con CtlEstadoCivil
    public function estadoCivil()
    {
        return $this->belongsTo(CtlEstadoCivil::class, 'id_estado_civil');
    }

    // Relación con CtlDocIdePaciente
    public function docIdePaciente()
    {
        return $this->belongsTo(CtlDocumentoIdentidad::class, 'id_doc_ide_paciente');
    }

    // Relación con CtlOcupacion
    public function ocupacion()
    {
        return $this->belongsTo(CtlOcupacion::class, 'id_ocupacion');
    }

    // Relación con CtlDepartamento
    public function departamentoDomicilio()
    {
        return $this->belongsTo(CtlDepartamento::class, 'id_departamento_domicilio');
    }

    // Relación con CtlMunicipio
    public function municipioDomicilio()
    {
        return $this->belongsTo(CtlMunicipio::class, 'id_municipio_domicilio');
    }

    // Relación con CtlCanton
    public function cantonDomicilio()
    {
        return $this->belongsTo(CtlCanton::class, 'id_canton_domicilio');
    }

    // Relación con CtlNacionalidad
    public function nacionalidad()
    {
        return $this->belongsTo(CtlNacionalidad::class, 'id_nacionalidad');
    }

    // Relación con CtlSexo
    public function sexo()
    {
        return $this->belongsTo(CtlSexo::class, 'id_sexo');
    }


}
