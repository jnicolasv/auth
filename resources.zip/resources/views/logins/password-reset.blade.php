@extends('layout-login')

@section('title', 'Recuperar Contraseña')

@section('content')

    {{-- Formulario de restablecimiento --}}
    <form action="{{ route('password.update') }}" method="POST">
        @csrf

        <div class="mb-5">
            <p class="text-gray-700 text-lg text-center font-bold">Restablecer contraseña</p>
            <p class="text-gray-600 text-md text-center">Ingresa tu nueva contraseña para continuar</p>
        </div>

        {{-- Token oculto --}}
        <input type="hidden" name="token" value="{{ $token }}">

        {{-- Campos --}}
        <div class="grid grid-cols-1 gap-x-4 gap-y-6 mt-10">

            <div class="input-container">
                <label for="email" class="input-label">Correo eléctronico</label>
                <input type="email" id="email" name="email" class="input-field" value="{{ request('email') }}">
            </div>

            <div class="input-container">
                <label for="password" class="input-label">Nueva contraseña</label>
                <input type="password" id="password" name="password" class="input-field">
            </div>

            <div class="input-container">
                <label for="password_confirmation" class="input-label">Confirmar contraseña</label>
                <input type="password" id="password_confirmation" name="password_confirmation" class="input-field">
            </div>

        </div>

        {{-- Botón Enviar --}}
        <div class="flex justify-center mt-5 space-x-4">
            <button type="submit" class="btn-primary">
                Restablecer contraseña
            </button>
        </div>
    </form>

    {{-- Mostrar mensajes de error --}}
    @if (session('status'))
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mt-4" role="alert">
            <p class="text-sm">{{ session('status') }}</p>
        </div>
    @endif

    {{-- Mostrar errores de validación --}}
    @if ($errors->any())
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mt-4" role="alert">
            @foreach ($errors->all() as $error)
                <p class="text-sm">{{ $error }}</p>
            @endforeach
        </div>
    @endif

@endsection
