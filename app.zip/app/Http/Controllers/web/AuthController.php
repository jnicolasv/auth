<?php

namespace App\Http\Controllers\web;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use App\Mail\TwoFactorCodeMail;
use Carbon\Carbon;


class AuthController extends Controller
{
    // public function showLoginForm()
    // {
    //     return view('login'); // Asegúrate de que este sea el nombre de tu vista Blade
    // }

    public function login(Request $request)
    {

        $request->validate([
            'login' => 'required',
            'password' => 'required',
        ], [
            'login.required' => 'El campo usuario o correo electrónico es obligatorio.',
            'password.required' => 'La contraseña es obligatoria.',
        ]);

        $credentials = [
            'password' => $request->password,
        ];

        // Verificar si el input es un correo electrónico o un nombre de usuario
        if (filter_var($request->login, FILTER_VALIDATE_EMAIL)) {
            $credentials['email'] = $request->login; // Si es correo
            if (strpos($request->login, '@salud.gob.sv') === false) {
                return back()->withErrors([
                    'email' => 'El correo electrónico debe ser institucional.',
                ]);
            }
        } else {
            $credentials['name'] = $request->login; // Si es nombre de usuario
        }

        // Intentar autenticar al usuario
        if (Auth::attempt($credentials)) {
            // Verificar si el usuario está bloqueado, en este caso el ID 2 del usuario API
            $user = Auth::user();

            // Colocar el ID del usuario a bloquear
            if ($user->id == 2) {
                Auth::logout();
                return back()->withErrors([
                    'access' => 'No tienes permiso para acceder al sistema.',
                ]);
            }

            // Ya no va
            // Verificar si el campo password_changed_at es nulo
            /*if (is_null($user->password_changed_at)) {
                session()->flash('password_change_alert', 'Por motivos de seguridad, le recomendamos cambiar la contraseña generada automáticamente por una de su elección. Por favor, asegúrese de que sea segura y fácil de recordar.');
            }*/

            if ($user->two_factor) {
                $this->sendTwoFactorCode($user);
                return redirect()->route('two-factor.form');
            }

            // Generar la sesión y redirigir si el usuario
            $request->session()->regenerate();
            return redirect()->intended('dashboard'); // Cambia 'dashboard' según la ruta de inicio
        }

        return back()->withErrors([
            'email' => 'Credenciales inválidas.',
        ]);
    }

    public function logout(Request $request)
    {
        Auth::logout();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect('/');
    }

    public function sendTwoFactorCode($user)
    {
        $code = rand(100000, 999999);

        $user->update([
            'two_factor_code' => $code,
            'two_factor_expires_at' => Carbon::now()->addMinutes(15)
        ]);

        // Enviar el correo con la plantilla HTML
        Mail::to($user->email)->send(new TwoFactorCodeMail($user, $code));
    }

    public function verifyTwoFactor(Request $request)
    {
        $request->validate(['code' => 'required|numeric']);

        $user = Auth::user();

        if ($request->code == $user->two_factor_code && Carbon::now()->lt($user->two_factor_expires_at)) {
            $user->update([
                'two_factor_code' => null,
                'two_factor_expires_at' => null
            ]);

            $request->session()->regenerate();
            return redirect()->intended('dashboard');
        }

        return back()->withErrors(['code' => 'El código es incorrecto o ha expirado.']);
    }

    public function showTwoFactorForm()
    {
        return view('logins.two-factor'); // Asegúrate de que este sea el nombre de tu vista Blade
    }

    public function cancelTwoFactor()
    {
        Auth::logout();
        return redirect('/');
    }


    public function showLinkRequestForm()
    {
        return view('logins.password-email');
    }

    /* Enviar el enlace de restablecimiento de contraseña */
    public function sendResetLink(Request $request)
    {
        $validated = $request->validate([
            'email' => 'required|email|exists:users,email',
        ], [
            'email.required' => 'El correo electrónico es obligatorio.',
            'email.email' => 'El correo electrónico debe ser válido.',
            'email.exists' => 'El correo electrónico no está registrado en nuestro sistema.',
        ]);

        $status = Password::sendResetLink(
            $request->only('email')
        );

        return $status === Password::RESET_LINK_SENT
            ? back()->with('status', trans($status))
            : back()->withErrors(['email' => trans($status)]);
    }

    /* Mostrar el formulario para restablecer la contraseña */
    public function showResetForm($token)
    {
        // dd($token, request()->email);
        return view('logins.password-reset', ['token' => $token]); // Asegúrate de que este sea el nombre de tu vista Blade
    }

    public function resetPassword(Request $request)
    {
        // dd($request->all());
        // Validar la entrada
        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
            'password' => 'required|confirmed|min:8',
        ], [
            'email.required' => 'El correo electrónico es obligatorio.',
            'email.email' => 'El correo electrónico debe ser válido.',
            'password.required' => 'La contraseña es obligatoria.',
            'password.confirmed' => 'Las contraseñas no coinciden.',
            'password.min' => 'La contraseña debe tener al menos 8 caracteres.',
        ]);

        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }

        // Restablecer la contraseña
        $response = Password::reset(
            $request->only('email', 'password', 'password_confirmation', 'token'),
            function ($user, $password) {
                $user->password = bcrypt($password);
                $user->save();
            }
        );

        // Verificar si la actualización fue exitosa
        if ($response == Password::PASSWORD_RESET) {
            return redirect()->route('login')->with('status', 'Contraseña restablecida correctamente');
        }

        return back()->withErrors(['email' => [trans($response)]]);
    }

}
