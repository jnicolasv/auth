<?php $__env->startSection('content'); ?>
<div class="container mx-auto p-6">
    <div class="bg-white p-4 rounded shadow mb-4">
        <h1 class="text-2xl font-bold mb-6">Gestión de Roles y Permisos</h1>

        <!-- Sección de Roles -->
        <div class="mb-8">
            <h2 class="text-xl font-semibold mb-4">Roles</h2>
            
            <!-- Formulario para registrar un nuevo rol -->
            <form action="<?php echo e(route('roles.store')); ?>" method="POST" class="mb-4">
                <?php echo csrf_field(); ?>
                <div class="flex items-center">
                    <input type="text" name="name" placeholder="Nombre del Rol" class="p-2 border rounded mr-2" required>
                    <button type="submit" class="btn-primary-fit">Registrar Rol</button>
                </div>
            </form>

            <!-- Lista de roles -->
            <table class="min-w-full bg-white border">
                <thead>
                    <tr>
                        <th class="py-2 px-4 border">Nombre</th>
                        <th class="py-2 px-4 border">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="py-2 px-4 border"><?php echo e($role->name); ?></td>
                        <td class="py-2 px-4 border">
                            <div class="flex justify-center space-x-2">
                                <!-- Botón para abrir el modal de edición -->
                                <button onclick="openEditModal('role', '<?php echo e($role->id); ?>', '<?php echo e($role->name); ?>')" class="btn-info-fit">Editar</button>
                                <!-- Botón para eliminar el rol -->
                                <form action="<?php echo e(route('roles.destroy', $role->id)); ?>" method="POST" class="inline-block">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn-danger-fit">Eliminar</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <!-- Sección de Permisos -->
        <div class="mb-8">
            <h2 class="text-xl font-semibold mb-4">Permisos</h2>
            
            <!-- Formulario para registrar un nuevo permiso -->
            <form action="<?php echo e(route('permissions.store')); ?>" method="POST" class="mb-4">
                <?php echo csrf_field(); ?>
                <div class="flex items-center">
                    <input type="text" name="name" placeholder="Nombre del Permiso" class="p-2 border rounded mr-2" required>
                    <button type="submit" class="btn-primary-fit">Registrar Permiso</button>
                </div>
            </form>

            <!-- Lista de permisos -->
            <table class="min-w-full bg-white border">
                <thead>
                    <tr>
                        <th class="py-2 px-4 border">Nombre</th>
                        <th class="py-2 px-4 border">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="py-2 px-4 border"><?php echo e($permission->name); ?></td>
                        <td class="py-2 px-4 border">
                            <div class="flex justify-center space-x-2">
                                <!-- Botón para abrir el modal de edición -->
                                <button onclick="openEditModal('permission', '<?php echo e($permission->id); ?>', '<?php echo e($permission->name); ?>')" class="btn-info-fit">Editar</button>
                                <!-- Botón para eliminar el permiso -->
                                <form action="<?php echo e(route('permissions.destroy', $permission->id)); ?>" method="POST" class="inline-block">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn-danger-fit">Eliminar</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <!-- Sección para asignar permisos a roles -->
        <div class="mb-8">
            <h2 class="text-xl font-semibold mb-4">Asignar Permisos a Roles</h2>
            
            <form action="<?php echo e(route('roles.assignPermissions')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="mb-4">
                    <label for="role" class="block mb-2">Seleccionar Rol</label>
                    <select name="role_id" id="role" class="p-2 border rounded w-full" required>
                        <option value="" disabled selected>Seleccione un Rol</option>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="mb-4">
                    <label for="permissions" class="block mb-2">Seleccionar Permisos</label>
                    <div class="grid grid-cols-3 gap-4">
                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div>
                            <label class="inline-flex items-center">
                                <input type="checkbox" name="permissions[]" value="<?php echo e($permission->id); ?>" class="form-checkbox">
                                <span class="ml-2"><?php echo e($permission->name); ?></span>
                            </label>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <button type="submit" class="btn-primary-fit">Asignar Permisos</button>
            </form>
        </div>

        <!-- Modal de edición -->
        <div id="editModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center hidden">
            <div class="bg-white p-6 rounded shadow-lg w-1/3">
                <h2 class="text-xl font-semibold mb-4">Editar</h2>
                <form id="editForm" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <input type="hidden" name="id" id="editId">
                    <div class="mb-4">
                        <label for="editName" class="block mb-2">Nombre</label>
                        <input type="text" name="name" id="editName" class="p-2 border rounded w-full" required>
                    </div>
                    <div class="flex justify-end">
                        <button type="button" onclick="closeEditModal()" class="btn-secondary-fit mr-2">Cancelar</button>
                        <button type="submit" class="btn-primary-fit">Guardar Cambios</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    function openEditModal(type, id, name) {
        document.getElementById('editId').value = id;
        document.getElementById('editName').value = name;
        document.getElementById('editForm').action = `/${type}s/${id}`;
        document.getElementById('editModal').classList.remove('hidden');
    }

    function closeEditModal() {
        document.getElementById('editModal').classList.add('hidden');
    }

    document.getElementById('role').addEventListener('change', function() {
        const roleId = this.value;
        fetch(`/roles/${roleId}/permissions`)
            .then(response => response.json())
            .then(data => {
                document.querySelectorAll('input[name="permissions[]"]').forEach(checkbox => {
                    checkbox.checked = data.permissions.includes(parseInt(checkbox.value));
                });
            });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/users/rolPermission.blade.php ENDPATH**/ ?>