<?php

use App\Http\Controllers\api\ReaccionAdversaController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

// Route::get('/user', function (Request $request) {
//     return $request->user();
// })->middleware('auth:sanctum');
Route::post('/v1/login_reaccion', [ReaccionAdversaController::class, 'login_user']);

Route::middleware('auth:sanctum')->group(function () {
    Route::post('/v1/registro/reaccion', [ReaccionAdversaController::class, 'registrar_reaccion_adversa']);
    Route::get('/v1/obtener/reacciones', [ReaccionAdversaController::class, 'obtener_reacciones_adversas']);
});