<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CtlEstablecimiento extends Model
{
    use HasFactory;

    protected $table = 'ctl_establecimiento';

    protected $fillable = [
        'id_tipo_establecimiento',
        'nombre',
        'direccion',
        'telefono',
        'activo',
        'id_establecimiento_sis',
    ];

    // Relación con SecReaccionAdversa (uno a muchos)
    public function reaccionesAdversas()
    {
        return $this->hasMany(SecReaccionAdversa::class, 'id_establecimiento');
    }

    // Relación con CtlTipoEstablecimiento
    public function tipoEstablecimiento()
    {
        return $this->belongsTo(CtlTipoEstablecimiento::class, 'id_tipo_establecimiento');
    }

    // Relación con MntExpediente
    public function expedientes()
    {
        return $this->hasMany(MntExpediente::class, 'id_establecimiento');
    }

    // Relación con MntEmpleado
    public function empleados()
    {
        return $this->hasMany(MntEmpleado::class, 'id_establecimiento');
    }
}
