<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class FarmViaAdministracionSeeder extends Seeder
{
    public function run()
    {
        DB::table('farm_via_administracion')->insert([
            [
                'nombre' => 'Oral',
                'abreviatura' => null,
            ],
            [
                'nombre' => 'Por sonda',
                'abreviatura' => null,
            ],
            [
                'nombre' => 'Intramuscular',
                'abreviatura' => null,
            ],
            [
                'nombre' => 'Subcutanea',
                'abreviatura' => null,
            ],
            [
                'nombre' => 'Intradermica',
                'abreviatura' => null,
            ],
            [
                'nombre' => 'Inhalado',
                'abreviatura' => null,
            ],
            [
                'nombre' => 'Topica',
                'abreviatura' => null,
            ],
            [
                'nombre' => 'Rectal',
                'abreviatura' => null,
            ],
            [
                'nombre' => 'Endovenoso',
                'abreviatura' => null,
            ],
            [
                'nombre' => 'Central en infusion',
                'abreviatura' => null,
            ],
            [
                'nombre' => 'Vaginal',
                'abreviatura' => null,
            ],
            [
                'nombre' => 'Intraperitoneal',
                'abreviatura' => null,
            ],
            [
                'nombre' => 'Oftálmica ',
                'abreviatura' => null,
            ],
            [
                'nombre' => 'Ótica ',
                'abreviatura' => null,
            ],
            [
                'nombre' => 'Intratecal',
                'abreviatura' => null,
            ],
        ]);
    }
}
