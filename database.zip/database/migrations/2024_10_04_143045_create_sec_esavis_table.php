MntRaReaccionesPresentadas<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('sec_esavi', function (Blueprint $table) {
            $table->id();

            $table->unsignedBigInteger('id_reaccion_adversa');
            $table->unsignedBigInteger('id_clasificacion_notificador');
            $table->unsignedBigInteger('id_accion_tomada');
            $table->string('unidad_efectora_empleado', 120);
            $table->string('condiciones_medicas_embarazo', 256)->nullable();
            $table->timestamp('fecha_resolucion_evento')->nullable();
            $table->timestamp('fecha_inicio_esavi')->nullable();
            $table->string('descripcion_cuadro_clinico', 500)->nullable();
            $table->string('descripcion_accion_tomada', 120)->nullable();
            $table->string('enfermedad_autoinmune', 50)->nullable();
            $table->string('medicacion_concomitante', 150)->nullable();
            $table->boolean('historia_esavi')->nullable();
            $table->string('historia_tipo_reaccion_vacuna', 100)->nullable();
            $table->boolean('antecedentes_familiares_esavi')->nullable();
            $table->string('antecedentes_tipo_reaccion_vacuna', 100)->nullable();
            $table->timestamp('fecha_egreso_alta')->nullable();
            $table->timestamp('fecha_muerte_defuncion')->nullable();
            $table->string('autopsia', 250)->nullable();
            $table->unsignedBigInteger('id_clasificacion_final')->nullable();
            $table->unsignedBigInteger('id_usuario_registra')->nullable();

            // Llaves foráneas
            $table->foreign('id_reaccion_adversa')->references('id')->on('sec_reaccion_adversa')->onDelete('restrict')->onUpdate('cascade');
            $table->foreign('id_clasificacion_notificador')->references('id')->on('ctl_ra_clasificacion_notificador')->onDelete('restrict')->onUpdate('cascade');
            $table->foreign('id_accion_tomada')->references('id')->on('ctl_ra_accion_tomada')->onDelete('restrict')->onUpdate('cascade');
            $table->foreign('id_clasificacion_final')->references('id')->on('ctl_ra_clasificacion_final')->onDelete('restrict')->onUpdate('cascade');
            $table->foreign('id_usuario_registra')->references('id')->on('fos_user_user')->onDelete('restrict')->onUpdate('cascade');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('sec_esavi');
    }
};
