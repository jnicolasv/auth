<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CtlRaClasificacionNotificador extends Model
{
    use HasFactory;

    protected $table = 'ctl_ra_clasificacion_notificador';

    protected $fillable = [
        'nombre_corto',
        'nombre',
        'descripcion',
        'activo',
    ];

    // Relación con SecEsavi (uno a muchos)
    public function esavi()
    {
        return $this->hasMany(SecEsavi::class, 'id_clasificacion_notificador');
    }
}
