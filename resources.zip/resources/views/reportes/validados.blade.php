@extends('layout')

@section('title', 'Reacciones adversas validadas')

@section('content')
<div class="p-6">
    <!-- Filters -->
    <div class="bg-white p-4 rounded shadow mb-4">
        <div class="border-2 border-[#576ca9] bg-[#edf3ff] p-2 rounded-2xl mb-4 text-center">
            <h2 class="text-xl font-semibold text-[#576ca9]">Reacciones adversas validadas</h2>
        </div>
        
        <!-- Formulario de filtros -->
        <form method="GET" action="{{ route('reportes.validados') }}" class="mt-6">

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-x-4 gap-y-6">
                <div class="input-container">
                    <label for="nombre_establecimiento" class="input-label">Establecimiento</label>
                    <input type="text" id="nombre_establecimiento" name="nombre_establecimiento" class="input-field" value="{{ old('nombre_establecimiento', $filters['nombre_establecimiento'] ?? '') }}">
                </div>
                <div class="input-container">
                    <label for="estado" class="input-label">Estado</label>
                    <select id="estado" name="estado" class="select-field bg-white">
                        <option value="" disabled selected>Seleccione</option>
                        <option value="Aprobado" {{ (old('estado', $filters['estado'] ?? '') == 'Aprobado') ? 'selected' : '' }}>
                            {{ 'Aprobado' }}
                        </option>
                        <option value="Rechazado" {{ (old('estado', $filters['estado'] ?? '') == 'Rechazado') ? 'selected' : '' }}>
                            {{ 'Rechazado' }}
                        </option>
                    </select>                    
                </div>
                <div class="input-container">
                    <label for="tipo_reaccion" class="input-label">Tipo de Evento</label>
                    <select id="tipo_reaccion" name="tipo_reaccion" class="select-field bg-white">
                        <option value="" disabled selected>Seleccione</option>
                        @foreach($tipos_reaccion as $tipo_reaccion)
                            <option value="{{ $tipo_reaccion }}" {{ (old('tipo_reaccion', $filters['tipo_reaccion'] ?? '') == $tipo_reaccion) ? 'selected' : '' }}>
                                {{ $tipo_reaccion }}
                            </option>
                        @endforeach
                    </select>                    
                </div>
                <div class="input-container">
                    <label for="fecha_rango" class="input-label">Fecha de Reporte</label>
                    <input type="text" id="fecha_rango" name="fecha_rango" class="input-field" value="{{ old('fecha_rango', $filters['fecha_rango'] ?? '') }}">
                </div>
            </div>

            <!-- Botones agrupados -->
            <div class="flex justify-center gap-4 mt-4">
                <div class="input-container w-1/2 sm:w-2/5 md:w-3/10 lg:w-1/5">
                    <button type="submit" class="input-button btn-primary">FILTRAR</button>
                </div>
                <div class="input-container w-1/2 sm:w-2/5 md:w-3/10 lg:w-1/5">
                    <a href="{{ route('reportes.validados') }}" class="input-button btn-secondary">LIMPIAR</a>
                </div>
            </div>

        </form>

        <hr class="col-span-3 my-4 border-t border-[#576ca9]">     

        <!-- Notificaciones -->
        <div id="notificaciones">
            @if(session('success'))
                <div class="bg-green-500 text-white p-2 mt-4 rounded-md relative">
                    <div class="flex items-center gap-2">
                        <span class="material-symbols-outlined">check_circle</span> 
                        <span>{{ session('success') }}</span>
                    </div>
                    <button class="notification-close-button" onclick="this.parentElement.style.display='none';"><span class="material-symbols-outlined">close</span></button>
                </div>
            @endif
            @if(session('error'))
                <div class="bg-red-500 text-white p-2 mt-4 rounded-md relative">
                    <div class="flex items-center gap-2">
                        <span class="material-symbols-outlined">cancel</span> 
                        <span>{{ session('error') }}</span>
                    </div>
                    <button class="notification-close-button" onclick="this.parentElement.style.display='none';"><span class="material-symbols-outlined">close</span></button>
                </div>
            @endif
        
            @if(session('warning'))
                <div class="bg-yellow-500 text-white p-2 mt-4 rounded-md relative">
                    <div class="flex items-center gap-2">
                        <span class="material-symbols-outlined">error</span> 
                        <span>{{ session('warning') }}</span>
                    </div>
                    <button class="notification-close-button" onclick="this.parentElement.style.display='none';"><span class="material-symbols-outlined">close</span></button>
                </div>
            @endif
        
            @if(session('info'))
                <div class="bg-blue-500 text-white p-2 mt-4 rounded-md relative">
                    <div class="flex items-center gap-2">
                        <span class="material-symbols-outlined">info</span> 
                        <span>{{ session('info') }}</span>
                    </div>
                    <button class="notification-close-button" onclick="this.parentElement.style.display='none';"><span class="material-symbols-outlined">close</span></button>
                </div>
            @endif
        </div>
        
        <!-- Tabla de usuarios -->
        <div class="bg-white p-4 rounded shadow">
            <div class="table-container overflow-x-auto max-w-full">
                <table class="min-w-[700px] w-full table-auto border-collapse border border-gray-200">        
                    <thead class="bg-[#576ca9] text-white">
                        <tr>
                            <th class="p-2 border">Tipo evento</th>
                            <th class="p-2 border">Establecimiento</th>
                            <th class="p-2 border">Médico</th>
                            <th class="p-2 border">Paciente</th>
                            <th class="p-2 border">Fecha hora reporte</th>
                            <th class="p-2 border">Estado</th>
                            <th class="p-2 border">Accion</th>
                        </tr>
                    </thead>
                    <tbody>
                        @php
                            // Contador para verificar cuántos filtros están definidos y no son null
                            $filtrosDefinidos = 0;

                            if (isset($filters['nombre_establecimiento']) && $filters['nombre_establecimiento'] != null) {
                                $filtrosDefinidos++;
                                $notificacion = "No se encontraron reacciones adversas validadas para el establecimiento {$filters['nombre_establecimiento']}";
                            }

                            if (isset($filters['estado']) && $filters['estado'] != null) {
                                $filtrosDefinidos++;
                                $notificacion = "No se encontraron reacciones adversas validadas para el estado {$filters['estado']}";
                            }

                            if (isset($filters['tipo_reaccion']) && $filters['tipo_reaccion'] != null) {
                                $filtrosDefinidos++;
                                $notificacion = "No se encontraron reacciones adversas validadas para el tipo de evento {$filters['tipo_reaccion']}";
                            }

                            if (isset($filters['fecha_rango']) && $filters['fecha_rango'] != null) {
                                $filtrosDefinidos++;
                                $notificacion = "No se encontraron reacciones adversas validadas para el rango de fechas {$filters['fecha_rango']}";
                            }
                        @endphp

                        @if($reacciones->isEmpty())
                            @if($filtrosDefinidos == 1)
                                <tr>
                                    <td class="p-2 border text-center bg-gray-300" colspan="7">
                                        {{ $notificacion }}
                                    </td>
                                </tr>
                            @elseif($filtrosDefinidos >= 2)
                                <tr>
                                    <td class="p-2 border text-center bg-gray-300" colspan="7">
                                        No se encontraron reacciones adversas validadas para los filtros seleccionados
                                    </td>
                                </tr>
                            @else
                                <tr>
                                    <td class="p-2 border text-center bg-gray-300" colspan="7">
                                        No se encontraron reacciones adversas validadas
                                    </td>
                                </tr>
                            @endif
                        @else
                            @foreach($reacciones as $reaccion)
                                <tr class="odd:bg-gray-100">
                                    {{-- @dd($reaccion->persona) --}}
                                    <td class="p-2 border text-center">
                                        @if($reaccion->tipo_reaccion == 'ESAVI')
                                            <span class="etiqueta_esavi">
                                                {{ $reaccion->tipo_reaccion }}
                                            </span>
                                        @else
                                            <span class="etiqueta_ram">
                                                RAM
                                            </span>
                                        @endif
                                    </td>
                                    <td class="p-2 border">{{ $reaccion->establecimiento ?? '' }}</td>
                                    <td class="p-2 border">{{ $reaccion->medico }}</td>                         
                                    <td class="p-2 border">{{ $reaccion->paciente }}</td>                         
                                    <td class="p-2 border">{{ \Carbon\Carbon::parse($reaccion->fecha_notificacion)->format('d-m-Y h:i A') }}</td>
                                    <td class="p-2 border text-center">
                                        @if($reaccion->estado_verificacion == 'Aprobado')
                                            <span class="etiqueta_aprobado">
                                                {{ $reaccion->estado_verificacion }}
                                            </span>
                                        @else
                                            <span class="etiqueta_rechazado">
                                                {{ $reaccion->estado_verificacion }}
                                            </span>
                                        @endif
                                    </td>
                                    <td class="p-2 border text-center">
                                        <div class="flex justify-center space-x-3">
                                            <a href="{{ route('reporte.verificar', $reaccion->id) }}" class="text-[#576ca9]"><span class="material-symbols-outlined">visibility</span></a>
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                        @endif
                    </tbody>
                </table>
                <!-- Paginación -->
                <div class="mt-6">
                    <div class="pagination">
                        {{ $reacciones->appends(request()->query())->links() }}
                    </div>
                </div>
            </div>
        </div> <!-- Fin de la tabla de usuarios -->

    </div>
</div>

@endsection

@push('scripts')
<script>
    flatpickr("#fecha_rango", {
        mode: "range",
        dateFormat: "d-m-Y",
        maxDate: "today",
        locale: "es",
        theme: "airbnb"
    });

    // Validar que el campo de filtro nombre solo se puedan ingresar letras y espacios
    document.getElementById('nombre_establecimiento').addEventListener('keyup', function (e) {
        const regex = /[^a-zA-Z\s]/g;
        e.target.value = e.target.value.replace(regex, '');
    });
</script>
@endpush