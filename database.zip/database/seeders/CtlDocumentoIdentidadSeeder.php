<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CtlDocumentoIdentidadSeeder extends Seeder
{
    public function run()
    {
        DB::table('ctl_documento_identidad')->insert([
            [
                'nombre' => 'Documento Único Identidad',
                'abreviatura' => 'DUI',
            ],
            [
                'nombre' => 'Carné Minoridad',
                'abreviatura' => 'CM',
            ],
            [
                'nombre' => 'Carné ISSS',
                'abreviatura' => 'CISSS',
            ],
            [
                'nombre' => 'Pasaporte',
                'abreviatura' => 'P',
            ],
            [
                'nombre' => 'Carné Trabajo',
                'abreviatura' => 'CT',
            ],
            [
                'nombre' => 'Carné Estudiante',
                'abreviatura' => 'CE',
            ],
            [
                'nombre' => 'Ninguno',
                'abreviatura' => 'NA',
            ],
            [
                'nombre' => 'Otros',
                'abreviatura' => 'O',
            ],
            [
                'nombre' => 'Partida Nacimiento',
                'abreviatura' => 'PN',
            ],
            [
                'nombre' => 'Número de Identificación Tributaria',
                'abreviatura' => 'NIT',
            ],
            [
                'nombre' => 'Carné de Residencia',
                'abreviatura' => 'CR',
            ],
            [
                'nombre' => 'Carnet Veterano',
                'abreviatura' => 'CV',
            ],
            [
                'nombre' => 'Código Único Nacimiento',
                'abreviatura' => 'CUN',
            ],
            [
                'nombre' => 'Número Único de Indentidad',
                'abreviatura' => 'NUI',
            ],
        ]);
    }
}
