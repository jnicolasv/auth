<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SecRam extends Model
{
    use HasFactory;

    protected $table = 'sec_ram';

    protected $fillable = [
        'id_reaccion_adversa',
        'paciente_hospitalizado',
        'fecha_alta',
        'indicaciones_uso_medicamento',
        'examenes_laboratorio',
        'id_rb_desaparece_reaccion',
        'id_rb_reaparece_reaccion',
        'id_rb_antecedentes_reacciones_adversas',
        'discapacidad_por_ram',
        'descripcion_discapacidad',
        'ram_por_tb',
        'id_usuario_registra',
        'id_accion_tomada',
    ];

    public function reaccionAdversa()
    {
        return $this->belongsTo(SecReaccionAdversa::class, 'id_reaccion_adversa');
    }

    public function respuestaDesaparece()
    {
        return $this->belongsTo(CtlRespuestaBasica::class, 'id_rb_desaparece_reaccion');
    }

    public function respuestaReaparece()
    {
        return $this->belongsTo(CtlRespuestaBasica::class, 'id_rb_reaparece_reaccion');
    }

    public function antecedentesReacciones()
    {
        return $this->belongsTo(CtlRespuestaBasica::class, 'id_rb_antecedentes_reacciones_adversas');
    }

    public function accionTomada()
    {
        return $this->belongsTo(CtlRaAccionTomada::class, 'id_accion_tomada');
    }

    public function usuarioRegistra()
    {
        return $this->belongsTo(FosUserUser::class, 'id_usuario_registra');
    }


}
