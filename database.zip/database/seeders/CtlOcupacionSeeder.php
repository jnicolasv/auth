<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CtlOcupacionSeeder extends Seeder
{
    public function run()
    {
        DB::table('ctl_ocupacion')->insert([
            [
                'nombre' => 'AMA DE CASA',
                'id_sumeve' => '2',
            ],
            [
                'nombre' => 'ESTUDIANTE',
                'id_sumeve' => '3',
            ],
            [
                'nombre' => 'PROFESIONAL',
                'id_sumeve' => '11',
            ],
            [
                'nombre' => 'TECNICO',
                'id_sumeve' => '11',
            ],
            [
                'nombre' => 'FUNCIONARIO PUBLICO',
                'id_sumeve' => '11',
            ],
            [
                'nombre' => 'PERSONAL ADMINISTRATIV',
                'id_sumeve' => '11',
            ],
            [
                'nombre' => 'COMERCIANTE Y VENDEDOR',
                'id_sumeve' => '11',
            ],
            [
                'nombre' => 'SERVICIO PROFESIONAL',
                'id_sumeve' => '11',
            ],
            [
                'nombre' => 'TRABAJADOR AGRICOLA',
                'id_sumeve' => '7',
            ],
            [
                'nombre' => 'OBREROS NO AGRICOLAS',
                'id_sumeve' => '7',
            ],
            [
                'nombre' => 'CONDUCTOR DE MAQUINA',
                'id_sumeve' => '11',
            ],
            [
                'nombre' => 'MOTORISTA',
                'id_sumeve' => '11',
            ],
            [
                'nombre' => 'OTRO',
                'id_sumeve' => '11',
            ],
            [
                'nombre' => 'NINGUNA ACTIVIDAD',
                'id_sumeve' => '11',
            ],
            [
                'nombre' => 'EMPLEADO FORMAL',
                'id_sumeve' => '6',
            ],
            [
                'nombre' => 'ALBAÑIL',
                'id_sumeve' => '11',
            ],
            [
                'nombre' => 'SASTRE',
                'id_sumeve' => '11',
            ],
            [
                'nombre' => 'AGRICULTOR EN PEQUEÑO',
                'id_sumeve' => '11',
            ],
            [
                'nombre' => 'DOMESTICO',
                'id_sumeve' => '11',
            ],
            [
                'nombre' => 'LIC EN LAB CLINICO',
                'id_sumeve' => '11',
            ],
            [
                'nombre' => 'PROFESOR@',
                'id_sumeve' => '11',
            ],
            [
                'nombre' => 'PASTOR',
                'id_sumeve' => '11',
            ],
            [
                'nombre' => 'RELIGIOS@',
                'id_sumeve' => '11',
            ],
            [
                'nombre' => 'COSTURERA',
                'id_sumeve' => '11',
            ],
            [
                'nombre' => 'MECANICO',
                'id_sumeve' => '11',
            ],
            [
                'nombre' => 'MECANICO EN OBRA DE BC',
                'id_sumeve' => '11',
            ],
            [
                'nombre' => 'AYUDANTE DE MECANICO',
                'id_sumeve' => '11',
            ],
            [
                'nombre' => 'COSMETOLOGA',
                'id_sumeve' => '11',
            ],
            [
                'nombre' => 'JORNALERO',
                'id_sumeve' => '11',
            ],
            [
                'nombre' => 'SECRETARIA(O)',
                'id_sumeve' => '11',
            ],
            [
                'nombre' => 'JUBILADO/PENSIONADO',
                'id_sumeve' => '4',
            ],
            [
                'nombre' => 'MODISTA',
                'id_sumeve' => '11',
            ],
            [
                'nombre' => 'MECANICO DELTAL',
                'id_sumeve' => '11',
            ],
            [
                'nombre' => 'BARBERO',
                'id_sumeve' => '11',
            ],
            [
                'nombre' => 'CARPINTERO',
                'id_sumeve' => '11',
            ],
            [
                'nombre' => 'COMERCIANTE',
                'id_sumeve' => '8',
            ],
            [
                'nombre' => 'VENDEDOR',
                'id_sumeve' => '11',
            ],
            [
                'nombre' => 'EMPLEADO INFORMAL',
                'id_sumeve' => '5',
            ],
            [
                'nombre' => 'CUERPOS UNIFORMADOS',
                'id_sumeve' => '9',
            ],
            [
                'nombre' => 'DESEMPLEADO(A)',
                'id_sumeve' => '1',
            ],
            [
                'nombre' => 'NO APLICA',
                'id_sumeve' => '10',
            ],
            [
                'nombre' => 'MEDICO',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'MEDICO ESPECIALISTA',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'MEDICO ECO-MINSAL',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'MINISTRO EVANGELICO',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'MOLINERO',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'OBRERO',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'OFICINISTA',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'OFICIOS DOMESTICOS',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'OFICIOS VARIOS',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'PANIFICADOR',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'PENSIONADO',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'PASTOR EVANGELICO',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'PENSIONADO',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'PERSONAL DE SALUD',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'PINTOR',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'PROFESOR EDUCACION FISICA',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'PSICOLOGO',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'SIN PROFESIÓN',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'TAXISTA',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'TEC. EN SALUD-HIGIENE DENTAL',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'TECNICO EN INGENIERIA INDUSTRIAL',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'TECNICO EN LABORATORIO',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'TECNOLOGO MEDICO ANESTESISTA',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'TELEOPERADOR',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'TRANSPORTISTA',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'ZAPATERO',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'ABOGADO',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'ABOGADO Y NOTARIO',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'ADMINISTRACION DE EMP.',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'AGRICULTOR',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'AGRONOMO',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'ARTESANO',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'AYUDANTE DE ALBAÑIL',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'BACHILLER',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'BACHILLER SECRETARIADO',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'CAFICULTOR',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'COMERCIANTE PEQUEÑO',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'CONSERJE',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'CONTADOR',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'DOCTOR(A) EN MEDICINA',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'EJECUTIVO DE EMBARGO',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'ELECTRICISTA',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'EMPRESARIO',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'EMPRESARIO INDUSTRIAL',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'ENDERAZADO Y PINTURA',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'ENFERMERA',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'ESTILISTA',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'FILARMONICO',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'FONTANERO',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'FOTOGRAFO(A)',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'ING. EN SISTEMAS',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'ING. INDUSTRIAL',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'ING. CIVIL',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'ING. ELECTRICISTA',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'ING. MECANICO',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'INSPECTOR DE SALUD',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'INTERPRETE TRADUCTOR',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'JARDINERO',
                'id_sumeve' => null,
            ],
            [
                'nombre' => 'SACERDOTE',
                'id_sumeve' => null,
            ],
        ]);
    }
}
