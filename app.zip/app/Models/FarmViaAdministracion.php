<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FarmViaAdministracion extends Model
{
    use HasFactory;

    protected $table = 'farm_via_administracion';

    protected $fillable = [
        'nombre',
        'abreviatura',
    ];

    public function vacunasSospechosas()
    {
        return $this->hasMany(SecVacunaSospechosaEsavi::class, 'id_via_administracion');
    }
}
