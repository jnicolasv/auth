<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CtlRaCondicionDesenlace extends Model
{
    use HasFactory;

    // Especifica la tabla asociada al modelo
    protected $table = 'ctl_ra_condicion_desenlace';

    // Define los atributos que pueden ser asignados masivamente
    protected $fillable = [
        'nombre_corto',
        'nombre',
        'descripcion',
        'activo'
    ];

    // Relación con SecReaccionAdversa (uno a muchos)
    public function reaccionesAdversas()
    {
        return $this->hasMany(SecReaccionAdversa::class, 'id_condicion_desenlace');
    }
}
