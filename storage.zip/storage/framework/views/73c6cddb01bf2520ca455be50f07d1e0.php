<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('login')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    
    <div class="relative mb-4">
        <label for="email" class="absolute -top-2 left-4 bg-white text-gray-700 text-sm px-1">Usuario o Correo Electrónico</label>
        <input
            type="text"
            id="login"
            name="login"
            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-300 focus:border-blue-500"
            placeholder=""
            value="<?php echo e(old('login')); ?>"
        >
    </div>
    
    <div class="relative mb-4">
        <label for="password" class="absolute -top-2 left-4 bg-white text-gray-700 text-sm px-1">Contraseña</label>
        <input
            type="password"
            id="password"
            name="password"
            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-300 focus:border-blue-500"
            placeholder=""
        >
    </div>

    <?php if(session('status')): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
            <p class="text-sm"><?php echo e(session('status')); ?></p>
        </div>
    <?php endif; ?>
    
    <?php if($errors->any()): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p class="text-sm"><?php echo e($error); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    <button type="submit" class="w-full bg-[#576ca9] text-white font-bold py-3 rounded-lg hover:bg-[#4a5a8a]">
        INICIAR SESIÓN
    </button>
</form>
<div class="text-center mt-6">
    <span class="text-gray-700">¿Has olvidado tu contraseña?</span> <a href="<?php echo e(route('password.email')); ?>" id="btn_recuperar_contra" class="text-[#576ca9] hover:underline inline"> <strong>Recuperar Cuenta</strong></a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout-login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/logins/login.blade.php ENDPATH**/ ?>