<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SecEsavi extends Model
{
    use HasFactory;

    protected $table = 'sec_esavi';

    protected $fillable = [
        'id_reaccion_adversa',
        'id_clasificacion_notificador',
        'id_accion_tomada',
        'unidad_efectora_empleado',
        'condiciones_medicas_embarazo',
        'fecha_resolucion_evento',
        'fecha_inicio_esavi',
        'descripcion_cuadro_clinico',
        'descripcion_accion_tomada',
        'enfermedad_autoinmune',
        'medicacion_concomitante',
        'historia_esavi',
        'historia_tipo_reaccion_vacuna',
        'antecedentes_familiares_esavi',
        'antecedentes_tipo_reaccion_vacuna',
        'fecha_egreso_alta',
        'fecha_muerte_defuncion',
        'autopsia',
        'id_clasificacion_final',
        'id_usuario_registra',
    ];

    // Relaciones con otras tablas
    public function reaccionAdversa()
    {
        return $this->belongsTo(SecReaccionAdversa::class, 'id_reaccion_adversa');
    }

    public function clasificacionNotificador()
    {
        return $this->belongsTo(CtlRaClasificacionNotificador::class, 'id_clasificacion_notificador');
    }

    public function accionTomada()
    {
        return $this->belongsTo(CtlRaAccionTomada::class, 'id_accion_tomada');
    }

    public function clasificacionFinal()
    {
        return $this->belongsTo(CtlRaClasificacionFinal::class, 'id_clasificacion_final');
    }

    public function usuarioRegistra()
    {
        return $this->belongsTo(FosUserUser::class, 'id_usuario_registra');
    }

    // Relación con SecRaDiagnostico (uno a muchos)
    public function diagnosticos()
    {
        return $this->hasMany(SecRaDiagnostico::class, 'id_esavi');
    }

    public function vacunasSospechosas()
    {
        return $this->hasOne(SecVacunaSospechosaEsavi::class, 'id_esavi');
    }

    public function reaccionesPresentadas()
    {
        return $this->hasMany(MntRaReaccionesPresentadas::class, 'id_esavi');
    }

    public function examenesLaboratorioProcedimientos()
    {
        return $this->hasMany(MntRaExamenesLaboratorioProcedimientos::class, 'id_esavi');
    }

    public function vacunasConcomitantes()
    {
        return $this->hasMany(MntRaVacunasConcomitantes::class, 'id_esavi');
    }
}
