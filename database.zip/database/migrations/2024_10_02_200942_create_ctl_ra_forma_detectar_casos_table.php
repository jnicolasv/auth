<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('ctl_ra_forma_detectar_caso', function (Blueprint $table) {
            $table->id();

            $table->string('nombre_corto', 8);
            $table->string('nombre', 50);
            $table->string('descripcion', 300)->nullable();
            $table->boolean('activo');
            
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('ctl_ra_forma_detectar_caso');
    }
};
