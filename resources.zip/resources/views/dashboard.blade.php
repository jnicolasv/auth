@extends('layout')

@section('title', 'Dashboard')

@push('styles')
<style>
    .responsive-table {
        overflow-x: auto;
    }
    table {
        min-width: 100%;
    }
</style>
@endpush

@section('content')
<div class="p-6">
    <div class="bg-white p-4 rounded shadow mb-4">

        <!-- Notificacion para cambiar la contreseña -->
        @if(session('password_change_alert'))
            <div class="bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-3 rounded relative mb-4" role="alert">
                <p class="text-sm flex items-center gap-2"><span class="material-symbols-outlined">error</span> {{ session('password_change_alert') }}</p>
            </div>
        @endif

        <div class="border-2 border-[#576ca9] bg-[#edf3ff] p-2 rounded-2xl mb-4 text-center">
            <h2 class="text-xl font-semibold text-[#576ca9]">Dashboard del Sistema</h2>
        </div>
    </div>
</div>
@endsection


@push('scripts')
<script src="{{ asset('js/dashboard.js') }}"></script>
<script>
    $(document).ready(function() {
        /*$('#tablaUsuarios').DataTable({
            language: {
                url: '//cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json'
            },
            responsive: true,
            paging: true,
            searching: true,
        });*/
    });
</script>
@endpush

