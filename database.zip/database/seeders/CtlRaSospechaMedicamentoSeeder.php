<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CtlRaSospechaMedicamentoSeeder extends Seeder
{
    public function run()
    {
        DB::table('ctl_ra_sospecha_medicamento')->insert([
            [
                'nombre_corto' => 'SOSP',
                'nombre' => 'Sospechoso',
                'descripcion' => 'Medicamento que se sopecha causo la reaccion adversa',
                'activo' => true,
            ],
            [
                'nombre_corto' => 'CONC',
                'nombre' => 'Concomitante',
                'descripcion' => 'Medicamento con comitante',
                'activo' => true,
            ],
            [
                'nombre_corto' => 'INTE',
                'nombre' => 'Interacción',
                'descripcion' => 'Medicamento que interactuo',
                'activo' => true,
            ],
        ]);
    }
}
