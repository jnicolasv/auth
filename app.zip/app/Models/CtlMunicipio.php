<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CtlMunicipio extends Model
{
    use HasFactory;

    // Especificar la tabla asociada
    protected $table = 'ctl_municipio';

    // Campos que pueden ser asignados masivamente
    protected $fillable = [
        'nombre',
        'codigo_cnr',
        'abreviatura',
        'id_departamento',
        'codigo_rnpn',
        'municipio2023id',
    ];

    // Relación con CtlDepartamento
    public function departamento()
    {
        return $this->belongsTo(CtlDepartamento::class, 'id_departamento');
    }

    // Relación opcional con CtlMunicipio2023
    public function municipio2023()
    {
        return $this->belongsTo(CtlMunicipio2023::class, 'municipio2023id');
    }

    // Relación con CtlCanton
    public function cantones()
    {
        return $this->hasMany(CtlCanton::class, 'id_municipio');
    }
}
