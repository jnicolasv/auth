<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Atcs extends Model
{
    use HasFactory;

    protected $table = 'atcs';

    protected $fillable = ['code', 'text', 'official_flag', 'id_whodrug'];
}
