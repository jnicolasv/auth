<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class CreateUsersSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $users = [
            ['name' => 'sadmin','email' => 'cristian.hrnandezh@salud.gob.sv','password' => bcrypt('4dm1n1str4d0r_Ap!')],
            ['name' => 'userApi','email' => 'user.apireacciones@salud.gob.sv','password' => bcrypt('Us3r_4p!')],
            ['name' => 'admin','email' => 'emailadmin@salud.gob.sv','password' => bcrypt('4dm1n1str4d0r_r4c!')],
        ];

        foreach ($users as $user) {
            \App\Models\User::create($user);
        }
    }
}
