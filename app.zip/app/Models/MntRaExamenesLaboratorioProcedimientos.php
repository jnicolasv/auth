<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MntRaExamenesLaboratorioProcedimientos extends Model
{
    use HasFactory;

    protected $table = 'mnt_ra_examenes_laboratorio_procedimientos';

    protected $fillable = [
        'examen_realizado',
        'id_tipo_muestra',
        'resultados',
        'fecha_realizacion',
        'id_esavi',
        'id_usuario_registra',
    ];

    // Relación con SecEsavi (muchos a uno)
    public function esavi()
    {
        return $this->belongsTo(SecEsavi::class, 'id_esavi');
    }

    // Relación con LabTipoMuestra (muchos a uno)
    public function tipoMuestra()
    {
        return $this->belongsTo(LabTipomuestra::class, 'id_tipo_muestra');
    }

    // Relación con FosUserUser para el usuario que registra (muchos a uno)
    public function usuarioRegistra()
    {
        return $this->belongsTo(FosUserUser::class, 'id_usuario_registra');
    }
}
