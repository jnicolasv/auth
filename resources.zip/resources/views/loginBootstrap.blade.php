<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Login</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

    <link href="{{ asset('css/app.css') }}" rel="stylesheet">

</head>
<body class="bg-light d-flex flex-column vh-100">

    <!-- Contenedor principal -->
    <div class="d-flex flex-column flex-md-row flex-grow-1">

        <!-- Imagen a la izquierda -->
        <div class="col-12 col-sm-12 col-md-5 col-lg-6 col-xl-7 col-xxl-8 d-flex justify-content-center align-items-center">
            <img src="{{ asset('images/img-login.png') }}" alt="Estadísticas" class="w-100 h-100 object-cover">
        </div>

        <!-- Login a la derecha -->
        <div class="col-12 col-sm-12 col-md-7 col-lg-6 col-xl-5 col-xxl-4 d-flex justify-content-center align-items-center p-5">
            <div class="bg-white shadow-lg rounded p-5 w-100 h-100 d-flex flex-column justify-content-center">
                <div class="text-center mb-4">
                    <!-- Logo -->
                    <img src="{{ asset('images/logo.png') }}" alt="Logo" class="img-fluid mx-auto mb-4 w-auto">
                    <h2 class="text-primary">
                        Sistema Centralizado de Reacciones Adversas
                    </h2>
                </div>
        
                <div id="zona_inicio_sesion">
                    <!-- Formulario Inicio de sesión -->
                    <form action="{{ route('login') }}" method="GET">
        
                        <div class="input-container">
                            <label for="email">Correo Electrónico</label>
                            <input type="email" id="email" name="email">
                        </div>
                        
                        <div class="input-container">
                            <label for="password">Contraseña</label>
                            <input type="password" id="password" name="password">
                        </div>

                        {{-- <div class="mb-3">
                            <label for="email" class="form-label">Correo Electrónico</label>
                            <input type="email" id="email" name="email" class="form-control" placeholder="Correo Electrónico">
                        </div>
                        
                        <div class="mb-3">
                            <label for="password" class="form-label">Contraseña</label>
                            <input type="password" id="password" name="password" class="form-control" placeholder="Contraseña">
                        </div>--}}
                        
                        <button type="submit" class="btn btn-primary w-100">
                            INICIAR SESIÓN
                        </button>
                    </form>                
        
                    <!-- Recuperar cuenta -->
                    <div class="text-center mt-4">
                        <span>¿Has olvidado tu contraseña?</span> <a href="#" id="btn_recuperar_contra" class="text-primary"><strong>Recuperar Cuenta</strong></a>
                    </div>
                </div>
        
                <div id="zona_recuperar_contra" style="display:none;">
                    <!-- Formulario de recuperación de contraseña -->
                    <div class="text-center mb-4">
                        <p>
                            Se ha enviado un código de verificación a su correo institucional, por favor ingrese el código en el siguiente campo.
                        </p>
                    </div>
                    
                    <div class="mb-3">
                        <label for="verification_code" class="form-label">Código de Verificación</label>
                        <input type="text" id="verification_code" name="verification_code" class="form-control">
                    </div>
                    
                    <div class="d-flex gap-2 mt-4">
                        <button type="submit" class="btn btn-primary w-100">
                            INICIAR SESIÓN
                        </button>
                        <button type="button" id="btn_cancelar_recuperacion" class="btn btn-secondary w-100">
                            CANCELAR
                        </button>
                    </div>
                </div>
        
            </div>
        </div> <!-- Fin Login -->

    </div>

    <!-- Footer -->
    <footer class="bg-primary text-white text-end py-2 px-4 mt-auto">
        <strong>Dirección de Tecnologías de Información y Comunicaciones © 2025</strong>
    </footer>

    <script>
        document.getElementById('zona_recuperar_contra').style.display = 'none';

        document.getElementById('btn_recuperar_contra').addEventListener('click', function(event) {
            event.preventDefault();
            document.getElementById('zona_recuperar_contra').style.display = 'block';
            document.getElementById('zona_inicio_sesion').style.display = 'none';
        });

        document.getElementById('btn_cancelar_recuperacion').addEventListener('click', function(event) {
            event.preventDefault();
            document.getElementById('zona_recuperar_contra').style.display = 'none';
            document.getElementById('zona_inicio_sesion').style.display = 'block';
        });
    </script>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>