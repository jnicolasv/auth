<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('sec_ra_diagnostico', function (Blueprint $table) {
            $table->id();
            
            $table->unsignedBigInteger('id_esavi')->nullable();
            $table->unsignedBigInteger('id_tipo_diagnostico')->nullable();
            $table->unsignedBigInteger('id_cie10')->nullable();
            $table->unsignedBigInteger('id_tipo_consulta')->nullable();
            $table->unsignedBigInteger('id_vacuna')->nullable();
            $table->string('especificacion', 200)->nullable();
            $table->boolean('confirmado')->nullable();
            $table->boolean('presuntivo')->nullable();
            $table->unsignedBigInteger('id_usuario_registra')->nullable();

            // Llaves foráneas
            $table->foreign('id_esavi')->references('id')->on('sec_esavi')->onDelete('restrict')->onUpdate('cascade');
            $table->foreign('id_tipo_diagnostico')->references('id')->on('ctl_tipo_diagnostico')->onDelete('restrict')->onUpdate('cascade');
            $table->foreign('id_cie10')->references('id')->on('mnt_cie10')->onDelete('restrict')->onUpdate('cascade');
            $table->foreign('id_tipo_consulta')->references('id')->on('ctl_tipo_consulta')->onDelete('restrict')->onUpdate('cascade');
            $table->foreign('id_vacuna')->references('id')->on('ctl_vacunas')->onDelete('restrict')->onUpdate('cascade');
            $table->foreign('id_usuario_registra')->references('id')->on('fos_user_user')->onDelete('restrict')->onUpdate('cascade');
            
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('sec_ra_diagnostico');
    }
};
