<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('ctl_establecimiento', function (Blueprint $table) {
            $table->id();

            $table->unsignedBigInteger('id_tipo_establecimiento')->nullable();
            $table->string('nombre', 150);
            $table->string('direccion', 250)->nullable();
            $table->string('telefono', 15)->nullable();
            $table->boolean('activo')->nullable();
            $table->integer('id_establecimiento_sis');
            $table->foreign('id_tipo_establecimiento')->references('id')->on('ctl_tipo_establecimiento');
            
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('ctl_establecimiento');
    }
};
