<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MntRaReaccionesPresentadas extends Model
{
    use HasFactory;

    protected $table = 'mnt_ra_reacciones_presentadas';

    protected $fillable = [
        'id_esavi',
        'codigo',
        'label_codigo_snomed',
        'id_usuario_registra',
    ];

    // Relación con SecEsavi
    public function esavi()
    {
        return $this->belongsTo(SecEsavi::class, 'id_esavi');
    }

    // Relación con FosUserUser (usuario registra)
    public function usuarioRegistra()
    {
        return $this->belongsTo(FosUserUser::class, 'id_usuario_registra');
    }
}
